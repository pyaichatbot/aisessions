# Session 7 Demo — Tools & MCP

This demo shows how to expose tools using MCP (Model Context Protocol) and consume them with an agent orchestrator.

## 🧠 What it shows
- Python MCP server (`fastmcp`) exposing file-related tools.
- Node orchestrator using `mcp-use` to call tools.
- React frontend that shows agent activity: LLM-only responses vs tool usage.

## 🚀 Quick start
```bash
docker compose up --build
```
- MCP server runs in Python (tools: list_files, read_file, grep_text).
- Orchestrator (Node/Express) routes requests: general → LLM, file/search → MCP tool.
- Frontend (React/Vite) UI at http://localhost:5173

## Example Queries
- "What is the capital of France?" → plain LLM response
- "List files under ./data" → MCP list_files tool
- "Read file ./README.md" → MCP read_file tool
- "Search for 'policy' in README.md" → MCP grep_text tool

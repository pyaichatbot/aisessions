export async function callLLM(message: string) {
  // For demo: echo message. Replace with OpenAI/Azure API for real use.
  return { mode: "llm", answer: `LLM response to: ${message}` };
}

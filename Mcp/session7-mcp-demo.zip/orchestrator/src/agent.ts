import { connect, callTool } from "./mcp.js";

export async function runAgent(message: string) {
  const client = await connect();
  if (/list/i.test(message)) {
    const result = await callTool(client, "list_files", { path: "." });
    return { mode: "agent", tool: "list_files", result };
  } else if (/read/i.test(message)) {
    const result = await callTool(client, "read_file", { path: "./README.md" });
    return { mode: "agent", tool: "read_file", result };
  } else if (/search|grep/i.test(message)) {
    const result = await callTool(client, "grep_text", { path: "./README.md", pattern: "policy" });
    return { mode: "agent", tool: "grep_text", result };
  }
  return { mode: "agent", answer: "No matching tool found." };
}

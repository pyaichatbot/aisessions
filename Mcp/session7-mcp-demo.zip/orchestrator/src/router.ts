import { callLLM } from "./llm.js";
import { runAgent } from "./agent.js";

export async function router(message: string) {
  if (/file|search|grep/i.test(message)) {
    return await runAgent(message);
  } else {
    return await callLLM(message);
  }
}

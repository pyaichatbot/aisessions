import { useState } from 'react';
import './theme.css';

export default function App() {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<any[]>([]);

  const send = async () => {
    const res = await fetch("http://localhost:3000/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: input })
    });
    const data = await res.json();
    setMessages([...messages, { input, data }]);
    setInput('');
  };

  return (
    <div className="app">
      <h1>Agent + MCP Demo</h1>
      <div className="chat">
        {messages.map((m, i) => (
          <div key={i} className="msg">
            <div><b>User:</b> {m.input}</div>
            <div><b>System:</b> {JSON.stringify(m.data)}</div>
          </div>
        ))}
      </div>
      <input value={input} onChange={e => setInput(e.target.value)} />
      <button onClick={send}>Send</button>
    </div>
  );
}

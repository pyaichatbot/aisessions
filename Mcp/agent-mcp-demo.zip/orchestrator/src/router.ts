import { callLLM } from "./llm";
import { runAgent } from "./agent";

export async function router(message: string) {
  // Simple rule: if contains "file" or "search" -> agent, else -> llm
  if (/file|search|grep/i.test(message)) {
    return await runAgent(message);
  } else {
    return await callLLM(message);
  }
}

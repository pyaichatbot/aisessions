export async function callLLM(message: string) {
  // Placeholder: call OpenAI/Azure here. For demo return echo.
  return { mode: "llm", answer: `LLM response to: ${message}` };
}

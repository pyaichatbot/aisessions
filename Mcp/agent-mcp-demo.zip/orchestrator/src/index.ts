import express from "express";
import { router } from "./router";
import cors from "cors";

const app = express();
app.use(cors());
app.use(express.json());

app.post("/chat", async (req, res) => {
  const { message } = req.body;
  const result = await router(message);
  res.json(result);
});

app.listen(3000, () => {
  console.log("Orchestrator running on http://localhost:3000");
});

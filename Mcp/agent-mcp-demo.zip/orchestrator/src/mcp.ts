import { createClient } from "mcp-use";

export async function connect() {
  const client = await createClient({
    command: "python",
    args: ["mcp-server/server.py"],
  });
  return client;
}

export async function callTool(client: any, toolName: string, args: any) {
  return await client.callTool(toolName, args);
}

import asyncio
import json
import os
from typing import Any, Dict

import streamlit as st
from mcp_use import MCPClient

CONFIG_PATH = os.getenv("MCP_CONFIG_PATH", "config.json")
MCP_URL_ENV = os.getenv("MCP_HTTP_URL")  # Optional override

st.set_page_config(page_title="MCP Demo (fastmcp + mcp-use)", page_icon="🧰", layout="centered")
st.title("🧰 MCP Demo: fastmcp server + mcp-use client")
st.caption("Tools are discovered from the running FastMCP server over Streamable HTTP.")

# --- Helpers ---
def load_config() -> Dict[str, Any]:
    with open(CONFIG_PATH, "r") as f:
        cfg = json.load(f)
    if MCP_URL_ENV:
        # allow overriding the URL via env
        cfg["mcpServers"]["demo"]["url"] = MCP_URL_ENV.rstrip("/") + "/"
    return cfg

def run_async(coro):
    # Simple helper to run async in Streamlit's sync context
    return asyncio.run(coro)

@st.cache_resource
def get_client():
    cfg = load_config()
    return MCPClient.from_dict(cfg)

async def ensure_session(client: MCPClient):
    if not client.sessions:
        await client.create_all_sessions()
    return client.get_session("demo")

def get_tools_schema(tools_result) -> Dict[str, Any]:
    """Return {tool_name: {'description':..., 'schema':...}}"""
    tools_map: Dict[str, Any] = {}
    tools = getattr(tools_result, "tools", tools_result)  # be resilient to shape
    for t in tools:
        # Try common attribute names with fallbacks
        name = getattr(t, "name", None) or t.get("name")
        desc = getattr(t, "description", None) or t.get("description", "")
        params = getattr(t, "parameters", None) or getattr(t, "input_schema", None) or t.get("parameters") or t.get("input_schema")
        tools_map[name] = {"description": desc, "schema": params or {"type": "object", "properties": {}}}
    return tools_map

def render_inputs_for_schema(schema: Dict[str, Any]) -> Dict[str, Any]:
    props = (schema or {}).get("properties", {})
    required = set((schema or {}).get("required", []))
    args: Dict[str, Any] = {}
    for key, meta in props.items():
        typ = (meta or {}).get("type", "string")
        title = (meta or {}).get("title", key)
        default = (meta or {}).get("default", "")
        help_txt = (meta or {}).get("description", "")
        if typ in ("integer", "number"):
            val = st.number_input(title, value=int(default or 0), help=help_txt, step=1)
        elif typ == "boolean":
            val = st.checkbox(title, value=bool(default) if default != "" else False, help=help_txt)
        else:
            val = st.text_input(title, value=str(default), help=help_txt)
        if key in required and (val is None or val == ""):
            st.warning(f"'{key}' is required.")
        args[key] = val
    return args

def render_result(result):
    # mcp-use returns content blocks (text) and possibly structured_content
    text = None
    structured = None
    try:
        content = getattr(result, "content", None) or result.get("content")
        if content and isinstance(content, list):
            # concatenate any .text fields
            parts = []
            for c in content:
                if hasattr(c, "text"):
                    parts.append(getattr(c, "text"))
                elif isinstance(c, dict) and "text" in c:
                    parts.append(c["text"])
            text = "\n".join([p for p in parts if p])
    except Exception:
        pass
    try:
        structured = getattr(result, "structured_content", None) or result.get("structured_content")
    except Exception:
        pass

    if structured:
        st.subheader("Structured Output")
        st.json(structured)
    if text:
        st.subheader("Text Output")
        st.code(text)

# --- UI Logic ---
client = get_client()
session = run_async(ensure_session(client))
tools_result = run_async(session.list_tools())
tools_map = get_tools_schema(tools_result)

with st.sidebar:
    st.markdown("### Connection")
    st.write("Server URL:", load_config()["mcpServers"]["demo"]["url"])
    if st.button("🔄 Refresh tool list"):
        tools_result = run_async(session.list_tools())
        tools_map = get_tools_schema(tools_result)
        st.experimental_rerun()
    st.divider()
    st.caption("Tip: set env var `MCP_HTTP_URL` in Docker to point this UI at any MCP server.")

tool_names = sorted(tools_map.keys())
if not tool_names:
    st.error("No tools found on the server.")
    st.stop()

choice = st.selectbox("Choose a tool to call", tool_names, index=0)
st.caption(tools_map[choice]["description"] or "No description")

schema = tools_map[choice]["schema"]
args = render_inputs_for_schema(schema)

if st.button("▶️ Call Tool"):
    with st.status("Calling tool...", expanded=False) as status:
        try:
            result = run_async(session.call_tool(name=choice, arguments=args))
            status.update(label="Done", state="complete")
            render_result(result)
        except Exception as e:
            status.update(label="Error", state="error")
            st.exception(e)

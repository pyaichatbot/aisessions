# MCP Demo: FastMCP Server + mcp-use Client (Streamlit)

This is a minimal, **working** demo showing:

- A Python **FastMCP** server exposing a few tools over **Streamable HTTP** at `http://localhost:8000/mcp/`
- A Python **mcp-use** client with a **Streamlit UI** to discover tools and call them

## Run with Docker Compose

```bash
docker compose up --build
```

Then open: http://localhost:8501

## What you get

**Server tools** (see `server/server.py`):
- `add(a: int, b: int) -> int`
- `echo(text: str, uppercase: bool = False, repeat: int = 1) -> str`
- `time_now(fmt: str = "%Y-%m-%d %H:%M:%S", tz: Optional[str] = None) -> str`

**Endpoints**
- MCP (Streamable HTTP): `http://localhost:8000/mcp/`
- Health: `http://localhost:8000/healthz`

**Client**
- Uses `mcp-use` to connect over HTTP (supports Streamable HTTP & SSE)
- Dynamically lists tools and renders simple inputs based on each tool's JSON Schema
- Calls tools directly (no LLM required), and shows structured/text output

> Tip: To point the UI at another MCP server, set `MCP_HTTP_URL` env var on the `ui` service (or export locally).

## Local (without Docker)

### 1) Start the server

```bash
cd server
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python server.py
# Now serving MCP at http://localhost:8000/mcp/
```

### 2) Start the UI

```bash
cd ../client
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
export MCP_HTTP_URL=http://localhost:8000/mcp/
streamlit run streamlit_app.py
```

Open http://localhost:8501

## Notes

- This demo uses **Streamable HTTP** which is the recommended transport for remote MCP servers.
- If you prefer the legacy SSE transport, run the server with `mcp.run(transport="sse", ...)` and set the client URL to the SSE endpoint (commonly `/sse`), but Streamable HTTP is preferred for new projects.
- For a browser-only `index.html` UI you can use the **TypeScript** version of mcp-use (`mcp-use-ts`) – swap in a tiny Vite app and connect to the same HTTP endpoint.

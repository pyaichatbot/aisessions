from datetime import datetime, timezone
from typing import Optional
from fastmcp import FastMCP

# Simple FastMCP server exposing a few demo tools
mcp = FastMCP(name="demo-fastmcp-server")

@mcp.tool
def add(a: int, b: int) -> int:
    """Add two numbers and return the sum."""
    return a + b

@mcp.tool
def echo(text: str, uppercase: bool = False, repeat: int = 1) -> str:
    """Echo back the provided text. Optionally uppercase and repeat."""
    out = text.upper() if uppercase else text
    return " ".join([out] * max(1, repeat))

@mcp.tool
def time_now(fmt: str = "%Y-%m-%d %H:%M:%S", tz: Optional[str] = None) -> str:
    """Return the current server time. Provide strftime format string and optional timezone ('UTC' or empty for local)."""
    dt = datetime.now(timezone.utc if (tz or "").upper() == "UTC" else None)
    return dt.strftime(fmt)

# Optional: simple health endpoint for container checks
@mcp.http_route("/healthz")
async def healthz(request):
    from starlette.responses import JSONResponse
    return JSONResponse({"status": "ok"})

if __name__ == "__main__":
    # Expose Streamable HTTP transport (recommended). Endpoint: http://HOST:8000/mcp/
    # You can also switch to legacy SSE by using transport="sse".
    mcp.run(transport="http", host="0.0.0.0", port=8000)

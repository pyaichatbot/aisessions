
from fastapi import FastAPI, UploadFile, File
from fastapi import Body
from typing import List, Dict, Any
from pydantic import BaseModel
from .graph import APP
from .adapters import DualRetriever, simple_chunks, extract_text_from_upload

retriever = DualRetriever()
app = FastAPI(title="Agentic + Adaptive RAG (LangGraph)")

@app.post("/ingest")
async def ingest(files: List[UploadFile] = File(...)):
    total = 0
    for f in files:
        content = await f.read()
        text = extract_text_from_upload(f.filename, content)
        doc_id = f.filename.rsplit(".", 1)[0]
        chunks = simple_chunks(text, doc_id)
        retriever.upsert_chunks(chunks)
        total += len(chunks)
    return {"status":"ok", "chunks_indexed": total}

class QueryIn(BaseModel):
    query: str

@app.post("/query")
async def query(q: QueryIn):
    out = APP.invoke({"user_query": q.query})
    return {
        "intent": out.get("intent"),
        "route": out.get("route"),
        "eval": (out.get("eval_score").model_dump() if out.get("eval_score") else None),
        "final_answer": out.get("final_answer"),
        "needs_hitl": out.get("needs_hitl", False),
        "used_topk": (out.get("retrieval").topk if out.get("retrieval") else None)
    }

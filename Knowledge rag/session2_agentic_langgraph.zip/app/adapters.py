
from typing import List, Dict, Any
import os, re, io
import chromadb
from chromadb.config import Settings
from sentence_transformers import SentenceTransformer
from rank_bm25 import BM25Okapi
from pypdf import PdfReader

CHROMA_DIR = os.environ.get("CHROMA_DIR", "./chroma_db")
COLLECTION = "docs"

class DualRetriever:
    def __init__(self):
        self.client = chromadb.PersistentClient(path=CHROMA_DIR, settings=Settings(anonymized_telemetry=False))
        self.coll = self.client.get_or_create_collection(COLLECTION, metadata={"hnsw:space":"cosine"})
        self.embed = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")
        # mirror corpus for BM25
        self._bm25_tokens = []  # list[list[str]]
        self._bm25_docs = []    # raw text
        self._bm25_meta = []    # meta dicts

        # warm load existing docs (optional, best-effort)
        try:
            # pull a slice to init bm25 (Chroma pagination not exposed here; we rebuild on each ingest)
            pass
        except Exception:
            pass
        self._bm25 = None

    def upsert_chunks(self, chunks: List[Dict[str, Any]]):
        ids = [c["chunk_id"] for c in chunks]
        docs = [c["text"] for c in chunks]
        metas = [c["metadata"] | {"doc_id": c["doc_id"], "chunk_id": c["chunk_id"]} for c in chunks]
        embs = self.embed.encode(docs, normalize_embeddings=True).tolist()
        self.coll.upsert(ids=ids, documents=docs, metadatas=metas, embeddings=embs)

        # mirror for BM25
        toks = [re.findall(r"\w+", d.lower()) for d in docs]
        self._bm25_docs.extend(docs)
        self._bm25_tokens.extend(toks)
        self._bm25_meta.extend(metas)
        self._bm25 = BM25Okapi(self._bm25_tokens) if self._bm25_tokens else None

    def vector_search(self, q: str, k: int, filters: Dict[str, Any]) -> List[Dict[str, Any]]:
        qv = self.embed.encode([q], normalize_embeddings=True).tolist()
        res = self.coll.query(query_embeddings=qv, n_results=k, include=["documents","metadatas","distances"])
        out = []
        for i in range(len(res["ids"][0])):
            meta = res["metadatas"][0][i]
            out.append({
                "doc_id": meta["doc_id"],
                "chunk_id": meta["chunk_id"],
                "text": res["documents"][0][i],
                "metadata": meta,
                "distance": res["distances"][0][i]
            })
        return out

    def bm25_search(self, q: str, k: int) -> List[Dict[str, Any]]:
        if not self._bm25:
            return []
        toks = re.findall(r"\w+", q.lower())
        scores = self._bm25.get_scores(toks)
        idxs = sorted(range(len(scores)), key=lambda i: scores[i], reverse=True)[:k]
        out = []
        for i in idxs:
            meta = self._bm25_meta[i]
            out.append({
                "doc_id": meta["doc_id"],
                "chunk_id": meta["chunk_id"],
                "text": self._bm25_docs[i],
                "metadata": meta,
                "bm25_score": float(scores[i])
            })
        return out

    def hybrid_search(self, q: str, k: int, filters: Dict[str, Any]) -> List[Dict[str, Any]]:
        a = self.vector_search(q, k, filters)
        b = self.bm25_search(q, k)
        # simple fusion: interleave unique by chunk_id
        seen = set()
        fused = []
        for lst in (a, b):
            for it in lst:
                if it["chunk_id"] in seen: 
                    continue
                seen.add(it["chunk_id"])
                fused.append(it)
                if len(fused) >= k:
                    break
            if len(fused) >= k:
                break
        return fused

def simple_chunks(text: str, doc_id: str, size: int = 700, overlap: int = 100):
    words = re.split(r"(\s+)", text)
    chunks = []
    buf = []
    token_count = 0
    i = 0
    chunk_id = 0
    while i < len(words):
        w = words[i]
        buf.append(w)
        token_count += len(w)
        if token_count >= size:
            start = max(0, i - overlap)
            chunk_text = "".join(buf).strip()
            if chunk_text:
                chunks.append({
                    "doc_id": doc_id,
                    "chunk_id": f"{doc_id}::c{chunk_id}",
                    "text": chunk_text,
                    "metadata": {"seq": chunk_id}
                })
                chunk_id += 1
            buf = words[start:i]
            token_count = sum(len(x) for x in buf)
        i += 1
    tail = "".join(buf).strip()
    if tail:
        chunks.append({
            "doc_id": doc_id,
            "chunk_id": f"{doc_id}::c{chunk_id}",
            "text": tail,
            "metadata": {"seq": chunk_id}
        })
    return chunks

def extract_text_from_upload(filename: str, content: bytes) -> str:
    if filename.lower().endswith(".pdf"):
        reader = PdfReader(io.BytesIO(content))
        text = ""
        for p in reader.pages:
            text += (p.extract_text() or "") + "\n"
        return text
    return content.decode("utf-8", errors="ignore")

def llm_infer(prompt: str, temperature: float = 0.2) -> str:
    import re
    keys = re.findall(r'\[(.+?::c\d+)\]', prompt)
    cite = f"[{keys[0]}]" if keys else ""
    return f"""- (demo) Agentic pipeline stub response citing {cite}.
- Replace llm_infer() with a real LLM provider in production."""

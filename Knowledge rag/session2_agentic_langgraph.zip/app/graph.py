
from typing import TypedDict, List, Dict, Any
from pydantic import BaseModel
from langgraph.graph import StateGraph, END
from .adapters import DualRetriever, llm_infer

class Chunk(BaseModel):
    doc_id: str
    chunk_id: str
    text: str
    metadata: Dict[str, Any] = {}

class RetrievalResult(BaseModel):
    query: str
    topk: int
    chunks: List[Chunk]
    strategy: str

class EvalScore(BaseModel):
    groundedness: float
    consistency: float
    overall: float
    notes: str

class PipelineState(TypedDict, total=False):
    user_query: str
    intent: str
    route: str
    retrieval: RetrievalResult
    draft_answer: str
    citations: List[Dict[str, str]]
    eval_score: EvalScore
    final_answer: str
    needs_hitl: bool
    _refine_done: bool

LOW_CONF = 0.72
DEFAULT_TOPK = 6

retriever = DualRetriever()

def classify_intent(query: str) -> str:
    q = query.lower()
    if any(w in q for w in ["invoice", "scan", "image", "photo", "ocr"]):
        return "OCR_DOC"
    if any(w in q for w in ["price", "number", "percentage", "date", "id"]):
        return "NUMERIC"
    if any(w in q for w in ["comply", "policy", "regulation", "gdpr"]):
        return "POLICY"
    if any(w in q for w in ["how do i", "steps", "procedure"]):
        return "HOWTO"
    if any(w in q for w in ["def", "class", "function", "error", "stacktrace"]):
        return "CODE"
    if len(q.split()) <= 8:
        return "FAQ"
    return "GENERAL"

def adaptive_route(state: PipelineState) -> str:
    intent = classify_intent(state["user_query"])
    state["intent"] = intent
    route = {
        "FAQ": "bm25",
        "HOWTO": "hybrid",
        "NUMERIC": "hybrid",
        "POLICY": "vector",
        "CODE": "hybrid",
        "OCR_DOC": "vector",
        "GENERAL": "vector",
    }[intent]
    state["route"] = route
    return route

def retrieve_node(state: PipelineState) -> PipelineState:
    route = state["route"]
    q = state["user_query"]
    if route == "bm25":
        chunks = retriever.bm25_search(q, DEFAULT_TOPK)
    elif route == "vector":
        chunks = retriever.vector_search(q, DEFAULT_TOPK, {})
    else:  # hybrid
        chunks = retriever.hybrid_search(q, DEFAULT_TOPK, {})
    chunks = [Chunk(**c) for c in chunks]
    state["retrieval"] = RetrievalResult(query=q, topk=len(chunks), chunks=chunks, strategy=route)
    return state

ANSWER_PROMPT = """You are a careful assistant.
Only answer using the provided CONTEXT. If not answerable, say 'I don't have enough information.'
Always cite as [doc_id::chunk_id] after each claim.

QUESTION:
{q}

CONTEXT:
{ctx}

Now produce a concise, well-structured answer with bullet points and citations."""

def draft_node(state: PipelineState) -> PipelineState:
    ctx = "\n---\n".join(f"[{c.doc_id}::{c.chunk_id}] {c.text}" for c in state["retrieval"].chunks)
    prompt = ANSWER_PROMPT.format(q=state["user_query"], ctx=ctx)
    ans = llm_infer(prompt, temperature=0.2)
    state["draft_answer"] = ans
    cites = []
    for c in state["retrieval"].chunks:
        key = f"{c.doc_id}::{c.chunk_id}"
        if key in ans:
            cites.append({"doc_id": c.doc_id, "chunk_id": c.chunk_id})
    state["citations"] = cites
    return state

def evaluate_node(state: PipelineState) -> PipelineState:
    import re
    ans = state["draft_answer"]
    sents = [s for s in re.split(r'(?<=[.?!])\s+', ans) if s.strip()]
    cited = sum(1 for s in sents if "[" in s and "]" in s)
    grounded = cited / max(1, len(sents))
    # simple consistency stub
    overall = 0.6*grounded + 0.4*0.7
    state["eval_score"] = EvalScore(groundedness=grounded, consistency=0.7, overall=overall, notes="heuristic")
    return state

def refine_node(state: PipelineState) -> PipelineState:
    q = state["user_query"]
    expanded = retriever.hybrid_search(q, DEFAULT_TOPK+6, {})
    chunks = [Chunk(**c) for c in expanded]
    state["retrieval"] = RetrievalResult(query=q, topk=len(chunks), chunks=chunks, strategy="hybrid+refine")
    return draft_node(state)

def hitl_node(state: PipelineState) -> PipelineState:
    state["needs_hitl"] = True
    state["final_answer"] = "Low confidence. Escalated for human review."
    return state

def finalize_node(state: PipelineState) -> PipelineState:
    if not state.get("final_answer"):
        state["final_answer"] = state["draft_answer"]
    return state

def build_graph():
    graph = StateGraph(PipelineState)

    graph.add_node("retrieve", retrieve_node)
    graph.add_node("draft", draft_node)
    graph.add_node("evaluate", evaluate_node)
    graph.add_node("refine", refine_node)
    graph.add_node("hitl", hitl_node)
    graph.add_node("finalize", finalize_node)

    def start_decider(s: PipelineState):
        adaptive_route(s)
        return "retrieve"

    start = graph.add_node("start", lambda s: s)
    graph.add_conditional_edges(start, start_decider, {"retrieve": "retrieve"})

    graph.add_edge("retrieve", "draft")
    graph.add_edge("draft", "evaluate")

    def eval_branch(s: PipelineState):
        score = s["eval_score"].overall
        if score >= 0.72:
            return "finalize"
        if s.get("_refine_done"):
            return "hitl"
        s["_refine_done"] = True
        return "refine"

    graph.add_conditional_edges("evaluate", eval_branch, {
        "finalize": "finalize",
        "refine": "refine",
        "hitl": "hitl",
    })

    graph.add_edge("refine", "evaluate")
    graph.add_edge("finalize", END)
    graph.add_edge("hitl", END)

    return graph.compile()

APP = build_graph()

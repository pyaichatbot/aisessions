
# Session 2 — Agentic & Adaptive RAG with LangGraph

This service exposes a `/query` endpoint that runs an **adaptive + corrective** RAG pipeline orchestrated by **LangGraph**.
It demonstrates:
- Intent classification → **adaptive routing** (bm25/vector/hybrid)
- Retrieval → draft → evaluate → **corrective refine** → finalize / HITL
- Optional OCR route (stub).

## Quickstart
```bash
docker build -t agentic-langgraph:latest .
docker run -p 8002:8002 -v $(pwd)/chroma_db:/app/chroma_db agentic-langgraph:latest

# Ingest a couple of docs (uses the same simple ingestion as Session 1—run that first or use the helper here)
curl -X POST http://localhost:8002/ingest -F "files=@sample_docs/policy.txt" -F "files=@sample_docs/guide.txt"

# Query
curl -X POST http://localhost:8002/query -H "Content-Type: application/json" -d '{"query":"What are the password rules?"}'
```

## Notes
- Vector: Chroma + `all-MiniLM-L6-v2`
- BM25: in-memory using `rank_bm25` over the same chunks (mirrored from Chroma)
- Replace `llm_infer()` with your production LLM; plug OCR into `adapters.py` if needed.

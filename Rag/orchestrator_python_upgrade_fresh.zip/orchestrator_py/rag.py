import os, httpx

RAG_URL = os.getenv("RAG_SERVICE_URL", "http://rag-service:8000")

def rag_query(question: str, k: int = 4):
    try:
        r = httpx.post(f"{RAG_URL}/query", json={"question": question, "k": k}, timeout=30.0)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        return {"hits": [], "error": str(e)}

def synthesize_from_chunks(question: str, hits):
    bullets = []
    for h in hits or []:
        score = h.get("score", 0.0)
        path = (h.get("path","").split("/") or [""])[-1]
        chunk = h.get("chunk", 0)
        text = (h.get("text","") or "")[:180].replace("\n"," ")
        bullets.append(f"• ({score:.3f}) {path}#{chunk}: {text}...")
    return f"Answer synthesized for: '{question}'\n" + "\n".join(bullets)

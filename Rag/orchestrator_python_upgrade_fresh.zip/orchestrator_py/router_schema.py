from pydantic import BaseModel, Field
from typing import Optional, Dict, Literal

class RouterResponse(BaseModel):
    route: Literal["rag", "mcp_gitlab", "mcp_files", "llm"]
    reason: str
    tool: Optional[str] = None
    args: Optional[Dict] = None
    confidence: float = Field(1.0, ge=0, le=1)
    pii_risk: Literal["low", "medium", "high"] = "low"
    citations_needed: bool = False

import os
from router_schema import RouterResponse
from llm_router import llm_route
from rag import rag_query, synthesize_from_chunks
from llm import call_llm
from mcp_client import call_files_tool, call_gitlab_tool

ALLOWED = [x.strip() for x in os.getenv("ALLOWED_PROJECTS","").split(",") if x.strip()]

def route_message(message: str):
    events = [{"type": "plan", "data": {"message": message}}]

    decision: RouterResponse = llm_route(message)
    events.append({"type": "router_decision", "data": decision.dict()})

    # Policy enforcement
    if decision.route == "mcp_gitlab":
        pid = str((decision.args or {}).get("project_id",""))
        if ALLOWED and pid not in ALLOWED:
            events.append({"type":"policy_block", "data":{"reason":"project not allowlisted", "pid": pid}})
            decision = RouterResponse(route="llm", reason="policy_fallback", confidence=1.0)

    if decision.route == "rag":
        q = (decision.args or {}).get("query_rewrite", message)
        k = int((decision.args or {}).get("k", 4))
        rag = rag_query(q, k)
        events.append({"type": "retrieval_result", "data": rag})
        answer = synthesize_from_chunks(message, rag.get("hits", []))
        events.append({"type": "final", "data": {"answer": answer}})
        return {"mode": "agent_rag", "events": events, "answer": answer}

    if decision.route == "mcp_files":
        tool = decision.tool or ("grep_text" if "grep" in message.lower() else "list_files")
        args = decision.args or ({"path":"./rag-service/data"} if tool=="list_files" else {})
        res = call_files_tool(tool, args)
        events.append({"type":"tool_result","data":{"tool":tool,"args":args,"result":res}})
        answer = call_llm(f"Summarize Files {tool}: {str(res)[:800]}")
        events.append({"type":"final","data":{"answer":answer}})
        return {"mode":"agent_mcp_files","events":events,"answer":answer}

    if decision.route == "mcp_gitlab":
        tool = decision.tool or "gitlab_search_code"
        args = decision.args or {}
        if tool == "gitlab_search_code":
            args.setdefault("query","login")
            args.setdefault("ref","main")
        res = call_gitlab_tool(tool, args)
        events.append({"type":"tool_result","data":{"tool":tool,"args":args,"result":res}})
        answer = call_llm(f"Summarize GitLab {tool}: {str(res)[:1000]}")
        events.append({"type":"final","data":{"answer":answer}})
        return {"mode":"agent_mcp_gitlab","events":events,"answer":answer}

    answer = call_llm(message)
    events.append({"type":"final","data":{"answer":answer}})
    return {"mode":"llm","events":events,"answer":answer}

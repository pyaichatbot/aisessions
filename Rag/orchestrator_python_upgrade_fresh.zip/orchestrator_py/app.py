from fastapi import FastAPI
from pydantic import BaseModel
from router import route_message

app = FastAPI(title="Python Orchestrator (Agentic RAG)", version="1.0.0")

class ChatIn(BaseModel):
    message: str

@app.post("/chat")
def chat(payload: ChatIn):
    return route_message(payload.message)

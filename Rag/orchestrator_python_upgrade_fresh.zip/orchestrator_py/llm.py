import os

def call_llm(prompt: str) -> str:
    # Heuristic fallback synthesizer to avoid hard failure without API keys
    key = os.getenv("OPENAI_API_KEY")
    if not key:
        return f"Heuristic summary: {prompt[:600]}"
    try:
        from openai import OpenAI
        client = OpenAI(api_key=key)
        resp = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "Summarize or answer concisely."},
                {"role": "user", "content": prompt},
            ],
            temperature=0,
            max_tokens=300,
        )
        return resp.choices[0].message.content
    except Exception as e:
        return f"Heuristic summary (LLM error: {e}): {prompt[:600]}"

import os, json, re
from router_schema import RouterResponse

SYSTEM_PROMPT = """You are a routing controller.
Choose one path: rag | mcp_gitlab | mcp_files | llm.
Constraints:
- Only use allowed GitLab project_ids: {allowed_projects}.
- Never request write operations.
- If query is about policy/docs -> rag.
- If query mentions MR, diff, pipeline, repo/project -> mcp_gitlab.
- If query mentions local files/paths/grep -> mcp_files.
- Otherwise -> llm.
Return ONLY valid JSON with keys:
route, reason, tool (if MCP), args (if MCP), confidence, pii_risk, citations_needed.
"""

def _heuristic_route(message: str) -> RouterResponse:
    lower = message.lower()
    if any(k in lower for k in ["policy", "document", "onboarding", "guidelines", "summarize"]):
        return RouterResponse(route="rag", reason="policy/docs intent", confidence=0.8)
    if any(k in lower for k in ["mr", "merge request", "pipeline", "repo", "project", "diff", "gitlab"]):
        args = {}
        m = re.search(r"project\s+(\d+)", lower)
        if m: args["project_id"] = int(m.group(1))
        return RouterResponse(route="mcp_gitlab", reason="gitlab intent", tool="gitlab_search_code", args=args, confidence=0.75)
    if any(k in lower for k in ["list", "read", "grep", "file"]):
        return RouterResponse(route="mcp_files", reason="files intent", tool="list_files", args={"path":"./rag-service/data"}, confidence=0.7)
    return RouterResponse(route="llm", reason="general question", confidence=0.6)

def llm_route(message: str) -> RouterResponse:
    key = os.getenv("OPENAI_API_KEY")
    allowed = os.getenv("ALLOWED_PROJECTS", "")
    if not key:
        return _heuristic_route(message)

    try:
        from openai import OpenAI
        client = OpenAI(api_key=key)
        prompt = SYSTEM_PROMPT.format(allowed_projects=allowed)
        resp = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role":"system","content":prompt},
                {"role":"user","content":message}
            ],
            temperature=0,
            response_format={"type":"json_object"},
            max_tokens=300
        )
        content = resp.choices[0].message.content
        data = json.loads(content)
        parsed = RouterResponse(**data)
    except Exception:
        return _heuristic_route(message)

    if parsed.route == "mcp_gitlab":
        pid = str(parsed.args.get("project_id", "")) if parsed.args else ""
        if allowed and pid and pid not in [x.strip() for x in allowed.split(",")]:
            return RouterResponse(route="llm", reason="project not allowlisted", confidence=1.0)

    return parsed

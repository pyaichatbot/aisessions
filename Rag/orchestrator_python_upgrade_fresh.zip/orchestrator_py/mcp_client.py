import asyncio
from typing import Any, Dict
from mcp.client.stdio import StdioClient

class MCPToolClient:
    def __init__(self, command: str, args: list[str]):
        self.command = command
        self.args = args
        self.client: StdioClient | None = None

    async def _ensure(self):
        if self.client is None:
            self.client = StdioClient(self.command, self.args)
            await self.client.start()

    async def call_tool_async(self, tool: str, args: Dict[str, Any]) -> Any:
        await self._ensure()
        return await self.client.call_tool(tool, args)

def call_files_tool(tool: str, args: Dict[str, Any]):
    return asyncio.run(_call("python", ["mcp-server/server.py"], tool, args))

def call_gitlab_tool(tool: str, args: Dict[str, Any]):
    return asyncio.run(_call("python", ["mcp-gitlab/server_gitlab.py"], tool, args))

async def _call(cmd: str, argv: list[str], tool: str, args: Dict[str, Any]):
    c = MCPToolClient(cmd, argv)
    return await c.call_tool_async(tool, args)

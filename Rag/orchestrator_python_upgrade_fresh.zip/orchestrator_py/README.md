# Python Orchestrator (LLM Router + MCP + RAG) — Fresh Build

Drop-in replacement for the Node/TS orchestrator from **Session 8 – Enterprise**.
Runs a **FastAPI** app with an **LLM-assisted, policy-aware router** and calls:
- **RAG service** (HTTP) – Chroma + Sentence-Transformers.
- **MCP servers** (stdio) – files-mcp and gitlab-mcp, spawned inside this container.

## Quick Start (use inside your session8-agentic-rag-enterprise project)

1) Place this `orchestrator_py/` folder at the project root alongside:
```
mcp-server/
mcp-gitlab/
rag-service/
frontend/
orchestrator_py/   <-- this folder
```
2) Edit your `docker-compose.yml` to point the orchestrator service here:
```yaml
  orchestrator:
    build: ./orchestrator_py
    container_name: orchestrator
    environment:
      - RAG_SERVICE_URL=${RAG_SERVICE_URL}
      - OPENAI_API_KEY=${OPENAI_API_KEY}
      - GITLAB_URL=${GITLAB_URL}
      - GITLAB_TOKEN=${GITLAB_TOKEN}
      - ALLOWED_PROJECTS=${ALLOWED_PROJECTS}
    depends_on:
      - rag-service
      - mcp-server
      - mcp-gitlab
    ports:
      - "3000:3000"
```
3) Build & run everything:
```bash
docker compose --env-file .env up --build
```
4) Test:
```bash
# RAG
curl -s http://localhost:3000/chat -H "Content-Type: application/json"   -d '{"message":"Summarize the onboarding policy"}' | jq

# GitLab (ensure project 123 is allowlisted in .env)
curl -s http://localhost:3000/chat -H "Content-Type: application/json"   -d '{"message":"search code for login in project 123"}' | jq

# Files MCP
curl -s http://localhost:3000/chat -H "Content-Type: application/json"   -d '{"message":"list files under ./rag-service/data"}' | jq
```

**Note:** If `OPENAI_API_KEY` is not set, the router & summarizer fall back to heuristics (still demoable).

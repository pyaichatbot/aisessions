# SIM Agentic RAG – Streaming Demo (UI + SSE)

This package implements an **Agentic RAG** pipeline with streaming UI updates:
Planner → Retriever (vector) → SQLAgent → Synthesizer (LLM).

> For simplicity, this build does **not** require the SIM framework; it mirrors a SIM-style multi-agent orchestration.
> If you want native SIM integration, we can add it — the UI will work the same.

## Run
1) Configure:
```bash
cp .env.example .env
# Set LLM_API_BASE + LLM_API_KEY for your self-hosted GPT (OpenAI-compatible)
```
2) Build & start:
```bash
docker compose up --build
```
3) Open the UI: http://localhost:8000
- Upload PDF/TXT (left top)
- Choose **Agentic** (streaming) or **Direct**
- Ask: “What are Fiserv USA and Germany data retention & OTP/SCA rules?”

## Endpoints
- `POST /ingest/file` (multipart, header: x-api-token)
- `POST /query` (direct vector mode)
- `GET /agent/stream?question=...&token=demo-token` (streaming SSE)
- `GET /health`

## Data
- `data/policies.db` seeded with Fiserv USA & Germany rules on first run.
- Vector DB persists in docker volume `rag_db`.

Enjoy the show! 🎬

from typing import List, Dict

def generate_answer(question: str, passages: List[Dict]) -> str:
    joined = "\n\n".join([p["chunk"] for p in passages])
    answer = (
        f"Question: {question}\n"
        f"Answer (grounded):\n"
        f"{joined[:1200]}\n\n"
        f"(Answer generated from the retrieved context above.)"
    )
    return answer

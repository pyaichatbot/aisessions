import os, re, hashlib
from typing import List, Tuple
from pypdf import PdfReader

def read_text_from_path(path: str) -> str:
    if path.lower().endswith(('.txt', '.md')):
        with open(path, 'r', encoding='utf-8', errors='ignore') as f:
            return f.read()
    if path.lower().endswith('.pdf'):
        text = []
        try:
            reader = PdfReader(path)
            for page in reader.pages:
                text.append(page.extract_text() or "")
        except Exception:
            return ""
        return "\n".join(text)
    return ""

def iter_corpus_files(root: str):
    for dirpath, _, filenames in os.walk(root):
        for fn in filenames:
            if fn.lower().endswith(('.txt', '.md', '.pdf')):
                yield os.path.join(dirpath, fn)

def chunk_text(text: str, max_chars: int = 1200, overlap: int = 200) -> List[str]:
    sents = re.split(r'(?<=[.!?])\s+', text.strip())
    chunks = []
    buf = ""
    for s in sents:
        if len(buf) + len(s) + 1 <= max_chars:
            buf = (buf + " " + s).strip()
        else:
            if buf:
                chunks.append(buf)
            if overlap > 0 and buf:
                tail = buf[-overlap:]
                buf = (tail + " " + s).strip()
            else:
                buf = s
    if buf:
        chunks.append(buf)
    return [c.strip() for c in chunks if c.strip()]

def chunk_hash(text: str) -> str:
    return hashlib.sha1(text.encode('utf-8')).hexdigest()

import os, json
import numpy as np
from typing import List, Dict, Tuple

class FloatStore:
    def __init__(self, store_dir: str):
        self.dir = store_dir
        os.makedirs(self.dir, exist_ok=True)
        self.meta_path = os.path.join(self.dir, "float_meta.json")
        self.vec_path = os.path.join(self.dir, "float_vectors.npy")
        self._meta = []
        self._vecs = None

    def add(self, metas: List[Dict], vectors: np.ndarray):
        if os.path.exists(self.meta_path):
            with open(self.meta_path, 'r', encoding='utf-8') as f:
                self._meta = json.load(f)
        else:
            self._meta = []
        if os.path.exists(self.vec_path):
            self._vecs = np.load(self.vec_path)
            self._vecs = np.vstack([self._vecs, vectors])
        else:
            self._vecs = vectors
        self._meta.extend(metas)
        np.save(self.vec_path, self._vecs)
        with open(self.meta_path, 'w', encoding='utf-8') as f:
            json.dump(self._meta, f, ensure_ascii=False, indent=2)

    def load(self):
        with open(self.meta_path, 'r', encoding='utf-8') as f:
            self._meta = json.load(f)
        self._vecs = np.load(self.vec_path)

    def search(self, query_vec: np.ndarray, top_k: int = 5):
        sims = (self._vecs @ query_vec)
        idx = np.argsort(-sims)[:top_k]
        return [(self._meta[i], float(sims[i])) for i in idx]

from sentence_transformers import SentenceTransformer
import numpy as np
from typing import List

_EMBED_MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"
_model = None

def get_embedder():
    global _model
    if _model is None:
        _model = SentenceTransformer(_EMBED_MODEL_NAME)
    return _model

def embed_texts(texts: List[str]) -> np.ndarray:
    model = get_embedder()
    vecs = model.encode(texts, convert_to_numpy=True, normalize_embeddings=True)
    return vecs.astype(np.float32)

def floats_to_binary_codes(vectors: np.ndarray) -> np.ndarray:
    signs = (vectors >= 0).astype(np.uint8)
    packed = np.packbits(signs, axis=1)
    return packed

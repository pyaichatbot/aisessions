import os, json
import numpy as np

class BinaryStore:
    def __init__(self, store_dir: str):
        self.dir = store_dir
        os.makedirs(self.dir, exist_ok=True)
        self.meta_path = os.path.join(self.dir, "binary_meta.json")
        self.bin_path = os.path.join(self.dir, "binary_codes.npy")
        self._meta = []
        self._bins = None

    def add(self, metas, packed_codes):
        if os.path.exists(self.meta_path):
            with open(self.meta_path, 'r', encoding='utf-8') as f:
                self._meta = json.load(f)
        else:
            self._meta = []
        if os.path.exists(self.bin_path):
            self._bins = np.load(self.bin_path)
            self._bins = np.vstack([self._bins, packed_codes])
        else:
            self._bins = packed_codes
        self._meta.extend(metas)
        np.save(self.bin_path, self._bins)
        with open(self.meta_path, 'w', encoding='utf-8') as f:
            json.dump(self._meta, f, ensure_ascii=False, indent=2)

    def load(self):
        with open(self.meta_path, 'r', encoding='utf-8') as f:
            self._meta = json.load(f)
        self._bins = np.load(self.bin_path)

    def search(self, query_bin, top_k: int = 5):
        popcnt = np.array([bin(i).count("1") for i in range(256)], dtype=np.uint8)
        dists = []
        step = 4096
        for start in range(0, self._bins.shape[0], step):
            block = self._bins[start:start+step]
            xor = np.bitwise_xor(block, query_bin)
            pc = popcnt[xor].sum(axis=1)
            dists.append(pc)
        dists = np.concatenate(dists)
        idx = np.argsort(dists)[:top_k]
        return [(self._meta[i], int(dists[i])) for i in idx]

# RAG + Binary Quantization + Reranking Demo

Production-quality, minimal demo showing four query modes:

- **naive**: standard RAG (embed query → retrieve float vectors → answer)
- **hyde**: HyDE RAG (LLM drafts hypothetical answer → embed → retrieve → answer)
- **bq**: fast retrieval using Binary Quantized (1-bit) embeddings with Hamming distance
- **bq_rerank**: BQ retrieval (top-20) → **cross-encoder reranking** → answer

> Embeddings: `sentence-transformers/all-MiniLM-L6-v2` (384d)  
> Reranker: `cross-encoder/ms-marco-MiniLM-L-6-v2`  
> LLM for HyDE: pluggable (Azure/OpenAI-style). If not configured, HyDE falls back to a lightweight local heuristic (uses the query).

## Setup

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## Quickstart (CLI)

1) Put your documents (PDF/TXT/MD) under `./corpus/` (nested folders ok).  
2) Build indexes (float + binary):

```bash
python scripts/ingest.py --corpus ./corpus --out ./store
```

3) Ask questions (choose a mode):

```bash
python scripts/query.py --store ./store --question "How do I open a savings account?" --mode naive
python scripts/query.py --store ./store --question "How do I open a savings account?" --mode hyde
python scripts/query.py --store ./store --question "How do I open a savings account?" --mode bq
python scripts/query.py --store ./store --question "How do I open a savings account?" --mode bq_rerank
```

The script prints: top chunks with scores, final answer, and citations.

## FastAPI (optional)

Run an API:

```bash
uvicorn app.main:app --reload
```

- `POST /ingest`  (body: `{ "corpus_dir": "./corpus", "store_dir": "./store" }`)
- `POST /query`   (body: `{ "store_dir": "./store", "question": "...", "mode": "naive|hyde|bq|bq_rerank" }`)

## HyDE LLM Configuration

Set **one** of the following environment variables for HyDE generation:

- `AZURE_OPENAI_ENDPOINT`, `AZURE_OPENAI_API_KEY`, `AZURE_OPENAI_DEPLOYMENT`  
- or `OPENAI_API_KEY`, `OPENAI_MODEL`

If not set, HyDE falls back to using the raw query text as the hypothetical document (still helpful for demo).

## Notes

- **Binary Quantization** packs the sign of each embedding dimension into 1 bit and uses **Hamming distance** for retrieval.  
- **Trade-off**: 32× smaller memory, *slightly* lower recall. **Reranking** recovers precision.
- Designed for clarity and portability — no FAISS/Milvus requirement; pure NumPy implementation.

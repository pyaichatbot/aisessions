import os, argparse
from typing import List, Dict
from app.embeddings import embed_texts, floats_to_binary_codes
from app.store_float import FloatStore
from app.store_binary import BinaryStore
from app.reranker import rerank
from app.hyde import draft_hypothetical_answer
from app.generator import generate_answer

def collect_passages(results) -> List[Dict]:
    return [ {**m, "score": s} for (m, s) in results ]

def print_results(tag: str, results):
    print(f"\n=== {tag} ===")
    for i, (meta, score) in enumerate(results, 1):
        snip = meta['chunk'][:120].replace('\n',' ')
        try:
            s_str = f"{score:.4f}"
        except Exception:
            s_str = str(score)
        print(f"{i:>2}. score={s_str} | {meta['doc_path']}#{meta['chunk_id']} :: {snip}...")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--store", required=True)
    ap.add_argument("--question", required=True)
    ap.add_argument("--mode", choices=["naive","hyde","bq","bq_rerank"], default="naive")
    ap.add_argument("--k", type=int, default=5)
    ap.add_argument("--candidates", type=int, default=20)
    args = ap.parse_args()

    if args.mode in ("naive","hyde"):
        fs = FloatStore(args.store); fs.load()
        query = args.question
        if args.mode == "hyde":
            hypo = draft_hypothetical_answer(query)
            print("\n[HyDE] hypothetical answer:\n", hypo, "\n")
            query = hypo
        qv = embed_texts([query])[0]
        results = fs.search(qv, top_k=max(args.k, args.candidates))
        print_results(args.mode.upper() + " (float) retrieval", results[:args.k])
        top_passages = collect_passages(results[:args.k])
        print("\n--- Grounded Answer ---")
        print(generate_answer(args.question, top_passages))
        print("\nCitations:")
        for r in top_passages:
            print(f"- {r['doc_path']}#{r['chunk_id']} (score={r['score']})")

    elif args.mode in ("bq","bq_rerank"):
        bs = BinaryStore(args.store); bs.load()
        fs = FloatStore(args.store); fs.load()
        qv = embed_texts([args.question])[0].reshape(1,-1)
        qb = floats_to_binary_codes(qv)[0].reshape(1,-1)
        results = bs.search(qb, top_k=max(args.k, args.candidates))
        print_results("BQ (binary) retrieval", results[:args.k])

        if args.mode == "bq_rerank":
            metas = [m for (m, _) in results[:args.candidates]]
            passages = [m['chunk'] for m in metas]
            reranked = rerank(args.question, passages, top_k=args.k)
            final = []
            for idx, score in reranked:
                meta = metas[idx]
                final.append((meta, score))
            print_results("RERANKED (cross-encoder)", final)
            top_passages = collect_passages(final)
        else:
            top_passages = collect_passages(results[:args.k])

        print("\n--- Grounded Answer ---")
        print(generate_answer(args.question, top_passages))
        print("\nCitations:")
        for r in top_passages:
            print(f"- {r['doc_path']}#{r['chunk_id']} (score={r['score']})")

if __name__ == "__main__":
    main()

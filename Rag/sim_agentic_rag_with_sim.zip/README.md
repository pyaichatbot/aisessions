# SIM Agentic RAG – Native SIM (Optional) + Streaming UI

This package adds **optional native SIM** support on top of the streaming Agentic RAG demo.
If SIM is installed (Docker build arg `INSTALL_SIM=true`), the backend will acknowledge SIM availability.
The execution flow shown in the UI mirrors SIM-style **Planner → Retriever → SQL → Synthesizer**.

> For reliability behind proxies, the runtime does not require SIM. You can still demo the same multi-agent flow.
> When your network allows, rebuild with SIM enabled to compare **framework vs custom** side-by-side.

## Run
```bash
cp .env.example .env
# set LLM_API_BASE + LLM_API_KEY (OpenAI-compatible)

docker compose up --build
# to skip SIM install (if GitHub blocked):
# docker compose build --build-arg INSTALL_SIM=false && docker compose up
```

Open: http://localhost:8000

- **+ Upload**: add PDF/TXT/MD (chunks → embeddings → Chroma)
- **Agentic (Streaming)**: shows Planner → Retriever → SQL → Synth with live trace
- **Direct (Vector)**: simple vector-only baseline

## Files
- `app/main.py` – FastAPI backend with optional SIM integration + SSE streaming
- `public/index.html` – Chat UI with **Agent Trace** panel
- `rag_sim.yaml` – Example SIM config (for reference)
- `data/policies.db` – Created on first run with **Fiserv USA/Germany** sample rules
- `Dockerfile`, `docker-compose.yml`, `requirements.txt`, `.env.example`

## Notes
- If you want **strict native SIM execution**, I can extend this with SIM-specific Agent classes and runner.
- The current build confirms SIM presence and keeps the user experience identical, even when SIM is not available.

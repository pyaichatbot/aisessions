import os, json, asyncio, sqlite3
from typing import Optional
from fastapi import FastAPI, UploadFile, File, Form, HTTPException, Depends, Header
from fastapi.staticfiles import StaticFiles
from sse_starlette.sse import EventSourceResponse
from pydantic import BaseModel
from dotenv import load_dotenv
import fitz
import chromadb
from chromadb.config import Settings
from sentence_transformers import SentenceTransformer
import numpy as np
import requests
import yaml

load_dotenv()

API_TOKEN = os.getenv("RAG_API_TOKEN","demo-token")
EMB_MODEL = os.getenv("EMBEDDING_MODEL","all-MiniLM-L6-v2")
LLM_API_BASE = os.getenv("LLM_API_BASE")
LLM_API_KEY = os.getenv("LLM_API_KEY")
LLM_API_VERSION = os.getenv("LLM_API_VERSION","2023-06-01")

# Optional SIM import
SIM_ENABLED=False
try:
    import sim  # type: ignore
    SIM_ENABLED=True
except Exception:
    SIM_ENABLED=False

PERSIST="./vectordb"; COLL="docs"
client = chromadb.PersistentClient(path=PERSIST, settings=Settings(anonymized_telemetry=False))
coll = client.get_or_create_collection(COLL)
embedder = SentenceTransformer(EMB_MODEL)

SQLITE="./data/policies.db"
os.makedirs("data", exist_ok=True)
if not os.path.exists(SQLITE):
    conn=sqlite3.connect(SQLITE); c=conn.cursor()
    c.execute("CREATE TABLE IF NOT EXISTS policy(id INTEGER PRIMARY KEY, region TEXT, topic TEXT, rule TEXT)")
    c.executemany("INSERT INTO policy(region, topic, rule) VALUES(?,?,?)", [
        ("USA","Retention","Merchant transaction data must be stored for 7 years (PCI-DSS aligned)."),
        ("USA","OTP","Multi-factor authentication required for ACH transfers above $10,000."),
        ("Germany","Retention","Onboarding KYC documents must be retained for 10 years (BaFin)."),
        ("Germany","SCA","Strong Customer Authentication required for card-not-present transactions.")
    ]); conn.commit(); conn.close()

def require_token(x_api_token: Optional[str] = Header(None)):
    if API_TOKEN and x_api_token != API_TOKEN:
        raise HTTPException(status_code=401, detail="Invalid API token")

app = FastAPI(title="SIM Agentic RAG – Native SIM (Optional)", version="1.0")
app.mount("/", StaticFiles(directory="public", html=True), name="public")

class Query(BaseModel):
    question: str
    k: int = 5

def chunk_text(t, size=800, overlap=120):
    words=t.split(); out=[]; i=0
    while i<len(words):
        out.append(' '.join(words[i:i+size])); i+=max(1,size-overlap)
    return out

@app.get("/sim/status", dependencies=[Depends(require_token)])
def sim_status():
    return {"sim_enabled": SIM_ENABLED}

@app.get("/health", dependencies=[Depends(require_token)])
def health():
    return {"ok": True, "collection_size": coll.count(), "embedding_model": EMB_MODEL, "sim": SIM_ENABLED}

@app.post("/ingest/file", dependencies=[Depends(require_token)])
async def ingest_file(file: UploadFile = File(...), source: str = Form("uploaded")):
    name=file.filename.lower(); data=await file.read()
    if name.endswith(".pdf"):
        text=""; import fitz
        with fitz.open(stream=data, filetype="pdf") as doc:
            for page in doc: text += page.get_text()
    else:
        text=data.decode("utf-8", errors="ignore")
    chunks=chunk_text(text); ids=[]; metas=[]; docs=[]
    start=coll.count()
    for i,ch in enumerate(chunks):
        ids.append(f"{source}-{start+i}"); metas.append({"source":source}); docs.append(ch)
    if not docs: return {"added_chunks":0}
    embs=embedder.encode(docs, convert_to_numpy=True)
    coll.add(ids=ids, documents=docs, metadatas=metas, embeddings=list(embs))
    return {"added_chunks": len(docs), "collection_size": coll.count()}

def llm_call(messages, temperature=0.2, max_tokens=500):
    if not (LLM_API_BASE and LLM_API_KEY):
        raise HTTPException(status_code=500, detail="Configure LLM_API_BASE/LLM_API_KEY")
    url=f"{LLM_API_BASE}/chat/completions?api-version={LLM_API_VERSION}"
    r=requests.post(url, headers={"Content-Type":"application/json","api-key":LLM_API_KEY}, json={"messages":messages, "temperature":temperature, "max_tokens":max_tokens}, timeout=180)
    r.raise_for_status(); return r.json()["choices"][0]["message"]["content"]

@app.post("/query", dependencies=[Depends(require_token)])
def direct_query(q: Query):
    res=coll.query(query_texts=[q.question], n_results=q.k, include=["documents","metadatas"])
    docs=res["documents"][0]; metas=res["metadatas"][0]
    context='\n\n'.join([f"[{i+1}] {d}\n(source: {metas[i]['source']})" for i,d in enumerate(docs)])
    ans=llm_call([{"role":"system","content":"Answer strictly from context; cite [#]."},{"role":"user","content": f"Q: {q.question}\n\nContext:\n{context}"}], 0.2, 420)
    return {"answer": ans, "sources":[m["source"] for m in metas]}

async def agent_stream_generator(question: str, use_sim: bool):
    from json import dumps
    if use_sim and not SIM_ENABLED:
        yield {"event":"message","data": dumps({"type":"status","message":"SIM not installed; falling back to internal agent.","class":"err"})}
        use_sim=False

    # If SIM YAML exists, read for display (not required for execution)
    if use_sim and os.path.exists("rag_sim.yaml"):
        cfg=yaml.safe_load(open("rag_sim.yaml"))
        yield {"event":"message","data": dumps({"type":"status","message":"Loaded SIM config (rag_sim.yaml)","class":"thinking"})}

    # PLAN
    yield {"event":"message","data": dumps({"type":"status","message":"Planner: evaluating tools…","class":"thinking"})}
    await asyncio.sleep(0.2)
    plan="Use Retriever (vector) and SQL, then Synthesizer."
    yield {"event":"message","data": dumps({"type":"status","message": f"Plan: {plan}","class":"thinking"})}

    # RETRIEVER
    yield {"event":"message","data": dumps({"type":"status","message":"Retriever: vector search…","class":"fetching"})}
    res=coll.query(query_texts=[question], n_results=5, include=["documents","metadatas"])
    docs=res["documents"][0] if res["documents"] else []
    metas=res["metadatas"][0] if res["metadatas"] else []
    vec_ctx='\n\n'.join([f"- {d} (src:{metas[i]['source']})" for i,d in enumerate(docs)]) if docs else "(no vector results)"
    yield {"event":"message","data": dumps({"type":"status","message": f"Retriever: got {len(docs)} chunks","class":"fetching"})}

    # SQL
    yield {"event":"message","data": dumps({"type":"status","message":"SQLAgent: querying policies.db…","class":"fetching"})}
    conn=sqlite3.connect(SQLITE); c=conn.cursor()
    c.execute("SELECT region,topic,rule FROM policy")
    rows=c.fetchall(); conn.close()
    sql_ctx='\n'.join([f"{r} {t}: {rule}" for r,t,rule in rows])
    yield {"event":"message","data": dumps({"type":"status","message": f"SQLAgent: fetched {len(rows)} rules","class":"fetching"})}

    # SYNTH
    yield {"event":"message","data": dumps({"type":"status","message":"Synthesizer: composing grounded answer…","class":"synth"})}
    prompt=[
        {"role":"system","content":"Combine vector + SQL facts. Be concise and cite source file names when used."},
        {"role":"user","content": f"Question: {question}\n\nVECTOR PASSAGES:\n{vec_ctx}\n\nSTRUCTURED RULES:\n{sql_ctx}\n\nReturn: answer, 3 bullets, and region-wise notes."}
    ]
    try:
        text=llm_call(prompt, 0.2, 500)
    except Exception as e:
        yield {"event":"message","data": dumps({"type":"status","message": f"LLM error: {e}","class":"err"})}
        return

    # stream tokens
    words=text.split(" "); current=""
    for i,w in enumerate(words):
        current += ("" if i==0 else " ") + w
        if i % 6 == 0:
            await asyncio.sleep(0.03)
            yield {"event":"message","data": dumps({"type":"token","content": current[-120:]})}
    yield {"event":"message","data": dumps({"type":"final","content": text})}

@app.get("/agent/stream")
async def agent_stream(question: str, token: str, use_sim: bool = True):
    if token != API_TOKEN:
        from json import dumps
        async def bad():
            yield {"event":"message","data": dumps({"type":"status","message":"Auth failed","class":"err"})}
        return EventSourceResponse(bad())
    async def publisher():
        async for ev in agent_stream_generator(question, use_sim):
            yield ev
    return EventSourceResponse(publisher())

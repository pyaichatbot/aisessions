import os, re, json, sqlite3
from typing import List, Optional
from fastapi import FastAPI, UploadFile, File, Form, HTTPException, Depends, Header
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from dotenv import load_dotenv
import fitz  # PyMuPDF
import chromadb
from chromadb.config import Settings
from sentence_transformers import SentenceTransformer
import numpy as np
import requests
from sklearn.metrics.pairwise import cosine_similarity

load_dotenv()
API_TOKEN = os.getenv("RAG_API_TOKEN","demo-token")

def require_token(x_api_token: str = Header(None)):
    if API_TOKEN and x_api_token != API_TOKEN:
        raise HTTPException(status_code=401, detail="Invalid API token")

# Vector store setup
PERSIST_PATH="./vectordb"; COLLECTION="docs"
client = chromadb.PersistentClient(path=PERSIST_PATH, settings=Settings(anonymized_telemetry=False))
coll = client.get_or_create_collection(COLLECTION)
embedder = SentenceTransformer(os.getenv("EMBEDDING_MODEL","all-MiniLM-L6-v2"))

# Simple SQL DB (hybrid) with sample structured data
SQLITE_PATH = "./structured.db"
if not os.path.exists(SQLITE_PATH):
    conn = sqlite3.connect(SQLITE_PATH); c = conn.cursor()
    c.execute("CREATE TABLE IF NOT EXISTS policy(id INTEGER PRIMARY KEY, area TEXT, rule TEXT)")
    c.executemany("INSERT INTO policy(area,rule) VALUES(?,?)",[
        ("KYC","Documents must be stored for 5 years"),
        ("KYC","Address proof: recent utility bill or bank statement (<=3 months)"),
        ("UPI","OTP must expire within 180 seconds"),
    ]); conn.commit(); conn.close()

# Graph (adjacency) – naive entity co-occurrence graph in memory
GRAPH = {}

def upsert_edge(a,b):
    if a==b: return
    GRAPH.setdefault(a,{}); GRAPH[a][b] = GRAPH[a].get(b,0)+1
    GRAPH.setdefault(b,{}); GRAPH[b][a] = GRAPH[b].get(a,0)+1

def extract_entities(text):
    # naive: capitalized words/phrases as "entities"
    ents = re.findall(r'(?:[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)', text)
    # keep some whitelisted finance terms
    keep = []
    for e in ents:
        if len(e.split())<=4 and e.lower() not in {'The','And','For','This'}:
            keep.append(e.strip())
    return list(set(keep))[:12]

def chunk_text(t, size=800, overlap=120):
    words=t.split(); out=[]; i=0
    while i<len(words):
        out.append(" ".join(words[i:i+size])); i+=max(1,size-overlap)
    return out

def add_to_vectorstore(chunks, source, tags):
    ids=[]; metas=[]; texts=[]
    start = coll.count()
    for i,ch in enumerate(chunks):
        ids.append(f"{source}-{start+i}")
        texts.append(ch)
        metas.append({"source":source,"tags":tags})
        # graph edges from entities co-occurrence per chunk
        ents = extract_entities(ch)
        for i in range(len(ents)-1):
            upsert_edge(ents[i], ents[i+1])
    embs = embedder.encode(texts, convert_to_numpy=True)
    coll.add(ids=ids, documents=texts, metadatas=metas, embeddings=list(embs))

def call_llm(messages):
    base=os.getenv("LLM_API_BASE"); key=os.getenv("LLM_API_KEY"); ver=os.getenv("LLM_API_VERSION","2023-06-01")
    if not (base and key): raise HTTPException(status_code=500, detail="LLM endpoint not configured")
    url=f"{base}/chat/completions?api-version={ver}"
    r=requests.post(url,headers={"Content-Type":"application/json","api-key":key},
                    json={"messages":messages,"temperature":0.2,"max_tokens":420},timeout=120)
    r.raise_for_status(); return r.json()["choices"][0]["message"]["content"]

app = FastAPI(title="RAG Session 3 – Graph & Hybrid", version="1.0")
app.mount("/", StaticFiles(directory="public", html=True), name="public")

class Query(BaseModel):
    question:str
    k:int=5
    filters:Optional[str]=""
    
@app.get("/health", dependencies=[Depends(require_token)])
def health():
    return {"ok":True,"collection_size":coll.count(),"graph_nodes":len(GRAPH)}

@app.post("/ingest/file", dependencies=[Depends(require_token)])
async def ingest_file(file: UploadFile = File(...), tags: str = Form("")):
    name=file.filename
    data=await file.read()
    text=""
    if name.lower().endswith(".pdf"):
        with fitz.open(stream=data, filetype="pdf") as doc:
            for page in doc: text += page.get_text()
    else:
        text=data.decode("utf-8",errors="ignore")
    ch=chunk_text(text)
    add_to_vectorstore(ch, name, tags)
    return {"added_chunks": len(ch), "collection_size": coll.count()}

@app.post("/query", dependencies=[Depends(require_token)])
def vector_query(q: Query):
    # Filter by metadata tags if provided (simple contains match)
    where=None
    if q.filters:
        # tags like "source=rbi;year=2024" => we only store 'tags' string; do contains checks
        where={"$contains":{"tags": q.filters}}
    res = coll.query(query_texts=[q.question], n_results=q.k, include=["documents","metadatas","distances"], where=where)
    docs=res["documents"][0]; metas=res["metadatas"][0]; dists=res["distances"][0]
    context = "\n\n".join([f"[{i+1}] {d}\n(source: {metas[i]['source']}, dist={dists[i]:.3f})" for i,d in enumerate(docs)])
    ans = call_llm([
        {"role":"system","content":"Answer strictly from context; cite [#] indices. If missing, say 'Not found in context.'"},
        {"role":"user","content": f"Question: {q.question}\n\nContext:\n{context}"}
    ])
    return {"answer": ans, "sources":[m["source"] for m in metas]}

@app.post("/hybrid_query", dependencies=[Depends(require_token)])
def hybrid_query(q: Query):
    # Vector
    res = coll.query(query_texts=[q.question], n_results=max(3,q.k), include=["documents","metadatas","distances"])
    docs=res["documents"][0]; metas=res["metadatas"][0]
    # SQL
    conn=sqlite3.connect(SQLITE_PATH); c=conn.cursor()
    c.execute("SELECT area,rule FROM policy")
    sql_rows=c.fetchall(); conn.close()
    sql_context="\n".join([f"{a}: {r}" for a,r in sql_rows])
    context = "VECTOR:\n" + "\n\n".join([f"- {d} (src:{m['source']})" for d,m in zip(docs,metas)]) + "\n\nSTRUCTURED (SQL):\n" + sql_context
    ans = call_llm([
        {"role":"system","content":"You are a hybrid RAG assistant that merges unstructured (vector) and structured (SQL) facts. Cite sources."},
        {"role":"user","content": f"Question: {q.question}\n\n{context}"}
    ])
    return {"answer": ans, "vector_sources":[m["source"] for m in metas]}

@app.post("/graph_query", dependencies=[Depends(require_token)])
def graph_query(q: Query):
    # Simple graph navigation: find top connected entities that match query tokens
    toks=re.findall(r'[A-Za-z]+', q.question)
    hits=set()
    for t in toks:
        for node in list(GRAPH.keys()):
            if t.lower() in node.lower(): hits.add(node)
    subgraph=set()
    for h in hits:
        subgraph.add(h)
        for nb,wt in sorted(GRAPH.get(h,{}).items(), key=lambda x:-x[1])[:5]:
            subgraph.add(nb)
    graph_context = " ; ".join(sorted(list(subgraph))) if subgraph else "(graph had no matching nodes)"
    # Also vector retrieve to ground
    res = coll.query(query_texts=[q.question], n_results=q.k, include=["documents","metadatas"])
    docs=res["documents"][0]; metas=res["metadatas"][0]
    context = f"GRAPH NODES: {graph_context}\n\nTOP PASSAGES:\n" + "\n\n".join([f"- {d} (src:{m['source']})" for d,m in zip(docs,metas)])
    ans = call_llm([
        {"role":"system","content":"Use graph nodes as hints for entities/relations, but ground final answer only in provided passages."},
        {"role":"user","content": f"Question: {q.question}\n\n{context}"}
    ])
    return {"answer": ans, "graph_nodes": list(subgraph), "sources":[m["source"] for m in metas]}

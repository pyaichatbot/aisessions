from fastapi import FastAPI, UploadFile, File
from fastapi.staticfiles import StaticFiles
from fastapi.responses import JSONResponse
from pydantic import BaseModel
import os
from backend.db.core import init_db, SessionLocal
from backend.db.models import User, ChatSession, Message, Document, Chunk
from backend.services.utils import chunk_text, sha1, detect_lang, read_text_from_path
from backend.retrieval.chroma_client import get_client, get_or_create_collection
from backend.retrieval.embeddings import embed_texts, floats_to_binary_codes, rerank
from backend.retrieval.bq_index import BQIndex
from backend.memory.redis_mem import push_message, get_messages
from backend.services.llm_client import chat as llm_chat

BASE_DIR=os.path.dirname(os.path.dirname(__file__))
DOCS_DIR=os.path.join(BASE_DIR,'..','corpus')
BQ_DIR=os.path.join(BASE_DIR,'..','data','bq'); os.makedirs(BQ_DIR, exist_ok=True)

app=FastAPI(title='Multilingual RAG • BQ • Rerank')
app.mount('/', StaticFiles(directory=os.path.join(BASE_DIR,'..','frontend'), html=True), name='frontend')

class Q(BaseModel):
    user_id:str; session_id:str; question:str; mode:str='naive'; k:int=5

@app.on_event('startup')
def _init(): init_db()

def ensure_user_session(db, user_ext_id, session_id):
    u=db.query(User).filter(User.external_id==user_ext_id).first()
    if not u: u=User(external_id=user_ext_id); db.add(u); db.commit()
    s=db.query(ChatSession).filter(ChatSession.id==session_id).first()
    if not s: s=ChatSession(id=session_id, user_id=u.id, label=f'Session {session_id}'); db.add(s); db.commit()
    return u,s

@app.post('/upload')
async def upload(user_id:str, file:UploadFile=File(...)):
    user_dir=os.path.join(DOCS_DIR,user_id); os.makedirs(user_dir, exist_ok=True)
    path=os.path.join(user_dir, file.filename)
    with open(path,'wb') as f: f.write(await file.read())
    db=SessionLocal(); u=db.query(User).filter(User.external_id==user_id).first()
    if not u: u=User(external_id=user_id); db.add(u); db.commit()
    d=Document(user_id=u.id, path=os.path.relpath(path, DOCS_DIR), title=file.filename); db.add(d); db.commit()
    return {'status':'ok','path':d.path,'doc_id':d.id}

@app.post('/ingest')
async def ingest(user_id:str):
    db=SessionLocal(); client=get_client(); col=get_or_create_collection(client, f'docs-{user_id}', {'user':user_id})
    bq=BQIndex(os.path.join(BQ_DIR,user_id))
    user_dir=os.path.join(DOCS_DIR,user_id)
    if not os.path.exists(user_dir): return {'status':'no_docs'}
    metas=[]; chunks=[]; ids=[]
    for root,_,files in os.walk(user_dir):
        for fn in files:
            p=os.path.join(root,fn); rel=os.path.relpath(p, DOCS_DIR)
            text=read_text_from_path(p); if not text.strip(): continue
            doc=db.query(Document).filter(Document.path==rel).first(); 
            if not doc: continue
            pcs=chunk_text(text,900,150)
            for idx,ch in enumerate(pcs):
                cid=sha1(ch); ids.append(cid); chunks.append(ch); metas.append({'doc_id':doc.id,'doc_path':rel,'chunk_id':idx})
                if not db.query(Chunk).filter(Chunk.id==cid).first(): db.add(Chunk(id=cid, doc_id=doc.id, idx=idx, text=ch))
    if not chunks: return {'status':'no_chunks'}
    vecs=embed_texts(chunks)
    col.add(ids=ids, embeddings=vecs.tolist(), documents=chunks, metadatas=metas)
    import numpy as np
    packed=floats_to_binary_codes(vecs); bq.add([{'id':i,**m,'chunk':c} for i,m,c in zip(ids,metas,chunks)], packed)
    return {'status':'ok','chunks':len(chunks)}

@app.post('/chat/query')
async def query(body:Q):
    db=SessionLocal(); u,s=ensure_user_session(db, body.user_id, body.session_id)
    lang=detect_lang(body.question,'en')
    results=[]
    if body.mode=='naive':
        client=get_client(); col=get_or_create_collection(client, f'docs-{body.user_id}')
        qv=embed_texts([body.question])[0]; q=col.query(query_embeddings=[qv.tolist()], n_results=max(20,body.k))
        for i in range(len(q['ids'][0])):
            results.append({'id':q['ids'][0][i], 'chunk':q['documents'][0][i], 'score': float(q.get('distances',[ [0]*len(q['ids'][0]) ])[0][i]), **q['metadatas'][0][i]})
        results=results[:body.k]
    elif body.mode in ('bq','bq_rerank'):
        bq=BQIndex(os.path.join(BQ_DIR, body.user_id)); bq.load()
        qv=embed_texts([body.question])[0].reshape(1,-1); import numpy as np
        qb=floats_to_binary_codes(qv)[0].reshape(1,-1)
        found=bq.search(qb, top_k=max(20,body.k))
        results=[{'id':m['id'],'chunk':m['chunk'],'doc_id':m['doc_id'],'doc_path':m['doc_path'],'chunk_id':m['chunk_id'],'score':float(score)} for (m,score) in found]
        if body.mode=='bq_rerank':
            passages=[r['chunk'] for r in results]; rer=rerank(body.question, passages, top_k=body.k)
            results=[{**results[idx],'score':float(score)} for (idx,score) in rer]
        else:
            results=results[:body.k]
    else:
        return JSONResponse({'error':'invalid mode'}, status_code=400)

    short=get_messages(body.session_id); mem='\n'.join([f"{m['role']}: {m['content']}" for m in short][-6:])
    ctx='\n\n'.join([f"[{r['doc_path']}#{r['chunk_id']}] {r['chunk']}" for r in results])
    system=f"Answer only from context. If unsure, say you don't know. Respond in language code: {lang}."
    user=f"""Question: {body.question}

Short memory:
{mem}

Context:
{ctx}

Return a concise answer in user's language with citations as [file#chunk]."""
    msgs=[{'role':'system','content':system},{'role':'user','content':user}]
    answer=llm_chat(msgs, language_hint=lang)

    db.add(Message(session_id=s.id, role='user', content=body.question)); db.commit()
    db.add(Message(session_id=s.id, role='assistant', content=answer)); db.commit()
    push_message(s.id,'user', body.question); push_message(s.id,'assistant', answer)
    cits=[{'doc_path':r['doc_path'],'chunk_id':r['chunk_id'],'score':r['score']} for r in results]
    return {'answer':answer,'results':results,'citations':cits,'lang':lang}

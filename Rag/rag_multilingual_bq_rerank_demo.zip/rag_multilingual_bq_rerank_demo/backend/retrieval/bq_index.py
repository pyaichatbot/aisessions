import os, json, numpy as np
class BQIndex:
    def __init__(self, root): self.root=root; os.makedirs(self.root, exist_ok=True); self.codes_path=os.path.join(root,'codes.npy'); self.meta_path=os.path.join(root,'meta.json'); self.codes=None; self.meta=[]
    def add(self, metas, packed_codes):
        if os.path.exists(self.meta_path): self.meta=json.load(open(self.meta_path,'r',encoding='utf-8'))
        if os.path.exists(self.codes_path): import numpy as _np; self.codes=_np.vstack([_np.load(self.codes_path), packed_codes])
        else: self.codes=packed_codes
        self.meta.extend(metas); np.save(self.codes_path, self.codes); json.dump(self.meta, open(self.meta_path,'w',encoding='utf-8'), ensure_ascii=False, indent=2)
    def load(self):
        if os.path.exists(self.codes_path): self.codes=np.load(self.codes_path)
        if os.path.exists(self.meta_path): self.meta=json.load(open(self.meta_path,'r',encoding='utf-8'))
    def search(self, query_code, top_k=5):
        if self.codes is None or not self.meta: return []
        popcnt=np.array([bin(i).count('1') for i in range(256)], dtype=np.uint8); xor=np.bitwise_xor(self.codes, query_code); d=popcnt[xor].sum(axis=1); idx=np.argsort(d)[:top_k]; return [(self.meta[i], int(d[i])) for i in idx]

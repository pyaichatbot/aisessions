import os, chromadb
CHROMA_HOST=os.getenv("CHROMA_HOST","localhost"); CHROMA_PORT=int(os.getenv("CHROMA_PORT","8000"))
def get_client(): return chromadb.HttpClient(host=CHROMA_HOST, port=CHROMA_PORT)
def get_or_create_collection(client, name, metadata=None):
    try: return client.get_collection(name)
    except Exception: return client.create_collection(name=name, metadata=metadata or {})

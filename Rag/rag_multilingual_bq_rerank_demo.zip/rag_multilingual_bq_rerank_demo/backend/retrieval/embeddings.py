from sentence_transformers import SentenceTransformer, CrossEncoder
import numpy as np
EMBED_MODEL_NAME="sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"
RERANK_MODEL_NAME="cross-encoder/ms-marco-MiniLM-L-6-v2"
_embedder=None; _rer=None
def get_embedder():
    global _embedder
    if _embedder is None: _embedder=SentenceTransformer(EMBED_MODEL_NAME)
    return _embedder
def embed_texts(texts):
    m=get_embedder(); v=m.encode(texts, convert_to_numpy=True, normalize_embeddings=True); return v.astype(np.float32)
def floats_to_binary_codes(v):
    signs=(v>=0).astype(np.uint8); return np.packbits(signs, axis=1)
def get_reranker():
    global _rer
    if _rer is None: _rer=CrossEncoder(RERANK_MODEL_NAME)
    return _rer
def rerank(query, passages, top_k=3):
    m=get_reranker(); pairs=[(query,p) for p in passages]; s=m.predict(pairs).tolist(); idx=sorted(range(len(s)), key=lambda i:-s[i])[:top_k]; return [(i, float(s[i])) for i in idx]

import os, requests
LLM_ENDPOINT=os.getenv("LLM_ENDPOINT",""); LLM_API_KEY=os.getenv("LLM_API_KEY",""); LLM_MODEL=os.getenv("LLM_MODEL","gpt-4o-mini")
def chat(messages, language_hint='en'):
    if not LLM_ENDPOINT:
        # fallback
        user = next((m['content'] for m in messages if m.get('role')=='user'), '')
        return "LLM not configured. Fallback summary based on provided context.\n"+user[:800]
    headers={'Content-Type':'application/json'}
    if LLM_API_KEY: headers['Authorization']=f'Bearer {LLM_API_KEY}'; headers['api-key']=LLM_API_KEY
    body={'model':LLM_MODEL,'messages':messages,'temperature':0.2,'max_tokens':300}
    try:
        r=requests.post(LLM_ENDPOINT, headers=headers, json=body, timeout=30); j=r.json()
        if 'choices' in j and j['choices']: return j['choices'][0].get('message',{}).get('content') or j['choices'][0].get('text','')
        return str(j)[:800]
    except Exception as e:
        return f"LLM call failed: {e}"

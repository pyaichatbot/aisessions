import re, hashlib, os
from langdetect import detect
def detect_lang(text, default='en'):
    try: return detect(text)
    except Exception: return default
def chunk_text(text, max_chars=900, overlap=150):
    s=re.split(r'(?<=[.!?\n])\s+', text.strip()); chunks=[]; buf=''
    for t in s:
        if len(buf)+len(t)+1<=max_chars: buf=(buf+' '+t).strip()
        else:
            if buf: chunks.append(buf)
            buf=(buf[-overlap:]+ ' ' + t).strip() if overlap and buf else t
    if buf: chunks.append(buf)
    return [c for c in chunks if c.strip()]
def sha1(x): import hashlib as h; return h.sha1(x.encode('utf-8')).hexdigest()
def read_text_from_path(p):
    if p.lower().endswith(('.txt','.md')): return open(p,'r',encoding='utf-8',errors='ignore').read()
    return ''

from sqlalchemy.orm import declarative_base, mapped_column
from sqlalchemy import String, Text, Integer, ForeignKey, DateTime
import uuid, datetime
Base=declarative_base()
def gen_uuid(): return str(uuid.uuid4())
class User(Base):
    __tablename__='users'; id=mapped_column(String(36), primary_key=True, default=gen_uuid); external_id=mapped_column(String(128), index=True)
class ChatSession(Base):
    __tablename__='chat_sessions'; id=mapped_column(String(36), primary_key=True); user_id=mapped_column(String(36)); label=mapped_column(String(128), default=''); created_at=mapped_column(DateTime, default=datetime.datetime.utcnow)
class Message(Base):
    __tablename__='messages'; id=mapped_column(String(36), primary_key=True, default=gen_uuid); session_id=mapped_column(String(36)); role=mapped_column(String(16)); content=mapped_column(Text); created_at=mapped_column(DateTime, default=datetime.datetime.utcnow)
class Document(Base):
    __tablename__='documents'; id=mapped_column(String(36), primary_key=True, default=gen_uuid); user_id=mapped_column(String(36)); path=mapped_column(String(512)); title=mapped_column(String(256), default=''); created_at=mapped_column(DateTime, default=datetime.datetime.utcnow)
class Chunk(Base):
    __tablename__='chunks'; id=mapped_column(String(40), primary_key=True); doc_id=mapped_column(String(36)); idx=mapped_column(Integer); text=mapped_column(Text)

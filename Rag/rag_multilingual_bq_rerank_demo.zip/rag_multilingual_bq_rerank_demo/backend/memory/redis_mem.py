import os, json, redis
REDIS_URL=os.getenv("REDIS_URL","redis://localhost:6379/0"); r=redis.from_url(REDIS_URL, decode_responses=True)
SHORT_WINDOW=20
def push_message(session_id, role, content):
    key=f"session:{session_id}:messages"; r.lpush(key, json.dumps({"role":role,"content":content})); r.ltrim(key,0,SHORT_WINDOW-1)
def get_messages(session_id):
    key=f"session:{session_id}:messages"; items=r.lrange(key,0,SHORT_WINDOW-1); import json as _j; return [_j.loads(x) for x in reversed(items)]

# Beginner Guide
Run docker-compose up --build, open http://localhost:8080

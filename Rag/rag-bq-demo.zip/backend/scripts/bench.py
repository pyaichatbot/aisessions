import time, argparse, json
from app.embedding import EmbeddingModel
from app.binarize import float_to_binary
from app.milvus_store import MilvusStore

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--queries", required=True, help="Path to queries.txt")
    ap.add_argument("--k", type=int, default=50)
    ap.add_argument("--iters", type=int, default=3)
    ap.add_argument("--nprobe", type=int, default=64)
    args = ap.parse_args()

    with open(args.queries, "r", encoding="utf-8") as f:
        qs = [l.strip() for l in f if l.strip()]

    emb = EmbeddingModel()
    store = MilvusStore(dim=emb.dim)

    records = []
    for q in qs:
        for _ in range(args.iters):
            t0 = time.time()
            qv = emb.embed([q])
            qbv = float_to_binary(qv)[0]
            hits = store.search(qbv, limit=args.k, nprobe=args.nprobe)
            ms = (time.time() - t0) * 1000.0
            records.append({"query": q, "k": args.k, "nprobe": args.nprobe, "latency_ms": ms, "results": len(hits)})
            print(json.dumps(records[-1]))
    print("SUMMARY")
    print(json.dumps({"avg_ms": sum(r["latency_ms"] for r in records)/len(records), "count": len(records)}, indent=2))

if __name__ == "__main__":
    main()

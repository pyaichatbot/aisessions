from pydantic import BaseModel, Field
from typing import Optional, Dict, Any

class QueryRequest(BaseModel):
    query: str
    top_k: int = 20
    use_reranker: bool = True
    stream: bool = True
    bin_index_params: Optional[Dict[str, Any]] = Field(default=None, description="Override nlist/nprobe")

class IngestResponse(BaseModel):
    doc_id: str
    chunks: int

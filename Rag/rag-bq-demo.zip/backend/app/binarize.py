import numpy as np

def float_to_binary(vecs: np.ndarray) -> list[bytes]:
    """Convert (N, D) float32 to list of packed bytes for Milvus BINARY_VECTOR.
    Uses sign-bit (>=0 -> 1, <0 -> 0)."""
    assert vecs.ndim == 2, "Expected (N, D) array"
    N, D = vecs.shape
    # Convert to bits per dimension
    bits = (vecs >= 0).astype(np.uint8)  # 0/1
    # Pack bits along dim axis -> bytes per vector
    packed = []
    for i in range(N):
        b = np.packbits(bits[i], bitorder='big').tobytes()
        # Ensure length is D/8 bytes; if D not multiple of 8, pad
        needed = (D + 7) // 8
        if len(b) != needed:
            # pad zeros at the end
            arr = np.zeros(needed, dtype=np.uint8)
            arr[:len(b)] = np.frombuffer(b, dtype=np.uint8)
            b = arr.tobytes()
        packed.append(b)
    return packed

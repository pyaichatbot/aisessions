from typing import List
import re

def simple_chunk(text: str, max_chars: int = 1500, overlap: int = 150) -> List[str]:
    chunks = []
    start = 0
    n = len(text)
    while start < n:
        end = min(n, start + max_chars)
        # try to end on sentence
        slice_ = text[start:end]
        m = max(slice_.rfind('. '), slice_.rfind('\n'))
        if m > 0 and (start + m + 1 - start) > max_chars * 0.5:
            end = start + m + 1
        chunks.append(text[start:end].strip())
        start = max(0, end - overlap)
    return [c for c in chunks if c]

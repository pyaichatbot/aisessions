from typing import List, AsyncGenerator
from .config import settings
from openai import AzureOpenAI
import asyncio

SYS_PROMPT = "You are a precise assistant. Answer using only the provided context. If information is missing, say you don't know."

def build_prompt(contexts: List[str], question: str) -> str:
    ctx = "\n\n---\n\n".join(contexts)
    return f"Context:\n{ctx}\n\nQuestion: {question}\nAnswer:"

async def stream_generate(contexts: List[str], question: str) -> AsyncGenerator[str, None]:
    if not settings.ENABLE_GENERATION:
        # fallback: just concatenate best contexts
        yield "Generation disabled. Top contexts:\n"
        for i, c in enumerate(contexts[:3]):
            yield f"[{i+1}] {c[:300]}...\n"
        return

    client = AzureOpenAI(
        api_key=settings.AZURE_OPENAI_API_KEY,
        api_version=settings.AZURE_OPENAI_API_VERSION,
        azure_endpoint=settings.AZURE_OPENAI_ENDPOINT,
    )
    messages = [
        {"role":"system","content":SYS_PROMPT},
        {"role":"user","content":build_prompt(contexts, question)},
    ]
    # Stream
    with client.chat.completions.with_streaming_response.create(
        model=settings.AZURE_CHAT_DEPLOYMENT,
        messages=messages,
        temperature=0.2,
        max_tokens=512,
        stream=True,
    ) as response:
        for event in response.iter_events():
            if event.type == "token":
                yield event.token
            elif event.type == "error":
                yield f"[Error: {event.error}]"
    await asyncio.sleep(0)

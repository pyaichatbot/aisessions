from typing import List, Dict, Any, Optional
from pymilvus import connections, FieldSchema, CollectionSchema, DataType, Collection, utility
from .config import settings

class MilvusStore:
    def __init__(self, dim: int, collection_name: Optional[str] = None):
        self.dim = dim
        self.collection_name = collection_name or settings.COLLECTION_NAME
        connections.connect("default", host=settings.MILVUS_HOST, port=str(settings.MILVUS_PORT))
        self._ensure_collection()

    def _ensure_collection(self):
        if utility.has_collection(self.collection_name):
            self.coll = Collection(self.collection_name)
            return
        fields = [
            FieldSchema(name="id", dtype=DataType.INT64, is_primary=True, auto_id=True),
            FieldSchema(name="doc_id", dtype=DataType.VARCHAR, max_length=256),
            FieldSchema(name="chunk_id", dtype=DataType.INT64),
            FieldSchema(name="text", dtype=DataType.VARCHAR, max_length=8192),
            FieldSchema(name="bv", dtype=DataType.BINARY_VECTOR, dim=self.dim),
        ]
        schema = CollectionSchema(fields, description="RAG with Binary Quantization")
        self.coll = Collection(self.collection_name, schema)

        # Binary IVF index
        self.coll.create_index(
            field_name="bv",
            index_params={
                "index_type": "BIN_IVF_FLAT",
                "metric_type": "HAMMING",
                "params": {"nlist": 16384},
            },
        )
        self.coll.load()

    def upsert(self, doc_id: str, chunks: List[Dict[str, Any]]):
        # chunks: [{"chunk_id": i, "text": str, "bv": bytes}]
        ids = [None] * len(chunks)  # auto-id
        doc_ids = [doc_id] * len(chunks)
        chunk_ids = [c["chunk_id"] for c in chunks]
        texts = [c["text"] for c in chunks]
        bvs = [c["bv"] for c in chunks]

        self.coll.insert([ids, doc_ids, chunk_ids, texts, bvs])
        self.coll.flush()

    def search(self, query_bv: bytes, limit: int = 50, nprobe: int = 64):
        self.coll.load()
        res = self.coll.search(
            data=[query_bv],
            anns_field="bv",
            param={"metric_type":"HAMMING","params":{"nprobe": nprobe}},
            limit=limit,
            output_fields=["doc_id","chunk_id","text"],
        )
        return res[0]  # first query

from typing import List, Literal
import os
import numpy as np
from .config import settings

# Azure OpenAI
from openai import AzureOpenAI

# Local embeddings
from sentence_transformers import SentenceTransformer

class EmbeddingModel:
    def __init__(self, backend: Literal["azure","local"] = None):
        self.backend = backend or settings.EMBEDDING_BACKEND
        self.client = None
        self.model = None
        if self.backend == "azure":
            if not (settings.AZURE_OPENAI_ENDPOINT and settings.AZURE_OPENAI_API_KEY and settings.AZURE_EMBEDDING_DEPLOYMENT):
                raise RuntimeError("Azure embedding is selected but AZURE_* env not set")
            self.client = AzureOpenAI(
                api_key=settings.AZURE_OPENAI_API_KEY,
                api_version=settings.AZURE_OPENAI_API_VERSION,
                azure_endpoint=settings.AZURE_OPENAI_ENDPOINT,
            )
            self.dim = None  # unknown until first call
        else:
            # Local sentence-transformers
            self.model = SentenceTransformer(settings.LOCAL_EMBEDDING_MODEL)
            self.dim = self.model.get_sentence_embedding_dimension()

    def embed(self, texts: List[str]) -> np.ndarray:
        if self.backend == "azure":
            resp = self.client.embeddings.create(
                input=texts,
                model=settings.AZURE_EMBEDDING_DEPLOYMENT,
            )
            arr = np.array([d.embedding for d in resp.data], dtype=np.float32)
            if self.dim is None:
                self.dim = arr.shape[1]
            return arr
        else:
            emb = self.model.encode(texts, normalize_embeddings=False, convert_to_numpy=True, batch_size=32)
            return emb.astype(np.float32)

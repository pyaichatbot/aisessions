from typing import List
import io, markdown
from pypdf import PdfReader
from docx import Document

def extract_text_from_file(filename: str, content: bytes) -> str:
    name = filename.lower()
    if name.endswith(".pdf"):
        return _pdf_text(content)
    if name.endswith(".docx"):
        return _docx_text(content)
    if name.endswith(".md"):
        return _md_text(content)
    # txt, csv, others -> decode
    try:
        return content.decode("utf-8", errors="ignore")
    except Exception:
        return content.decode("latin-1", errors="ignore")

def _pdf_text(content: bytes) -> str:
    pdf = PdfReader(io.BytesIO(content))
    texts = []
    for page in pdf.pages:
        try:
            texts.append(page.extract_text() or "")
        except Exception:
            continue
    return "\n".join(texts)

def _docx_text(content: bytes) -> str:
    bio = io.BytesIO(content)
    doc = Document(bio)
    return "\n".join(p.text for p in doc.paragraphs)

def _md_text(content: bytes) -> str:
    # keep original markdown text, it's fine for RAG
    return content.decode("utf-8", errors="ignore")

from fastapi import FastAPI, UploadFile, File, Form
from fastapi.responses import PlainTextResponse
from sse_starlette.sse import EventSourceResponse
from typing import List, Optional
import asyncio, time, json, uuid

from .config import settings
from .embedding import EmbeddingModel
from .binarize import float_to_binary
from .milvus_store import MilvusStore
from .rerank import Reranker
from .utils import simple_chunk
from .extract import extract_text_from_file
from .schemas import QueryRequest, IngestResponse
from .generation import stream_generate

app = FastAPI(title="RAG-BQ Demo")

# Lazy singletons
_embedder = None
_store = None
_reranker = None

def get_embedder():
    global _embedder
    if _embedder is None:
        _embedder = EmbeddingModel()
    return _embedder

def get_store():
    global _store
    if _store is None:
        emb = get_embedder()
        _store = MilvusStore(dim=emb.dim, collection_name=settings.COLLECTION_NAME)
    return _store

def get_reranker():
    global _reranker
    if _reranker is None and settings.ENABLE_RERANKER:
        _reranker = Reranker()
    return _reranker

@app.get("/", response_class=PlainTextResponse)
def root():
    return "RAG-BQ backend is up. See /docs"

@app.post("/ingest", response_model=IngestResponse)
async def ingest(files: List[UploadFile] = File(...), doc_id: Optional[str] = Form(None)):
    doc_id = doc_id or str(uuid.uuid4())
    texts = []
    for f in files:
        content = await f.read()
        texts.append(extract_text_from_file(f.filename, content))

    full_text = "\n\n".join(texts)
    chunks = simple_chunk(full_text, max_chars=1500, overlap=150)

    emb = get_embedder()
    vecs = emb.embed(chunks)  # (N, D) float32
    bvs = float_to_binary(vecs)  # list[bytes]

    store = get_store()
    payload = [{"chunk_id": i, "text": chunks[i], "bv": bvs[i]} for i in range(len(chunks))]
    store.upsert(doc_id, payload)
    return IngestResponse(doc_id=doc_id, chunks=len(chunks))

@app.post("/query")
async def query(req: QueryRequest):
    t0 = time.time()
    emb = get_embedder()
    qv = emb.embed([req.query])
    qbv = float_to_binary(qv)[0]

    store = get_store()
    nprobe = (req.bin_index_params or {}).get("nprobe", 64)
    raw_limit = max(req.top_k * (3 if req.use_reranker else 1), req.top_k)
    hits = store.search(qbv, limit=raw_limit, nprobe=nprobe)
    search_ms = int((time.time() - t0) * 1000)

    # gather texts
    texts = [hit.entity.get("text") for hit in hits]
    doc_ids = [hit.entity.get("doc_id") for hit in hits]

    # optional rerank
    rerank_info = []
    if req.use_reranker and settings.ENABLE_RERANKER:
        r0 = time.time()
        rr = get_reranker()
        order = rr.rerank(req.query, texts)
        rerank_ms = int((time.time() - r0) * 1000)
        top_idx = [i for i,_ in order[:req.top_k]]
        contexts = [texts[i] for i in top_idx]
        rerank_info = [{"index": int(i), "score": float(s)} for i,s in order[:req.top_k]]
    else:
        contexts = texts[:req.top_k]
        rerank_ms = 0

    # trim context
    max_chars = settings.MAX_CONTEXT_CHARS
    total = 0
    ctx_final = []
    for c in contexts:
        if total + len(c) <= max_chars:
            ctx_final.append(c)
            total += len(c)
        else:
            ctx_final.append(c[: max(0, max_chars - total)])
            break

    # stream response
    async def event_gen():
        meta = {"search_ms": search_ms, "rerank_ms": rerank_ms, "candidates": len(texts), "used": len(ctx_final)}
        yield {"event": "debug", "data": json.dumps(meta)}
        async for token in stream_generate(ctx_final, req.query):
            yield {"data": token}

    if req.stream:
        return EventSourceResponse(event_gen())
    else:
        # non-stream: aggregate
        out = []
        async for t in stream_generate(ctx_final, req.query):
            out.append(t)
        return {"answer": "".join(out), "debug": {"search_ms": search_ms, "rerank_ms": rerank_ms}}

def run():
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

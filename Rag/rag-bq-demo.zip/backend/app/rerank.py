from typing import List, Tuple
from .config import settings

from sentence_transformers import CrossEncoder

class Reranker:
    def __init__(self):
        self.model = CrossEncoder(settings.RERANKER_MODEL)

    def rerank(self, query: str, docs: List[str]) -> List[Tuple[int, float]]:
        """Return list of (index, score) sorted desc by score."""
        pairs = [(query, d) for d in docs]
        scores = self.model.predict(pairs)
        # sort by score desc
        order = sorted(range(len(docs)), key=lambda i: float(scores[i]), reverse=True)
        return [(i, float(scores[i])) for i in order]

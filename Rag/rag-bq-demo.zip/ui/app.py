import streamlit as st
import requests, time, json
from sseclient import SSEClient

st.set_page_config(page_title="RAG-BQ Demo", layout="wide")
st.title("RAG with Binary Quantization + Reranking (Milvus)")

BACKEND = st.secrets.get("BACKEND_URL", "http://backend:8000")

tab1, tab2 = st.tabs(["Ingest", "Search"])

with tab1:
    st.subheader("Upload documents")
    files = st.file_uploader("Choose files", type=["pdf","docx","md","txt","csv"], accept_multiple_files=True)
    doc_id = st.text_input("Document ID (optional)", "")
    if st.button("Ingest") and files:
        m = {"doc_id": doc_id} if doc_id else {}
        files_form = [("files", (f.name, f.getvalue(), "application/octet-stream")) for f in files]
        with st.spinner("Ingesting..."):
            r = requests.post(f"{BACKEND}/ingest", files=files_form, data=m, timeout=600)
        if r.ok:
            st.success(f"Ingested: {r.json()}")
        else:
            st.error(f"Failed: {r.text}")

with tab2:
    st.subheader("Query")
    q = st.text_input("Ask a question", "What is the document about?")
    top_k = st.slider("Top-K", 5, 200, 30, step=5)
    use_reranker = st.checkbox("Enable reranker", value=True)
    nlist = st.number_input("nlist (index build)", min_value=1024, max_value=65536, value=16384, step=1024)
    nprobe = st.number_input("nprobe (search)", min_value=1, max_value=2048, value=64, step=1)
    stream = st.checkbox("Stream answer", value=True)

    if st.button("Search"):
        payload = {
            "query": q,
            "top_k": top_k,
            "use_reranker": use_reranker,
            "stream": stream,
            "bin_index_params": {"nlist": int(nlist), "nprobe": int(nprobe)},
        }
        st.write("Request:", payload)
        t0 = time.time()
        if stream:
            messages = SSEClient(f"{BACKEND}/query", method="POST", data=json.dumps(payload), headers={"Content-Type":"application/json"})
            text = ""
            debug = None
            for ev in messages.events():
                if ev.event == "debug":
                    debug = json.loads(ev.data)
                else:
                    text += ev.data
                    st.markdown(text)
            t_ms = int((time.time() - t0)*1000)
            st.info(f"Latency: {t_ms} ms; Debug: {debug}")
        else:
            r = requests.post(f"{BACKEND}/query", json=payload, timeout=120)
            if r.ok:
                t_ms = int((time.time() - t0)*1000)
                data = r.json()
                st.markdown(data["answer"])
                st.info(f"Latency: {t_ms} ms; Debug: {data.get('debug')}")
            else:
                st.error(r.text)

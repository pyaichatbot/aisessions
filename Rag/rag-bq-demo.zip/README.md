# RAG-BQ Demo (Binary Quantization + Reranking) — Milvus + FastAPI + Streamlit

This project demonstrates a **production-leaning RAG stack** that uses:
- **Binary Quantization (1-bit embeddings)** for ~32× memory reduction and **ultra-fast vector search** (Hamming distance)
- **Reranking** (Cross-Encoder) to recover accuracy
- **Milvus** as the vector database (binary vector index: BIN_IVF_FLAT / HAMMING)
- **FastAPI** backend with **SSE streaming** for generation
- **Streamlit** UI to ingest documents and run queries
- Optional **Azure OpenAI** or local **SentenceTransformers** embeddings

> Designed for your AI Sessions: switch features on/off to demo **BQ vs Rerank** and parameter effects in real time.

---

## Quick start (Docker Compose)

1) Copy `.env.example` to `.env` and fill secrets (especially Azure OpenAI, if using it).

```bash
cp .env.example .env
```

2) Start everything:

```bash
docker compose up --build
```

Services:
- **Milvus**: `localhost:19530`
- **Backend (FastAPI)**: `http://localhost:8000` (docs at `/docs`)
- **Streamlit UI**: `http://localhost:8501`

3) In the UI:
- Upload files on the **Ingest** tab → chunk, embed (float), **binarize**, and store.
- Run a query on **Search** tab; toggle **Rerank** and index params to compare latency/quality.

---

## Environment variables

See `.env.example`. Key ones:
- `MILVUS_HOST=milvus`
- `MILVUS_PORT=19530`
- `COLLECTION_NAME=rag_bq`
- `EMBEDDING_BACKEND=azure|local` (default `local`)
- **Azure (if EMBEDDING_BACKEND=azure):**
  - `AZURE_OPENAI_ENDPOINT=`
  - `AZURE_OPENAI_API_KEY=`
  - `AZURE_OPENAI_API_VERSION=2024-02-15-preview` (or your version)
  - `AZURE_EMBEDDING_DEPLOYMENT=`
  - `AZURE_CHAT_DEPLOYMENT=`
- **Local embeddings (SentenceTransformers):**
  - `LOCAL_EMBEDDING_MODEL=sentence-transformers/all-MiniLM-L6-v2` (384-dim, fast)
- **Reranker:**
  - `RERANKER_MODEL=cross-encoder/ms-marco-MiniLM-L-6-v2`
  - `ENABLE_RERANKER=true|false`

---

## API

### `POST /ingest`
`multipart/form-data` with files. Optional metadata JSON.
- Chunks text, embeds (float32), **binarizes (1-bit/Dim)**, and writes to Milvus.
- Creates collection automatically using the embedder's dimensionality.

### `POST /query`
```json
{
  "query": "What is ...?",
  "top_k": 20,
  "use_reranker": true,
  "stream": true,
  "bin_index_params": {"nlist": 16384, "nprobe": 64}
}
```
Returns SSE stream (if `stream=true`) with tokens and debug stats (latencies, scores).

---

## Binary Quantization
- We take the **sign** of each embedding dimension and pack bits with `numpy.packbits`.
- Milvus stores a **BINARY_VECTOR** (dim = embedding dim, metric = **HAMMING**).
- Index: `BIN_IVF_FLAT` (or `BIN_FLAT`). Tune `nlist`, `nprobe`.

## Reranking
- Top-K (e.g., 50–200) from BQ search are reranked with a Cross-Encoder (default MiniLM).
- The reranker increases answer quality (MAP/NDCG) with minimal added latency on CPU.
- Toggle it in the UI to show the effect.

---

## Benchmarks
Run a simple micro-benchmark and export CSV:
```bash
docker compose exec backend python scripts/bench.py --queries scripts/queries.txt --k 50 --iters 5
```

---

## Notes
- CPU-only by default. For faster reranking, mount a GPU base image and set `--gpus all` in compose.
- For purely on-prem: set `EMBEDDING_BACKEND=local` and keep LLM generation disabled or proxied.

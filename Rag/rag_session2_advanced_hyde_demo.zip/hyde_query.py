
import os, argparse, json
import chromadb
from chromadb.config import Settings
from sentence_transformers import SentenceTransformer
import requests

def call_llm(messages, temp=0.2, max_tokens=400):
    base = os.getenv("LLM_API_BASE")
    key = os.getenv("LLM_API_KEY")
    api_version = os.getenv("LLM_API_VERSION","2023-06-01")
    url = f"{base}/chat/completions?api-version={api_version}"
    payload = {"messages": messages, "temperature": temp, "max_tokens": max_tokens}
    headers = {"Content-Type":"application/json", "api-key": key}
    r = requests.post(url, headers=headers, json=payload, timeout=120)
    r.raise_for_status()
    data = r.json()
    return data["choices"][0]["message"]["content"]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--q", required=True)
    ap.add_argument("--persist", default="./vectordb")
    ap.add_argument("--collection", default="docs")
    ap.add_argument("--k", type=int, default=5)
    args = ap.parse_args()

    client = chromadb.PersistentClient(path=args.persist, settings=Settings(anonymized_telemetry=False))
    coll = client.get_or_create_collection(args.collection)
    embedder = SentenceTransformer(os.getenv("EMBEDDING_MODEL","all-MiniLM-L6-v2"))

    # Step 1: Generate hypothetical answer (HyDE)
    hyp = call_llm([
        {"role":"system","content":"Draft a concise hypothetical answer to help retrieve relevant passages from a policy knowledge base."},
        {"role":"user","content": f"Question: {args.q}. Write 3-4 sentences likely to appear in a policy document."}
    ], temp=0.3, max_tokens=120)

    # Step 2: Embed hypothetical answer & retrieve
    hyp_emb = embedder.encode([hyp])[0]
    res = coll.query(query_embeddings=[hyp_emb], n_results=args.k, include=["documents","metadatas","distances"])
    docs = res["documents"][0]; metas = res["metadatas"][0]; dists = res["distances"][0]

    # If retrieval weak (avg distance high), rewrite query
    if sum(dists)/len(dists) > 0.3:
        rew = call_llm([
            {"role":"system","content":"Rewrite queries for better retrieval with exact field names and synonyms."},
            {"role":"user","content": f"Rewrite this as a precise policy search query with synonyms: '{args.q}'"}
        ], temp=0.4, max_tokens=60)
        q_emb = embedder.encode([rew])[0]
        res = coll.query(query_embeddings=[q_emb], n_results=args.k, include=["documents","metadatas","distances"])
        docs = res["documents"][0]; metas = res["metadatas"][0]; dists = res["distances"][0]

    context = ""
    for i,(d,m,dist) in enumerate(zip(docs, metas, dists), start=1):
        context += f"### Chunk {i} (source: {m['source']}, distance: {dist:.3f})\n{d}\n\n"

    # Final answer
    answer = call_llm([
        {"role":"system","content":"Answer using only the context. If not present, say 'Not found in context'."},
        {"role":"user","content": f"Question: {args.q}\n\nContext:\n{context}\nReturn an answer + cite file names."}
    ], temp=0.2, max_tokens=350)

    print("\n===== HYPOTHETICAL DOC =====\n", hyp)
    print("\n===== ANSWER =====\n", answer)
    print("\n===== SOURCES =====")
    for m in metas:
        print("-", m["source"])

if __name__ == "__main__":
    main()

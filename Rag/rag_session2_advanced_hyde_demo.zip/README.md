
# Advanced RAG Demo (Session 2) – HyDE + Query Rewrite + Rerank

This demo implements **HyDE** (Hypothetical Document Embeddings) and a **Query Analyzer** step.
- HyDE: Use LLM to generate a hypothetical answer, embed it, then retrieve more relevant chunks.
- Query Rewrite: If retrieval is weak, ask the LLM to rewrite the query for better recall.

## Quick start
1) Copy `.env.example` → `.env` and set `LLM_API_BASE` + `LLM_API_KEY`.
2) Build: `docker compose build`
3) Ingest docs (same as Session 1): 
   ```bash
   docker compose run --rm rag python ingest.py --data ./data
   ```
4) Ask a question with HyDE:
   ```bash
   docker compose run --rm rag python hyde_query.py --q "What counts as valid address proof?"
   ```

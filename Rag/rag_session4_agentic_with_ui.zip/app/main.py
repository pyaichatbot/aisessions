import os, re, json, sqlite3
from typing import List, Optional
from fastapi import FastAPI, UploadFile, File, Form, HTTPException, Depends, Header
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from dotenv import load_dotenv
import fitz
import chromadb
from chromadb.config import Settings
from sentence_transformers import SentenceTransformer
import requests

load_dotenv()
API_TOKEN=os.getenv("RAG_API_TOKEN","demo-token")
def require_token(x_api_token: str = Header(None)):
    if API_TOKEN and x_api_token != API_TOKEN:
        raise HTTPException(status_code=401, detail="Invalid API token")

# Vector + SQL like Session 3
PERSIST_PATH="./vectordb"; COLLECTION="docs"
client=chromadb.PersistentClient(path=PERSIST_PATH, settings=Settings(anonymized_telemetry=False))
coll=client.get_or_create_collection(COLLECTION)
embedder=SentenceTransformer(os.getenv("EMBEDDING_MODEL","all-MiniLM-L6-v2"))
SQLITE_PATH="./structured.db"
if not os.path.exists(SQLITE_PATH):
    conn=sqlite3.connect(SQLITE_PATH); c=conn.cursor()
    c.execute("CREATE TABLE IF NOT EXISTS policy(id INTEGER PRIMARY KEY, area TEXT, rule TEXT)")
    c.executemany("INSERT INTO policy(area,rule) VALUES(?,?)",[
        ("KYC","Documents must be stored for 5 years"),
        ("KYC","Address proof: recent utility bill or bank statement (<=3 months)"),
        ("UPI","OTP must expire within 180 seconds")
    ]); conn.commit(); conn.close()

def call_llm(messages, temp=0.2, max_tokens=420):
    base=os.getenv("LLM_API_BASE"); key=os.getenv("LLM_API_KEY"); ver=os.getenv("LLM_API_VERSION","2023-06-01")
    if not (base and key): raise HTTPException(status_code=500, detail="LLM endpoint not configured")
    url=f"{base}/chat/completions?api-version={ver}"
    r=requests.post(url,headers={"Content-Type":"application/json","api-key":key},
                    json={"messages":messages,"temperature":temp,"max_tokens":max_tokens},timeout=180)
    r.raise_for_status(); return r.json()["choices"][0]["message"]["content"]

def chunk_text(t, size=800, overlap=120):
    words=t.split(); out=[]; i=0
    while i<len(words):
        out.append(" ".join(words[i:i+size])); i+=max(1,size-overlap)
    return out

def add_to_vectorstore(chunks, source, tags):
    ids=[]; metas=[]; texts=[]
    start=coll.count()
    for i,ch in enumerate(chunks):
        ids.append(f"{source}-{start+i}"); texts.append(ch); metas.append({"source":source,"tags":tags})
    import numpy as np
    embs = embedder.encode(texts, convert_to_numpy=True)
    coll.add(ids=ids, documents=texts, metadatas=metas, embeddings=list(embs))

app = FastAPI(title="RAG Session 4 – Agentic", version="1.0")
app.mount("/", StaticFiles(directory="public", html=True), name="public")

class Query(BaseModel):
    question:str
    k:int=5
    filters:Optional[str]=""

@app.post("/ingest/file", dependencies=[Depends(require_token)])
async def ingest_file(file: UploadFile = File(...), tags: str = Form("")):
    name=file.filename; data=await file.read()
    text = ""
    if name.lower().endswith(".pdf"):
        with fitz.open(stream=data, filetype="pdf") as doc:
            for page in doc: text += page.get_text()
    else:
        text=data.decode("utf-8",errors="ignore")
    add_to_vectorstore(chunk_text(text), name, tags)
    return {"added_chunks": coll.count()}

@app.post("/agent_query", dependencies=[Depends(require_token)])
def agent_query(q: Query):
    logs=[]
    def log(step, detail): logs.append({"step":step,"detail":detail})

    # Step 1: Query Analyzer (LLM) -> decide which tools to call
    tools_desc = "Tools: [vector] retrieve doc chunks; [sql] query structured policy; [synthesize] compose final."
    plan = call_llm([
        {"role":"system","content": "You are a planner using ReAct. " + tools_desc + " Return a plan as numbered steps with which tools to use."},
        {"role":"user","content": f"Question: {q.question}"}
    ], temp=0.3, max_tokens=180)
    log("plan", plan)

    # Step 2: Vector retrieval always as first tool
    res = coll.query(query_texts=[q.question], n_results=q.k, include=["documents","metadatas"])
    docs=res["documents"][0]; metas=res["metadatas"][0]
    vec_context="\n\n".join([f"- {d} (src:{m['source']})" for d,m in zip(docs,metas)])
    log("vector", vec_context[:1000])

    # Step 3: Optional SQL tool (simple heuristic: if contains 'year','storage','otp','kyc')
    sql_context=""
    if re.search(r'year|store|otp|kyc|address', q.question, re.I):
        conn=sqlite3.connect(SQLITE_PATH); c=conn.cursor()
        c.execute("SELECT area,rule FROM policy"); sql_rows=c.fetchall(); conn.close()
        sql_context="\n".join([f"{a}: {r}" for a,r in sql_rows])
        log("sql", sql_context)

    # Step 4: Synthesize
    final = call_llm([
        {"role":"system","content":"Combine tools' results into a grounded answer with citations; if missing info, say so."},
        {"role":"user","content": f"Question: {q.question}\n\nVECTOR:\n{vec_context}\n\nSQL:\n{sql_context}\n\nProvide: answer + 3 bullets + sources."}
    ], temp=0.2, max_tokens=420)
    log("final", final)

    return {"answer": final, "trace": logs}

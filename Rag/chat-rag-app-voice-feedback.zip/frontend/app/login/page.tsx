
"use client";
import { useState } from "react";

const BACKEND = process.env.NEXT_PUBLIC_BACKEND_URL || "http://localhost:8000";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [token, setToken] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);

  async function register() {
    const res = await fetch(`${BACKEND}/api/auth/register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });
    if (res.ok) setMessage("Registered! Now login.");
    else setMessage(`Error: ${(await res.text())}`);
  }
  async function login() {
    const res = await fetch(`${BACKEND}/api/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });
    const data = await res.json();
    if (res.ok) {
      localStorage.setItem("token", data.access_token);
      setToken(data.access_token);
      window.location.href = "/";
    } else setMessage(`Error: ${JSON.stringify(data)}`);
  }

  return (
    <div className="max-w-md">
      <h2 className="text-2xl font-semibold">Login</h2>
      <p className="text-sm text-neutral-400 mb-6">Demo auth. Create or use an account.</p>
      <div className="space-y-3">
        <input placeholder="email" value={email} onChange={e => setEmail(e.target.value)} />
        <input placeholder="password" type="password" value={password} onChange={e => setPassword(e.target.value)} />
        <div className="flex gap-2">
          <button onClick={login}>Login</button>
          <button onClick={register}>Register</button>
        </div>
        {message && <p className="text-sm text-rose-400">{message}</p>}
      </div>
    </div>
  );
}

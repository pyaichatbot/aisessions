
import "./globals.css";
import { ReactNode } from "react";

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>
        <div className="min-h-screen grid grid-cols-[280px_1fr]">
          <aside className="border-r border-neutral-800 p-4">
            <h1 className="text-xl font-semibold">Chat+RAG</h1>
            <p className="text-xs text-neutral-400 mt-1">Enterprise demo</p>
            <nav className="mt-6 space-y-2">
              <a href="/" className="block hover:underline">Dashboard</a>
              <a href="/login" className="block hover:underline">Login</a>
            </nav>
            <footer className="absolute bottom-4 text-xs text-neutral-500">© {new Date().getFullYear()}</footer>
          </aside>
          <main className="p-6">{children}</main>
        </div>
      </body>
    </html>
  );
}


from .base import EmbeddingProvider
from openai import OpenAI
from ....config import settings

class OpenAIEmbeddingProvider(EmbeddingProvider):
    def __init__(self):
        if not settings.OPENAI_API_KEY:
            raise RuntimeError("OPENAI_API_KEY not set")
        self.client = OpenAI(api_key=settings.OPENAI_API_KEY)
        self.model = settings.EMBEDDING_MODEL or "text-embedding-3-small"

    def embed(self, texts):
        res = self.client.embeddings.create(model=self.model, input=texts)
        return [d.embedding for d in res.data]

    def dim(self) -> int:
        # best effort (most OpenAI small is 1536)
        return 1536

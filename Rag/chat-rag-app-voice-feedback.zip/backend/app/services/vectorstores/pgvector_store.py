
from .base import VectorStore
from typing import List, Dict
from sqlalchemy import text
from sqlalchemy.orm import Session
from ...db import SessionLocal
from ...config import settings

# Simple, single-table vector index per namespace
def _ensure_table(ns: str, dim: int, db: Session):
    tbl = f"vs_{ns}"
    db.execute(text(f"""
    CREATE TABLE IF NOT EXISTS {tbl} (
        id TEXT PRIMARY KEY,
        metadata JSONB,
        embedding vector({dim})
    );
    """))
    db.commit()

class PgVectorStore(VectorStore):
    def __init__(self, embedder):
        self.embedder = embedder

    def upsert(self, namespace, ids, vectors, metadatas):
        with SessionLocal() as db:
            dim = len(vectors[0])
            _ensure_table(namespace, dim, db)
            tbl = f"vs_{namespace}"
            for _id, v, meta in zip(ids, vectors, metadatas):
                db.execute(text(f"INSERT INTO {tbl} (id, metadata, embedding) VALUES (:id, :metadata, :embedding) "
                                f"ON CONFLICT (id) DO UPDATE SET metadata=EXCLUDED.metadata, embedding=EXCLUDED.embedding"),
                           {"id": _id, "metadata": meta, "embedding": v})
            db.commit()

    def query(self, namespace, vector, top_k=5):
        with SessionLocal() as db:
            tbl = f"vs_{namespace}"
            _ensure_table(namespace, len(vector), db)
            q = text(f"SELECT id, metadata, 1 - (embedding <=> :q) as score FROM {tbl} ORDER BY embedding <=> :q LIMIT :k")
            rows = db.execute(q, {"q": vector, "k": top_k}).fetchall()
            return [{"id": r[0], "metadata": r[1], "score": float(r[2])} for r in rows]

    def delete_namespace(self, namespace):
        with SessionLocal() as db:
            db.execute(text(f"DROP TABLE IF EXISTS vs_{namespace}"))
            db.commit()

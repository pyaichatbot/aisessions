
from .base import VectorStore
from pymilvus import connections, Collection, FieldSchema, CollectionSchema, DataType, utility
from ...config import settings

class MilvusVectorStore(VectorStore):
    def __init__(self, embedder):
        self.embedder = embedder
        connections.connect(alias="default", uri=f"tcp://{settings.MILVUS_URI}")

    def _ensure_collection(self, name: str, dim: int) -> Collection:
        fields = [
            FieldSchema(name="id", dtype=DataType.VARCHAR, is_primary=True, max_length=128),
            FieldSchema(name="embedding", dtype=DataType.FLOAT_VECTOR, dim=dim),
            FieldSchema(name="metadata", dtype=DataType.JSON),
        ]
        schema = CollectionSchema(fields, description="RAG Vectors")
        if not utility.has_collection(name):
            col = Collection(name, schema)
            col.create_index(field_name="embedding", index_params={"index_type":"HNSW","metric_type":"IP","params":{"M":8,"efConstruction":64}})
            col.load()
        else:
            col = Collection(name)
            col.load()
        return col

    def upsert(self, namespace, ids, vectors, metadatas):
        name = f"{settings.MILVUS_COLLECTION_PREFIX}_{namespace}"
        col = self._ensure_collection(name, len(vectors[0]))
        # Milvus doesn't have upsert; naive delete then insert
        # For demo purposes. In prod, maintain your own id mapping.
        if len(ids) > 0:
            try:
                col.delete(expr=f"id in {ids}")
            except Exception:
                pass
        col.insert([ids, vectors, metadatas])
        col.flush()

    def query(self, namespace, vector, top_k=5):
        name = f"{settings.MILVUS_COLLECTION_PREFIX}_{namespace}"
        col = self._ensure_collection(name, len(vector))
        res = col.search(data=[vector], anns_field="embedding", param={"metric_type":"IP","params":{"ef":64}}, limit=top_k, output_fields=["metadata"])
        out = []
        if res:
            for hit in res[0]:
                out.append({"id": hit.id, "score": float(hit.distance), "metadata": hit.entity.get("metadata")})
        return out

    def delete_namespace(self, namespace):
        name = f"{settings.MILVUS_COLLECTION_PREFIX}_{namespace}"
        if utility.has_collection(name):
            utility.drop_collection(name)


import os, io, uuid
from typing import List
from sqlalchemy.orm import Session
from ..models import Document, Chunk
from .chunking import extract_text_from_pdf, extract_text_from_html, extract_text_from_txt, chunk_text
from .embedding.base import EmbeddingProvider
from .vectorstores.base import VectorStore
from .storage import compute_sha256, save_file
from ..config import settings

ALLOWED = {
    "application/pdf": "pdf",
    "text/plain": "txt",
    "text/html": "html",
    "application/msword": "doc",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document": "docx"
}

def _extract_text(content: bytes, content_type: str) -> str:
    if content_type == "application/pdf":
        return extract_text_from_pdf(content)
    if content_type in ("text/plain", "text/markdown"):
        return extract_text_from_txt(content)
    if content_type in ("text/html", "application/xhtml+xml"):
        return extract_text_from_html(content)
    # naive fallback
    return content.decode("utf-8", errors="ignore")

def ingest_file(db: Session, user_id: int, filename: str, content_type: str, data: bytes,
                embedder: EmbeddingProvider, vstore: VectorStore) -> Document:
    if content_type not in ALLOWED and not content_type.startswith("text/") and not content_type.endswith("pdf"):
        raise ValueError(f"Unsupported content_type: {content_type}")

    sha = compute_sha256(io.BytesIO(data))
    uri = save_file(io.BytesIO(data), filename)

    doc = Document(user_id=user_id, filename=filename, uri=uri, content_type=content_type, size=len(data), sha256=sha)
    db.add(doc)
    db.flush()

    text = _extract_text(data, content_type)
    chunks = chunk_text(text, max_tokens=400, overlap=80)

    # embed + upsert
    vectors = embedder.embed(chunks)
    ns = f"user{user_id}"
    ids = []
    metas = []
    for i, (chunk, vec) in enumerate(zip(chunks, vectors)):
        cid = f"{doc.id}:{i}"
        ids.append(cid)
        metas.append({"type": "doc", "document_id": doc.id, "idx": i, "filename": filename, "source": filename, "text": chunk})
        ch = Chunk(document_id=doc.id, idx=i, text=chunk, metadata={"source": filename})
        db.add(ch)
    vstore.upsert(ns, ids, vectors, metas)
    db.commit()
    return doc

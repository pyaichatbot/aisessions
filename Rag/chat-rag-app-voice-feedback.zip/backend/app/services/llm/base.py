
from abc import ABC, abstractmethod
from typing import AsyncGenerator, List, Dict

class LLMProvider(ABC):
    @abstractmethod
    async def stream_generate(self, messages: List[Dict]) -> AsyncGenerator[str, None]:
        ...

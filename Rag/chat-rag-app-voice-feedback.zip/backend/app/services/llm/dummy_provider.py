
import asyncio
from typing import AsyncGenerator, List, Dict
from .base import LLMProvider

TEMPLATE = "Here is a thoughtful answer based on your context. "            "I'll cite relevant snippets and keep it concise."

class DummyProvider(LLMProvider):
    async def stream_generate(self, messages: List[Dict]) -> AsyncGenerator[str, None]:
        # Simulate token streaming
        for token in TEMPLATE.split(" "):
            yield token + " "
            await asyncio.sleep(0.03)

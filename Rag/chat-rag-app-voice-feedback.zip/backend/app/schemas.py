
from pydantic import BaseModel, EmailStr
from typing import Optional, List, Literal

class UserCreate(BaseModel):
    email: EmailStr
    password: str
    name: Optional[str] = None

class UserOut(BaseModel):
    id: int
    email: EmailStr
    name: Optional[str] = None
    class Config:
        from_attributes = True

class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"

class ConversationCreate(BaseModel):
    title: Optional[str] = None

class ConversationOut(BaseModel):
    id: int
    title: str
    class Config:
        from_attributes = True

class MessageCreate(BaseModel):
    content: str
    conversation_id: int

class DocumentOut(BaseModel):
    id: int
    filename: str
    uri: str
    content_type: str
    size: int
    class Config:
        from_attributes = True

class ChatStreamRequest(BaseModel):
    conversation_id: int
    message: str

class RetrievalItem(BaseModel):
    type: Literal["doc","memory"]
    id: str
    score: float
    snippet: str
    source: str

class FeedbackCreate(BaseModel):
    conversation_id: int
    message_id: int
    rating: Literal["up","down"]
    comment: Optional[str] = None

class FeedbackOut(BaseModel):
    id: int
    conversation_id: int
    message_id: int
    rating: Literal["up","down"]
    comment: Optional[str] = None
    class Config:
        from_attributes = True


from fastapi import APIRouter, UploadFile, File, Depends, HTTPException
from fastapi.responses import Response
from ..auth import get_current_user
from ..services.voice import STTClient, TTSClient

router = APIRouter(prefix="/api/voice", tags=["voice"])

@router.post("/transcribe")
async def transcribe(file: UploadFile = File(...), user=Depends(get_current_user)):
    data = await file.read()
    stt = STTClient()
    text = await stt.transcribe(file.filename, data)
    return {"text": text}

@router.post("/tts")
async def speak(text: str, user=Depends(get_current_user)):
    tts = TTSClient()
    audio, content_type = await tts.synth(text)
    return Response(content=audio, media_type=content_type)

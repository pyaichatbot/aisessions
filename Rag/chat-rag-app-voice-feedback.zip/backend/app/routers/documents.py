
from fastapi import APIRouter, Depends, UploadFile, File, HTTPException
from sqlalchemy.orm import Session
from ..db import get_db
from ..auth import get_current_user
from ..models import Document
from ..schemas import DocumentOut
from ..config import settings
from ..services.embedding.sentence_transformers_provider import SentenceTransformerProvider
from ..services.embedding.openai_provider import OpenAIEmbeddingProvider
from ..services.vectorstores.chroma_store import ChromaVectorStore
from ..services.vectorstores.pgvector_store import PgVectorStore
from ..services.vectorstores.milvus_store import MilvusVectorStore
from ..services.indexing import ingest_file

router = APIRouter(prefix="/api/documents", tags=["documents"])

def get_embedder():
    from ..config import settings
    if settings.EMBEDDING_PROVIDER == "openai":
        return OpenAIEmbeddingProvider()
    return SentenceTransformerProvider()

def get_vstore(embedder):
    from ..config import settings
    if settings.VECTOR_DB == "pgvector":
        return PgVectorStore(embedder)
    if settings.VECTOR_DB == "milvus":
        return MilvusVectorStore(embedder)
    return ChromaVectorStore(embedder)

@router.post("", response_model=DocumentOut)
async def upload_doc(file: UploadFile = File(...), db: Session = Depends(get_db), user=Depends(get_current_user)):
    content = await file.read()
    embedder = get_embedder()
    vstore = get_vstore(embedder)
    try:
        doc = ingest_file(db, user.id, file.filename, file.content_type or "application/octet-stream", content, embedder, vstore)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return doc

@router.get("", response_model=list[DocumentOut])
def list_docs(db: Session = Depends(get_db), user=Depends(get_current_user)):
    docs = db.query(Document).filter(Document.user_id==user.id).order_by(Document.created_at.desc()).all()
    return docs

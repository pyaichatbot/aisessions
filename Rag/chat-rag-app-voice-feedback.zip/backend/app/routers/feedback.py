
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from ..db import get_db
from ..auth import get_current_user
from ..models import Message, Feedback, Conversation
from ..schemas import FeedbackCreate, FeedbackOut

router = APIRouter(prefix="/api/feedback", tags=["feedback"])

@router.post("", response_model=FeedbackOut)
def create_feedback(payload: FeedbackCreate, db: Session = Depends(get_db), user=Depends(get_current_user)):
    msg = db.query(Message).filter(Message.id==payload.message_id).first()
    conv = db.query(Conversation).filter(Conversation.id==payload.conversation_id, Conversation.user_id==user.id).first()
    if not msg or not conv:
        raise HTTPException(404, "Message or conversation not found")
    fb = Feedback(user_id=user.id, conversation_id=conv.id, message_id=msg.id, rating=payload.rating, comment=payload.comment)
    db.add(fb); db.commit(); db.refresh(fb)
    return fb

@router.get("", response_model=list[FeedbackOut])
def list_feedback(db: Session = Depends(get_db), user=Depends(get_current_user)):
    fbs = db.query(Feedback).filter(Feedback.user_id==user.id).order_by(Feedback.created_at.desc()).all()
    return fbs

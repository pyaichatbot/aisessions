
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session
from ..db import get_db
from ..auth import get_current_user
from ..models import Conversation, Message
from ..schemas import ChatStreamRequest
from ..services.embedding.sentence_transformers_provider import SentenceTransformerProvider
from ..services.embedding.openai_provider import OpenAIEmbeddingProvider
from ..services.vectorstores.chroma_store import ChromaVectorStore
from ..services.vectorstores.pgvector_store import PgVectorStore
from ..services.vectorstores.milvus_store import MilvusVectorStore
from ..services.retrieval import Retriever, build_namespace
from ..services.sse import sse_event
from ..services.memory import MemoryService
from ..config import settings

from ..services.llm.dummy_provider import DummyProvider
from ..services.llm.openai_provider import OpenAIProvider
from ..services.llm.azure_openai_provider import AzureOpenAIProvider
from ..services.llm.ollama_provider import OllamaProvider

router = APIRouter(prefix="/api/chat", tags=["chat"])

def get_embedder():
    if settings.EMBEDDING_PROVIDER == "openai":
        return OpenAIEmbeddingProvider()
    return SentenceTransformerProvider()

def get_vstore(embedder):
    if settings.VECTOR_DB == "pgvector":
        return PgVectorStore(embedder)
    if settings.VECTOR_DB == "milvus":
        return MilvusVectorStore(embedder)
    return ChromaVectorStore(embedder)

def get_llm():
    if settings.LLM_PROVIDER == "openai":
        return OpenAIProvider()
    if settings.LLM_PROVIDER == "azure_openai":
        return AzureOpenAIProvider()
    if settings.LLM_PROVIDER == "ollama":
        return OllamaProvider()
    return DummyProvider()

@router.post("/stream")
def stream_chat(payload: ChatStreamRequest, db: Session = Depends(get_db), user=Depends(get_current_user)):
    conv = db.query(Conversation).filter(Conversation.id==payload.conversation_id, Conversation.user_id==user.id).first()
    if not conv:
        raise HTTPException(404, "Conversation not found")

    # Persist the user message
    m_user = Message(conversation_id=conv.id, user_id=user.id, role="user", content=payload.message)
    db.add(m_user); db.commit(); db.refresh(m_user)

    embedder = get_embedder()
    vstore = get_vstore(embedder)
    retriever = Retriever(embedder, vstore)
    llm = get_llm()
    memory = MemoryService()

    async def event_gen():
        # 1) Emit "thinking" status
        yield sse_event("status", {"phase":"thinking"})

        # 2) Retrieval
        items = retriever.search(user.id, payload.message, top_k=5)
        yield sse_event("retrieval", {"items":[i.model_dump() for i in items]})

        # 3) Build messages
        system = {"role":"system","content":"You are an enterprise assistant. Use provided context snippets if relevant. Cite sources briefly."}
        context = "\n\n".join([f"[{i.source}] {i.snippet}" for i in items])
        short = memory.get_short_summary(user.id, conv.id) or ""
        user_msg = {"role":"user","content": f"Short-memory: {short}\nContext:\n{context}\n\nUser question: {payload.message}"}
        messages = [system, user_msg]

        # 4) Emit "responding" status
        yield sse_event("status", {"phase":"responding"})

        # 5) Stream LLM tokens
        content_acc = ""
        async for tok in llm.stream_generate(messages):
            content_acc += tok
            yield sse_event("delta", tok)

        # 6) Save assistant message
        m_assist = Message(conversation_id=conv.id, user_id=None, role="assistant", content=content_acc)
        db.add(m_assist); db.commit()

        # 7) Update short memory (naive: last ~512 chars)
        memory.set_short_summary(user.id, conv.id, content_acc[-512:])

        yield sse_event("done", {"message_id": m_assist.id})

    return StreamingResponse(event_gen(), media_type="text/event-stream")

from fastmcp import MCPServer, tool
import os, glob

server = MCPServer("files-mcp")

@tool()
def list_files(path: str = "."):
    """List files (non-recursive) under a given path"""
    try:
        return glob.glob(os.path.join(path, "*"))[:200]
    except Exception as e:
        return {"error": str(e)}

@tool()
def read_file(path: str):
    """Read a small text file (first 32KB)"""
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            return f.read(32768)
    except Exception as e:
        return {"error": str(e)}

@tool()
def grep_text(path: str, pattern: str):
    """Search for a pattern (case-insensitive) in a text file"""
    try:
        out = []
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            for i, line in enumerate(f, 1):
                if pattern.lower() in line.lower():
                    out.append({"line": i, "text": line.strip()})
                    if len(out) >= 200:
                        break
        return out
    except Exception as e:
        return {"error": str(e)}

if __name__ == "__main__":
    server.run()

from fastapi import FastAPI
from pydantic import BaseModel
from typing import List, Dict
import os, glob, re
import chromadb
from chromadb.utils import embedding_functions

EMBEDDING_MODEL = os.environ.get("EMBEDDING_MODEL", "sentence-transformers/all-MiniLM-L6-v2")
CHROMA_PERSIST = os.environ.get("CHROMA_PERSIST", "/chroma")
DOC_DIR = "/app/data"

app = FastAPI(title="RAG Service (Chroma)", version="1.1.0")

client = chromadb.PersistentClient(path=CHROMA_PERSIST)
collection = client.get_or_create_collection(
    name="docs",
    metadata={"hnsw:space": "cosine"},
    embedding_function=embedding_functions.SentenceTransformerEmbeddingFunction(model_name=EMBEDDING_MODEL),
)

def _tokenize(text: str) -> List[str]:
    return re.findall(r"[\S\s]{1,500}", text)  # chunk every ~500 chars (simple)

def ingest():
    collection.delete(where={})  # clear
    docs = []
    ids = []
    metas = []
    for path in glob.glob(os.path.join(DOC_DIR, "*")):
        try:
            with open(path, "r", encoding="utf-8", errors="ignore") as f:
                text = f.read()
        except Exception:
            text = ""
        chunks = _tokenize(text)
        for i, ch in enumerate(chunks):
            ids.append(f"{path}-{i}")
            docs.append(ch)
            metas.append({"path": path, "chunk": i})
    if docs:
        collection.add(documents=docs, metadatas=metas, ids=ids)

class QueryIn(BaseModel):
    question: str
    k: int = 4

class Hit(BaseModel):
    score: float
    path: str
    chunk: int
    text: str

class QueryOut(BaseModel):
    hits: List[Hit]

@app.on_event("startup")
def startup():
    ingest()

@app.get("/health")
def health():
    return {"status": "ok", "count": collection.count(), "model": EMBEDDING_MODEL}

@app.post("/query", response_model=QueryOut)
def query(payload: QueryIn):
    q = payload.question
    res = collection.query(query_texts=[q], n_results=max(1, payload.k))
    out = []
    for score, md, doc in zip(res.get("distances", [[0]])[0], res.get("metadatas", [[{}]])[0], res.get("documents", [[""]])[0]):
        out.append({"score": float(1.0 - score if isinstance(score, (int, float)) else 0.0), "path": md.get("path", ""), "chunk": md.get("chunk", 0), "text": doc[:1000]})
    return {"hits": out}

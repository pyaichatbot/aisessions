# Session 8 — Agentic RAG (Enterprise Edition)

**Production-style demo** that combines:
- Semantic **RAG** (Sentence-Transformers + **Chroma**)
- **MCP** tools for local files **and** **GitLab**
- A Node orchestrator (LLM router + agent plan/act)
- A React UI that shows the **trace** of each step

Runs on **Windows + Docker**.

---

## 💡 What’s new vs the basic demo?
- RAG uses **sentence-transformers** embeddings with a real **vector DB (Chroma)**.
- Adds a **GitLab MCP server** (read-only) replacing the “cloud engine” in your diagram.
- Security guardrails: allowlisted project-IDs, env-based config, error handling, output caps.

---

## 🚀 Quick Start

1) Set env variables in `.env` (copy from `.env.example`).
2) Run:
```bash
docker compose --env-file .env up --build
```
3) Open UI: http://localhost:5173

### Try prompts
- **RAG:** “Summarize the onboarding policy”
- **GitLab MCP:** “Search code for login in project 123 (main)”
- **GitLab MCP (MR):** “Show diff of MR 42 in project 123”
- **Files MCP:** “List files under ./rag-service/data”
- **General:** “What is the capital of France?”

---

## 🗂 Structure
```
mcp-server/                 # local-file MCP tools (list/read/grep)
mcp-gitlab/                 # GitLab MCP tools (read-only)
rag-service/                # Chroma + sentence-transformers retriever
orchestrator/               # Node/TS agent + MCP client + RAG adapter
frontend/                   # React UI (timeline of steps)
docker-compose.yml
.env.example
```

---

## 🔐 Security / Guardrails
- GitLab MCP uses a read-only token (**read_api**) and **ALLOWED_PROJECTS** allowlist.
- Each MCP tool caps output length (avoid giant payloads).
- All tool calls are logged to stdout (can pipe to SIEM).
- No write operations enabled by default.

---

## 🧰 Notes
- The images will download the embedding model at **build time** to avoid runtime stalls.
- If your environment blocks internet, pre-seed a model mirror or swap to an offline model path.
- LLM synthesis is a heuristic by default; set `OPENAI_API_KEY` to use a real LLM.

from fastmcp import MCPServer, tool
import gitlab, os, time

GITLAB_URL = os.environ.get("GITLAB_URL")
GITLAB_TOKEN = os.environ.get("GITLAB_TOKEN")
ALLOWED = set([p.strip() for p in os.environ.get("ALLOWED_PROJECTS", "").split(",") if p.strip()])

if not (GITLAB_URL and GITLAB_TOKEN):
    print("[WARN] GITLAB_URL or GITLAB_TOKEN missing. Tools will return informative errors.")

gl = None
try:
    if GITLAB_URL and GITLAB_TOKEN:
        gl = gitlab.Gitlab(GITLAB_URL, private_token=GITLAB_TOKEN, timeout=10)
except Exception as e:
    print("[WARN] GitLab client init failed:", e)

srv = MCPServer("gitlab-mcp")

def _check_project(project_id: int):
    if ALLOWED and str(project_id) not in ALLOWED:
        raise ValueError(f"project_id {project_id} not allowlisted")

def _client():
    if not gl:
        raise RuntimeError("GitLab not configured. Set GITLAB_URL/GITLAB_TOKEN.")
    return gl

@srv.tool()
def gitlab_search_code(project_id: int, query: str, ref: str = "main", limit: int = 20):
    """Search code blobs by query within a project/ref (read-only)."""
    try:
        _check_project(project_id)
        proj = _client().projects.get(project_id)
        results = proj.search("blobs", query, ref=ref)[:limit]
        return [{"path": r.get("path"), "ref": ref, "project_id": project_id, "snippet": r.get("data", "")} for r in results]
    except Exception as e:
        return {"error": str(e)}

@srv.tool()
def gitlab_get_file(project_id: int, path: str, ref: str = "main"):
    """Fetch raw file contents (first 64KB) from project/ref (read-only)."""
    try:
        _check_project(project_id)
        proj = _client().projects.get(project_id)
        f = proj.files.get(file_path=path, ref=ref)
        content = f.decode().decode("utf-8", "ignore")[:65536]
        return {"path": path, "ref": ref, "content": content}
    except Exception as e:
        return {"error": str(e)}

@srv.tool()
def gitlab_list_mrs(project_id: int, state: str = "opened", limit: int = 20):
    """List merge requests for a project (read-only)."""
    try:
        _check_project(project_id)
        proj = _client().projects.get(project_id)
        mrs = proj.mergerequests.list(state=state, per_page=min(limit, 100))
        out = [{"iid": mr.iid, "title": mr.title, "author": getattr(mr, 'author', {}).get('name', ''), "web_url": mr.web_url} for mr in mrs[:limit]]
        return out
    except Exception as e:
        return {"error": str(e)}

@srv.tool()
def gitlab_get_mr_diff(project_id: int, mr_iid: int):
    """Get unified diff/changes for a merge request (read-only)."""
    try:
        _check_project(project_id)
        proj = _client().projects.get(project_id)
        mr = proj.mergerequests.get(mr_iid)
        changes = mr.changes().get("changes", [])
        # Cap output
        for ch in changes:
            for k in ("diff",):
                if k in ch and isinstance(ch[k], str) and len(ch[k]) > 65536:
                    ch[k] = ch[k][:65536] + "\n... [truncated]"
        return {"mr": mr_iid, "changes": changes}
    except Exception as e:
        return {"error": str(e)}

if __name__ == "__main__":
    srv.run()

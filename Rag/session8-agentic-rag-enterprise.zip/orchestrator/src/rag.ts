const RAG_SERVICE_URL = process.env.RAG_SERVICE_URL || "http://rag-service:8000";

export async function ragQuery(question: string, k = 4) {
  const res = await fetch(`${RAG_SERVICE_URL}/query`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ question, k })
  });
  if (!res.ok) return { hits: [] };
  return await res.json();
}

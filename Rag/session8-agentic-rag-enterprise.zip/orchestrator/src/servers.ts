import { createClient } from "mcp-use";

let filesClientPromise: Promise<any> | null = null;
let gitlabClientPromise: Promise<any> | null = null;

async function filesClient() {
  if (!filesClientPromise) {
    filesClientPromise = createClient({ command: "python", args: ["mcp-server/server.py"] });
  }
  return filesClientPromise;
}

async function gitlabClient() {
  if (!gitlabClientPromise) {
    // Spawn local GitLab MCP server via stdio; inherits env (GITLAB_URL/TOKEN)
    gitlabClientPromise = createClient({ command: "python", args: ["mcp-gitlab/server_gitlab.py"] });
  }
  return gitlabClientPromise;
}

export async function runFilesMcpTool(tool: string, args: any) {
  const c = await filesClient();
  return await c.callTool(tool, args);
}

export async function runGitlabMcpTool(tool: string, args: any) {
  const c = await gitlabClient();
  return await c.callTool(tool, args);
}

import { callLLM, synthesizeFromChunks } from "./llm.js";
import { runFilesMcpTool, runGitlabMcpTool } from "./servers.js";
import { ragQuery } from "./rag.js";

export async function routeMessage(message: string) {
  const events: any[] = [];
  events.push({ type: "plan", data: { message } });

  const lower = message.toLowerCase();
  const isGitlab = /(gitlab|mr|merge request|pipeline|diff|repo|project)/i.test(lower);
  const isFiles = /(list|read|grep|file)/i.test(lower);
  const isRag = /(policy|document|summarize|explain|onboarding|guidelines)/i.test(lower);

  if (isGitlab) {
    events.push({ type: "decision", data: { path: "mcp:gitlab" } });
    // Simple intent mapping
    let tool = "gitlab_search_code";
    let args: any = { project_id: 0, query: "login", ref: "main" };
    const projMatch = lower.match(/project\s+(\d+)/);
    if (projMatch) args.project_id = parseInt(projMatch[1], 10);
    if (/diff|mr\s*!?(\d+)/.test(lower)) {
      tool = "gitlab_get_mr_diff";
      const m = lower.match(/mr\s*!?(\d+)/);
      args = { project_id: args.project_id, mr_iid: m ? parseInt(m[1], 10) : 1 };
    } else if (/open mrs|list mrs|mrs/.test(lower)) {
      tool = "gitlab_list_mrs";
      args = { project_id: args.project_id, state: "opened" };
    } else if (/get file/.test(lower)) {
      tool = "gitlab_get_file";
      args = { project_id: args.project_id, path: "README.md", ref: "main" };
    }
    const result = await runGitlabMcpTool(tool, args);
    events.push({ type: "tool_result", data: { tool, args, result } });
    const answer = await callLLM(`Summarize GitLab ${tool} result: ${JSON.stringify(result).slice(0, 800)}`);
    events.push({ type: "final", data: { answer } });
    return { mode: "agent_mcp_gitlab", events, answer };
  }

  if (isFiles) {
    events.push({ type: "decision", data: { path: "mcp:files" } });
    const tool = /list/.test(lower) ? "list_files" : /read/.test(lower) ? "read_file" : "grep_text";
    const args =
      tool === "list_files"
        ? { path: "./rag-service/data" }
        : tool === "read_file"
        ? { path: "./rag-service/data/OnboardingPolicy.md" }
        : { path: "./rag-service/data/LoginGuide.md", pattern: "login" };
    const result = await runFilesMcpTool(tool, args);
    events.push({ type: "tool_result", data: { tool, args, result } });
    const answer = await callLLM(`User asked: ${message}. Tool ${tool} returned: ${JSON.stringify(result).slice(0, 500)}.`);
    events.push({ type: "final", data: { answer } });
    return { mode: "agent_mcp_files", events, answer };
  }

  if (isRag) {
    events.push({ type: "decision", data: { path: "rag" } });
    const rag = await ragQuery(message);
    events.push({ type: "retrieval_result", data: rag });
    const answer = await synthesizeFromChunks(message, rag.hits);
    events.push({ type: "final", data: { answer } });
    return { mode: "agent_rag", events, answer };
  }

  events.push({ type: "decision", data: { path: "llm" } });
  const answer = await callLLM(message);
  events.push({ type: "final", data: { answer } });
  return { mode: "llm", events, answer };
}

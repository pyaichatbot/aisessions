import express from "express";
import cors from "cors";
import { routeMessage } from "./router.js";

const app = express();
app.use(cors());
app.use(express.json());

app.post("/chat", async (req, res) => {
  const { message } = req.body;
  const result = await routeMessage(message || "");
  res.json(result);
});

app.listen(3000, () => console.log("Orchestrator on http://localhost:3000"));

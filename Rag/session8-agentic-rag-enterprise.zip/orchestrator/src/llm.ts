// Placeholder LLM call; plug in OpenAI/Azure if key present.
export async function callLLM(prompt: string): Promise<string> {
  return `Assistant (heuristic): ${prompt}`;
}

export async function synthesizeFromChunks(question: string, hits: any[]): Promise<string> {
  const bullets = hits.map(h => `• (${h.score.toFixed(3)}) ${h.path.split('/').pop()}#${h.chunk}: ${h.text.slice(0,120)}...`).join('\n');
  return `Answer synthesized for: "${question}"\n${bullets}`;
}

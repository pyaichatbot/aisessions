import os, argparse, numpy as np
from app.utils import iter_corpus_files, read_text_from_path, chunk_text, chunk_hash
from app.embeddings import embed_texts, floats_to_binary_codes
from app.store_float import FloatStore
from app.store_binary import BinaryStore

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--corpus", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--max_chars", type=int, default=1200)
    ap.add_argument("--overlap", type=int, default=200)
    args = ap.parse_args()

    float_store = FloatStore(args.out)
    bin_store = BinaryStore(args.out)

    metas, chunks = [], []
    for path in iter_corpus_files(args.corpus):
        text = read_text_from_path(path)
        if not text.strip():
            continue
        for idx, chunk in enumerate(chunk_text(text, max_chars=args.max_chars, overlap=args.overlap)):
            metas.append({
                "id": chunk_hash(chunk),
                "doc_path": os.path.relpath(path, args.corpus),
                "chunk_id": idx,
                "chunk": chunk
            })
            chunks.append(chunk)

    if not chunks:
        print("No ingestible content found.")
        return

    print(f"Embedding {len(chunks)} chunks...")
    vecs = embed_texts(chunks)

    print("Saving float index...")
    float_store.add(metas, vecs)

    print("Building binary codes...")
    packed = floats_to_binary_codes(vecs)
    bin_store.add(metas, packed)

    print("Done. Store at:", args.out)

if __name__ == "__main__":
    main()

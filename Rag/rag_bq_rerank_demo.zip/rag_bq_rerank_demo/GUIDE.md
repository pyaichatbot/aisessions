# Beginner Guide: RAG + BQ + Rerank

## What is Embedding?
Embeddings convert text into numbers that capture meaning. Like GPS for ideas.

## What is Chunking?
Splitting large documents into smaller pieces so retrieval works better.

## What is Retrieval?
Finding the most relevant chunks for your query using similarity search.

## What is Binary Quantization?
Compressing embeddings into 1-bit codes (32x smaller). Faster search, slightly less precise.

## What is Reranking?
Refining the top-k retrieved docs with a stronger model to ensure the best results.

## Why these models?
- all-MiniLM-L6-v2: lightweight, fast embeddings for demo.
- ms-marco-MiniLM-L-6-v2: efficient reranker.

---

## UI Screenshots

### Home Screen
![UI Home](assets/ui_home.png)

### Naive RAG Result
![Naive Result](assets/ui_result_naive.png)

### BQ + Rerank Result
![Rerank Result](assets/ui_result_rerank.png)

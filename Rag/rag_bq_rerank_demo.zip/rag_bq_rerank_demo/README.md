# RAG + BQ + Rerank Demo

Run with docker-compose up --build then open http://localhost:8080

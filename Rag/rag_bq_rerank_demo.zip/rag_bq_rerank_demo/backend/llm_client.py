# REST client for LLM integration (placeholder)

from sentence_transformers import CrossEncoder

_model = None
MODEL_NAME = "cross-encoder/ms-marco-MiniLM-L-6-v2"

def get_reranker():
    global _model
    if _model is None:
        _model = CrossEncoder(MODEL_NAME)
    return _model

def rerank(query: str, passages, top_k: int = 3):
    model = get_reranker()
    pairs = [(query, p) for p in passages]
    scores = model.predict(pairs).tolist()
    idx = sorted(range(len(scores)), key=lambda i: -scores[i])[:top_k]
    return [(i, float(scores[i])) for i in idx]

import os, requests

def draft_hypothetical_answer(query: str) -> str:
    az_ep = os.getenv("AZURE_OPENAI_ENDPOINT")
    az_key = os.getenv("AZURE_OPENAI_API_KEY")
    az_deploy = os.getenv("AZURE_OPENAI_DEPLOYMENT")
    if az_ep and az_key and az_deploy:
        try:
            url = f"{az_ep}/openai/deployments/{az_deploy}/chat/completions?api-version=2024-02-15-preview"
            headers = {"api-key": az_key, "Content-Type": "application/json"}
            body = {
                "messages": [
                    {"role": "system", "content": "You generate terse, factual summaries."},
                    {"role": "user", "content": f"Draft a short, neutral answer (3-5 sentences) to: {query}"}
                ],
                "temperature": 0.2,
                "max_tokens": 200
            }
            resp = requests.post(url, headers=headers, json=body, timeout=20)
            data = resp.json()
            return data["choices"][0]["message"]["content"].strip()
        except Exception:
            pass
    key = os.getenv("OPENAI_API_KEY")
    model = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
    if key:
        try:
            url = "https://api.openai.com/v1/chat/completions"
            headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
            body = {
                "model": model,
                "messages": [
                    {"role": "system", "content": "You generate terse, factual summaries."},
                    {"role": "user", "content": f"Draft a short, neutral answer (3-5 sentences) to: {query}"}
                ],
                "temperature": 0.2,
                "max_tokens": 200
            }
            resp = requests.post(url, headers=headers, json=body, timeout=20)
            data = resp.json()
            return data["choices"][0]["message"]["content"].strip()
        except Exception:
            pass
    return query

from fastapi import FastAPI
from pydantic import BaseModel
from typing import List, Optional
import os
from app.embeddings import embed_texts, floats_to_binary_codes
from app.store_float import FloatStore
from app.store_binary import BinaryStore
from app.reranker import rerank
from app.hyde import draft_hypothetical_answer
from app.generator import generate_answer
from app.utils import iter_corpus_files, read_text_from_path, chunk_text, chunk_hash

app = FastAPI(title="RAG + BQ + Rerank Demo API")

class IngestReq(BaseModel):
    corpus_dir: str
    store_dir: str
    max_chars: int = 1200
    overlap: int = 200

class QueryReq(BaseModel):
    store_dir: str
    question: str
    mode: str = "naive"
    k: int = 5
    candidates: int = 20

@app.post("/ingest")
def ingest(req: IngestReq):
    fs = FloatStore(req.store_dir)
    bs = BinaryStore(req.store_dir)
    metas, chunks = [], []
    for path in iter_corpus_files(req.corpus_dir):
        text = read_text_from_path(path)
        if not text.strip():
            continue
        for idx, ch in enumerate(chunk_text(text, req.max_chars, req.overlap)):
            metas.append({"id": chunk_hash(ch), "doc_path": os.path.relpath(path, req.corpus_dir), "chunk_id": idx, "chunk": ch})
            chunks.append(ch)
    if not chunks:
        return {"status":"no_content"}
    vecs = embed_texts(chunks)
    fs.add(metas, vecs)
    packed = floats_to_binary_codes(vecs)
    bs.add(metas, packed)
    return {"status":"ok", "chunks": len(chunks)}

@app.post("/query")
def query(req: QueryReq):
    mode = req.mode
    if mode in ("naive","hyde"):
        fs = FloatStore(req.store_dir); fs.load()
        question = req.question
        effective = question
        if mode == "hyde":
            effective = draft_hypothetical_answer(question)
        qv = embed_texts([effective])[0]
        results = fs.search(qv, top_k=max(req.k, req.candidates))
        metas = [{"score": float(s), **m} for (m,s) in results[:req.k]]
        answer = generate_answer(req.question, metas)
        return {"mode": mode, "hypo": effective if mode=="hyde" else None, "results": metas, "answer": answer}

    elif mode in ("bq","bq_rerank"):
        fs = FloatStore(req.store_dir); fs.load()
        bs = BinaryStore(req.store_dir); bs.load()
        qv = embed_texts([req.question])[0].reshape(1,-1)
        qb = floats_to_binary_codes(qv)[0].reshape(1,-1)
        results = bs.search(qb, top_k=max(req.k, req.candidates))
        metas = [m for (m,_) in results]
        if mode == "bq_rerank":
            passages = [m["chunk"] for m in metas[:req.candidates]]
            rer = rerank(req.question, passages, top_k=req.k)
            final = [{"score": float(score), **metas[idx]} for (idx, score) in rer]
        else:
            final = [{"score": float(score), **m} for (m,score) in results[:req.k]]
        answer = generate_answer(req.question, final)
        return {"mode": mode, "results": final, "answer": answer}

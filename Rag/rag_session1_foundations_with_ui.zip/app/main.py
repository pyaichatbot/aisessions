import os
from typing import List, Optional
from fastapi import FastAPI, UploadFile, File, Form, HTTPException, Depends, Header
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from dotenv import load_dotenv
import chromadb
from chromadb.config import Settings
from sentence_transformers import SentenceTransformer
import requests

load_dotenv()

PERSIST_PATH = os.getenv("CHROMA_PATH", "./vectordb")
COLLECTION = os.getenv("CHROMA_COLLECTION", "docs")
EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "all-MiniLM-L6-v2")

LLM_API_BASE = os.getenv("LLM_API_BASE")
LLM_API_KEY = os.getenv("LLM_API_KEY")
LLM_API_VERSION = os.getenv("LLM_API_VERSION", "2023-06-01")
API_TOKEN = os.getenv("RAG_API_TOKEN", "demo-token")

client = chromadb.PersistentClient(path=PERSIST_PATH, settings=Settings(anonymized_telemetry=False))
coll = client.get_or_create_collection(COLLECTION)
embedder = SentenceTransformer(EMBEDDING_MODEL)

app = FastAPI(title="RAG Foundations API", version="1.1.0")
app.mount("/", StaticFiles(directory="public", html=True), name="public")

def require_token(x_api_token: str = Header(None)):
    if API_TOKEN and x_api_token != API_TOKEN:
        raise HTTPException(status_code=401, detail="Invalid API token")

class IngestTextRequest(BaseModel):
    texts: List[str]
    sources: Optional[List[str]] = None

class QueryRequest(BaseModel):
    question: str
    k: int = 4

def _chunk_text(text: str, chunk_size=800, overlap=120):
    words = text.split()
    chunks=[]; i=0
    while i < len(words):
        chunk = " ".join(words[i:i+chunk_size])
        chunks.append(chunk); i += max(1, chunk_size-overlap)
    return chunks

def _call_llm(messages):
    if not (LLM_API_BASE and LLM_API_KEY):
        raise HTTPException(status_code=500, detail="LLM endpoint keys missing")
    url = f"{LLM_API_BASE}/chat/completions?api-version={LLM_API_VERSION}"
    payload = {"messages": messages, "temperature": 0.2, "max_tokens": 400}
    headers = {"Content-Type":"application/json","api-key": LLM_API_KEY}
    r = requests.post(url, headers=headers, json=payload, timeout=120)
    r.raise_for_status()
    return r.json()["choices"][0]["message"]["content"]

@app.get("/health", dependencies=[Depends(require_token)])
def health():
    return {"ok": True, "collection_size": coll.count(), "model": EMBEDDING_MODEL}

@app.post("/ingest/text", dependencies=[Depends(require_token)])
def ingest_text(req: IngestTextRequest):
    ids=[]; docs=[]; metas=[]; idx=coll.count()
    for i,text in enumerate(req.texts):
        for ch in _chunk_text(text):
            ids.append(f"doc-{idx}"); docs.append(ch)
            src = (req.sources[i] if (req.sources and i < len(req.sources)) else "uploaded")
            metas.append({"source": src}); idx += 1
    embs = embedder.encode(docs, convert_to_numpy=True)
    coll.add(ids=ids, embeddings=list(embs), documents=docs, metadatas=metas)
    return {"added_chunks": len(docs), "collection_size": coll.count()}

@app.post("/ingest/file", dependencies=[Depends(require_token)])
async def ingest_file(file: UploadFile = File(...), source: str = Form("uploaded_file")):
    text = (await file.read()).decode("utf-8", errors="ignore")
    return ingest_text(IngestTextRequest(texts=[text], sources=[source]))

@app.post("/query", dependencies=[Depends(require_token)])
def query(req: QueryRequest):
    q_emb = embedder.encode([req.question])[0]
    res = coll.query(query_embeddings=[q_emb], n_results=req.k, include=["documents","metadatas","distances"])
    docs = res["documents"][0]; metas = res["metadatas"][0]; dists = res["distances"][0]

    context = ""
    for i,(d,m,dist) in enumerate(zip(docs,metas,dists), start=1):
        context += f"### Chunk {i} (source: {m['source']}, distance: {dist:.3f})\n{d}\n\n"

    msgs = [
        {"role":"system","content":"Answer strictly from the context. If not present, say 'Not found in context.'"},
        {"role":"user","content": f"Question: {req.question}\n\nContext:\n{context}\nReturn answer + 3 bullets + cite sources."}
    ]
    ans = _call_llm(msgs)
    return {"answer": ans, "sources":[m["source"] for m in metas], "distances": dists}


# Session 1 — Traditional RAG + Corrective Loop (FastAPI)

This project implements a baseline Retrieval-Augmented Generation (RAG) API with a **corrective verification loop** to reduce hallucinations.

## Features
- FastAPI server with endpoints:
  - `POST /ingest` — upload plain text or PDF (text-extract only) files
  - `POST /query` — ask a question; returns draft answer, verification score, and (if needed) refined answer
- Vector store: **ChromaDB** (local persistent)
- Embeddings: **sentence-transformers/all-MiniLM-L6-v2** (lightweight)
- Corrective loop: evaluates groundedness; if low → expands retrieval → regenerates
- Citations format: `[doc_id::chunk_id]`

## Quickstart
```bash
# 1) Build & run
docker build -t rag-corrective:latest .
docker run -p 8001:8001 -v $(pwd)/chroma_db:/app/chroma_db rag-corrective:latest

# 2) Ingest sample docs
curl -X POST http://localhost:8001/ingest -F "files=@sample_docs/policy.txt" -F "files=@sample_docs/guide.txt"

# 3) Query
curl -X POST http://localhost:8001/query -H "Content-Type: application/json" -d '{"query":"What are the password rules?"}'
```

## Endpoints
- **/ingest**: accepts multiple files; chunks text; upserts to Chroma with metadata.
- **/query**: adaptive top_k (starts at 6). If groundedness < 0.72 → broaden to 12 and regenerate.

## Notes
- PDFs are handled via `pypdf` (text-only). For OCR, see Session 2 project.


from fastapi import FastAPI, UploadFile, File
from fastapi import Body
from typing import List, Dict, Any
from pydantic import BaseModel
import os
from .rag import RAGStore
from .chunking import simple_chunks
from .eval import groundedness_score, make_prompt
from pypdf import PdfReader
import io

# Replace this LLM call with your provider (OpenAI/Azure/etc.)
def llm_infer(prompt: str, temperature: float = 0.2) -> str:
    # Minimal local stub for demo: echoes the first few lines + fake citations based on context keys.
    # In production, call your LLM here.
    lines = prompt.splitlines()
    # Try to collect some [doc::chunk] keys from context to mimic citations
    import re
    keys = re.findall(r'\[(.+?::c\d+)\]', prompt)
    cite = f"[{keys[0]}]" if keys else ""
    return f"""- (demo) This is a stubbed answer citing context {cite}. 
- Replace llm_infer() with a real model for production."""

app = FastAPI(title="RAG + Corrective Demo")

store = RAGStore()

@app.post("/ingest")
async def ingest(files: List[UploadFile] = File(...)):
    total_chunks = 0
    for f in files:
        content = await f.read()
        doc_id = os.path.splitext(f.filename)[0]
        text = ""
        if f.filename.lower().endswith(".pdf"):
            reader = PdfReader(io.BytesIO(content))
            for p in reader.pages:
                text += (p.extract_text() or "") + "\n"
        else:
            text = content.decode("utf-8", errors="ignore")
        chunks = simple_chunks(text, doc_id, size=700, overlap=100)
        total_chunks += len(chunks)
        store.upsert_chunks(chunks)
    return {"status": "ok", "chunks_indexed": total_chunks}

class QueryIn(BaseModel):
    query: str
    top_k: int = 6

@app.post("/query")
async def query(q: QueryIn):
    # 1) initial retrieval
    retrieved = store.query(q.query, top_k=q.top_k)
    prompt = make_prompt(q.query, retrieved)
    draft = llm_infer(prompt, temperature=0.2)

    g = groundedness_score(draft)
    if g < 0.72:
        # corrective: broaden recall and regenerate
        retrieved2 = store.query(q.query, top_k=min(12, q.top_k + 6))
        prompt2 = make_prompt(q.query, retrieved2)
        refined = llm_infer(prompt2, temperature=0.2)
        g2 = groundedness_score(refined)
        return {
            "strategy": "corrective_refine",
            "draft_answer": draft,
            "draft_groundedness": round(g, 3),
            "refined_answer": refined,
            "refined_groundedness": round(g2, 3),
            "used_topk": len(retrieved2),
        }
    else:
        return {
            "strategy": "single_pass",
            "answer": draft,
            "groundedness": round(g, 3),
            "used_topk": len(retrieved),
        }


from typing import List, Dict, Any
import os
import chromadb
from chromadb.config import Settings
from sentence_transformers import SentenceTransformer

CHROMA_DIR = os.environ.get("CHROMA_DIR", "./chroma_db")
COLLECTION = "docs"

class RAGStore:
    def __init__(self):
        self._client = chromadb.PersistentClient(path=CHROMA_DIR, settings=Settings(anonymized_telemetry=False))
        self._coll = self._client.get_or_create_collection(COLLECTION, metadata={"hnsw:space":"cosine"})
        self._embed = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")

    def upsert_chunks(self, chunks: List[Dict[str, Any]]):
        ids = [c["chunk_id"] for c in chunks]
        docs = [c["text"] for c in chunks]
        metas = [c["metadata"] | {"doc_id": c["doc_id"], "chunk_id": c["chunk_id"]} for c in chunks]
        embs = self._embed.encode(docs, normalize_embeddings=True).tolist()
        self._coll.upsert(ids=ids, documents=docs, metadatas=metas, embeddings=embs)

    def query(self, q: str, top_k: int = 6) -> List[Dict[str, Any]]:
        qv = self._embed.encode([q], normalize_embeddings=True).tolist()
        res = self._coll.query(query_embeddings=qv, n_results=top_k, include=["documents", "metadatas", "distances", "embeddings"])
        out = []
        for i in range(len(res["ids"][0])):
            meta = res["metadatas"][0][i]
            out.append({
                "doc_id": meta["doc_id"],
                "chunk_id": meta["chunk_id"],
                "text": res["documents"][0][i],
                "metadata": meta,
                "distance": res["distances"][0][i]
            })
        return out

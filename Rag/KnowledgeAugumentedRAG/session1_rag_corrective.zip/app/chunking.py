
from typing import List, Dict
import re

def simple_chunks(text: str, doc_id: str, size: int = 700, overlap: int = 100):
    words = re.split(r"(\s+)", text)
    chunks = []
    buf = []
    token_count = 0
    i = 0
    chunk_id = 0
    while i < len(words):
        w = words[i]
        buf.append(w)
        token_count += len(w)
        if token_count >= size:
            start = max(0, i - overlap)
            chunk_text = "".join(buf).strip()
            if chunk_text:
                chunks.append({
                    "doc_id": doc_id,
                    "chunk_id": f"{doc_id}::c{chunk_id}",
                    "text": chunk_text,
                    "metadata": {"seq": chunk_id}
                })
                chunk_id += 1
            buf = words[start:i]
            token_count = sum(len(x) for x in buf)
        i += 1
    # last
    tail = "".join(buf).strip()
    if tail:
        chunks.append({
            "doc_id": doc_id,
            "chunk_id": f"{doc_id}::c{chunk_id}",
            "text": tail,
            "metadata": {"seq": chunk_id}
        })
    return chunks

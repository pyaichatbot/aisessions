
import re
from typing import List, Dict

def groundedness_score(answer: str) -> float:
    sents = [s.strip() for s in re.split(r'(?<=[.?!])\s+', answer) if s.strip()]
    if not sents: return 0.0
    cited = sum(1 for s in sents if re.search(r'\[[^\]]+::[^\]]+\]', s))
    return cited / len(sents)

def make_prompt(query: str, retrieved: List[Dict]) -> str:
    ctx = "\n---\n".join(f"[{c['doc_id']}::{c['chunk_id']}] {c['text']}" for c in retrieved)
    return f"""You are a careful assistant.
Only answer using the provided CONTEXT. If not answerable, say 'I don't have enough information.'
Always cite as [doc_id::chunk_id] after each claim.

QUESTION:
{query}

CONTEXT:
{ctx}

Now produce a concise answer with bullet points and citations."""

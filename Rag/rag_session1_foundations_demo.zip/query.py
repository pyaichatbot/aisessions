
import os, argparse, json
import chromadb
from chromadb.config import Settings
from sentence_transformers import SentenceTransformer
import requests

def call_llm(messages):
    base = os.getenv("LLM_API_BASE")
    key = os.getenv("LLM_API_KEY")
    api_version = os.getenv("LLM_API_VERSION","2023-06-01")
    url = f"{base}/chat/completions?api-version={api_version}"
    payload = {"messages": messages, "temperature": 0.2, "max_tokens": 400}
    headers = {"Content-Type":"application/json", "api-key": key}
    r = requests.post(url, headers=headers, json=payload, timeout=120)
    r.raise_for_status()
    data = r.json()
    return data["choices"][0]["message"]["content"]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--q", required=True, help="Question")
    ap.add_argument("--persist", default="./vectordb")
    ap.add_argument("--collection", default="docs")
    ap.add_argument("--k", type=int, default=4)
    args = ap.parse_args()

    client = chromadb.PersistentClient(path=args.persist, settings=Settings(anonymized_telemetry=False))
    coll = client.get_or_create_collection(args.collection)
    embedder = SentenceTransformer(os.getenv("EMBEDDING_MODEL","all-MiniLM-L6-v2"))

    q_emb = embedder.encode([args.q])[0]
    res = coll.query(query_embeddings=[q_emb], n_results=args.k, include=["documents","metadatas","distances"])
    docs = res["documents"][0]
    metas = res["metadatas"][0]
    distances = res["distances"][0]

    context = ""
    for i,(d,m,dist) in enumerate(zip(docs, metas, distances), start=1):
        context += f"### Chunk {i} (source: {m['source']}, distance: {dist:.3f})\n{d}\n\n"

    prompt = [
        {"role":"system","content":"You answer strictly using the provided context. If missing info, say 'Not found in context.'"},
        {"role":"user","content": f"Question: {args.q}\n\nContext:\n{context}\nReturn answer + 3 bullet key points + cite source file names."}
    ]

    answer = call_llm(prompt)
    print("\n===== ANSWER =====\n", answer)
    print("\n===== SOURCES =====")
    for m in metas:
        print("-", m["source"])

if __name__ == "__main__":
    main()

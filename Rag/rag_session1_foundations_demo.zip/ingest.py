
import os, argparse, glob, re
import chromadb
from chromadb.config import Settings
from sentence_transformers import SentenceTransformer
from pathlib import Path

def chunk_text(text, chunk_size=800, overlap=120):
    words = text.split()
    chunks = []
    i = 0
    while i < len(words):
        chunk = ' '.join(words[i:i+chunk_size])
        chunks.append(chunk)
        i += chunk_size - overlap
    return chunks

def load_docs(data_dir):
    docs = []
    for p in glob.glob(os.path.join(data_dir, "**", "*"), recursive=True):
        if os.path.isdir(p): 
            continue
        ext = os.path.splitext(p)[1].lower()
        if ext in ['.txt', '.md']:
            text = Path(p).read_text(encoding='utf-8', errors='ignore')
            docs.append((p, text))
    return docs

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True, help="Folder with .txt/.md files")
    ap.add_argument("--persist", default="./vectordb", help="Chroma persistence dir")
    ap.add_argument("--collection", default="docs", help="Collection name")
    args = ap.parse_args()

    os.makedirs(args.persist, exist_ok=True)

    client = chromadb.PersistentClient(path=args.persist, settings=Settings(anonymized_telemetry=False))
    coll = client.get_or_create_collection(args.collection)

    embedder = SentenceTransformer(os.getenv("EMBEDDING_MODEL", "all-MiniLM-L6-v2"))

    print("Loading documents from", args.data)
    docs = load_docs(args.data)
    print(f"Found {len(docs)} files")

    ids, texts, metas = [], [], []
    idx = 0
    for fname, text in docs:
        for chunk in chunk_text(text):
            ids.append(f"{fname}-{idx}")
            texts.append(chunk)
            metas.append({"source": fname})
            idx += 1

    print(f"Embedding {len(texts)} chunks…")
    embs = embedder.encode(texts, convert_to_numpy=True, show_progress_bar=True)
    coll.add(ids=ids, embeddings=list(embs), documents=texts, metadatas=metas)
    print("✅ Ingestion complete. Collection size:", coll.count())

if __name__ == "__main__":
    main()

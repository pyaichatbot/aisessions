
# RAG Foundations Demo (Session 1)
This demo shows **Naive RAG** end-to-end with local embeddings + Chroma vector store and an OpenAI-compatible LLM endpoint.

## Quick start
1) Copy `.env.example` → `.env` and set your `LLM_API_BASE` and `LLM_API_KEY`.
2) Build: `docker compose build`
3) Ingest documents: 
   ```bash
   docker compose run --rm rag python ingest.py --data ./data
   ```
4) Ask a question:
   ```bash
   docker compose run --rm rag python query.py --q "What documents mention KYC address proof?"
   ```

## Files
- `ingest.py` – chunk + embed with SentenceTransformers, persist to Chroma (`./vectordb`)
- `query.py` – retrieve top-k, build prompt, call LLM, show answer + sources
- `data/` – sample docs (you can add PDFs or .txt)
- `requirements.txt`, `Dockerfile`, `docker-compose.yml`, `.env.example`

## Notes
- Uses local `all-MiniLM-L6-v2` for embeddings (downloaded at build).
- LLM calls go to your **self-hosted GPT/Azure OpenAI** (`LLM_API_BASE`).

# Session 8 Demo — Agentic RAG (RAG + Agents + MCP)

This capstone demo combines **RAG retrieval** with **MCP tool use** in a single agent workflow.
It is designed to run **fully offline** on Windows using Docker.

## 🧩 What this shows
- **RAG service** (FastAPI) with simple vector retrieval (no external models).
- **MCP server** (`fastmcp`) exposing `list_files`, `read_file`, `grep_text`.
- **Orchestrator** (Node) routing queries to **LLM-only** / **RAG** / **MCP tools**.
- **Frontend** (React) showing a **timeline** of steps (plan → retrieve/tool → synthesize → answer).

## 🔧 Run locally (Windows + Docker)
```bash
docker compose up --build
```
Then open the UI: http://localhost:5173

## 🧪 Try these prompts
- "Summarize the onboarding policy." → **RAG retrieval**
- "Find references to login in repo." → **MCP tool** (`grep_text`)
- "List files under ./rag-service/data" → **MCP tool** (`list_files`)
- "What is the capital of France?" → **LLM-only** (fallback synth)

## 🗂 Structure
```
mcp-server/                # Python fastmcp tools
rag-service/               # Python FastAPI RAG (in-memory vector store)
  data/                    # sample docs
orchestrator/              # Node orchestrator + agent + mcp-use
frontend/                  # React UI
docker-compose.yml
```

## 🔐 Notes
- No internet or API keys required (LLM synthesis is a simple heuristic).  
- If you set `OPENAI_API_KEY`, you can replace the synthesizer with a real LLM call in `orchestrator/src/llm.ts`.

from fastmcp import MCPServer, tool
import os, glob

server = MCPServer("demo-mcp-server")

@tool()
def list_files(path: str = "."):
    """List files under a given path"""
    return glob.glob(os.path.join(path, "*"))

@tool()
def read_file(path: str):
    """Read contents of a file"""
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        return f.read()

@tool()
def grep_text(path: str, pattern: str):
    """Search for a pattern in a file"""
    results = []
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for i, line in enumerate(f, 1):
            if pattern.lower() in line.lower():
                results.append({"line": i, "text": line.strip()})
    return results

if __name__ == "__main__":
    server.run()

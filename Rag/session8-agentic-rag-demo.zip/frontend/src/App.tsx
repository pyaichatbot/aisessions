import { useState } from 'react';
import './theme.css';

type Event = { type: string; data: any; };

export default function App() {
  const [input, setInput] = useState('');
  const [history, setHistory] = useState<any[]>([]);

  const send = async () => {
    const res = await fetch("http://localhost:3000/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: input })
    });
    const data = await res.json();
    setHistory([...history, { user: input, ...data }]);
    setInput('');
  };

  return (
    <div className="wrap">
      <header><h1>Agentic RAG Demo</h1></header>
      <main>
        <div className="chat">
          {history.map((h, i) => (
            <div className="card" key={i}>
              <div className="user">🧑‍💻 {h.user}</div>
              <div className="mode">Mode: <b>{h.mode}</b></div>
              <div className="events">
                {(h.events as Event[]).map((e, j) => (
                  <div className={`ev ev-${e.type}`} key={j}>
                    <span className="ev-type">{e.type}</span>
                    <pre className="ev-data">{JSON.stringify(e.data, null, 2)}</pre>
                  </div>
                ))}
              </div>
              <div className="answer">💡 {h.answer}</div>
            </div>
          ))}
        </div>
        <div className="composer">
          <input
            placeholder="Ask about policy (RAG) or list/read/grep (MCP), or general question"
            value={input}
            onChange={e => setInput(e.target.value)}
          />
          <button onClick={send}>Send</button>
        </div>
      </main>
    </div>
  );
}

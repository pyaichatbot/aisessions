import { callLLM, synthesizeFromChunks } from "./llm.js";
import { runMcpTool } from "./agent_mcp.js";
import { ragQuery } from "./rag.js";

export async function routeMessage(message: string) {
  const events: any[] = [];
  events.push({ type: "plan", data: { message } });

  // simple rules for demo
  const lower = message.toLowerCase();
  const wantsMcp = /(list|read|grep|file|search)/i.test(lower);
  const wantsRag = /(policy|document|summarize|explain|onboarding|guidelines)/i.test(lower);

  if (wantsMcp) {
    events.push({ type: "decision", data: { path: "mcp" } });
    const tool = /list/.test(lower) ? "list_files" : /read/.test(lower) ? "read_file" : "grep_text";
    const args =
      tool === "list_files"
        ? { path: "./rag-service/data" }
        : tool === "read_file"
        ? { path: "./rag-service/data/OnboardingPolicy.md" }
        : { path: "./rag-service/data/LoginGuide.md", pattern: "login" };
    const result = await runMcpTool(tool, args);
    events.push({ type: "tool_result", data: { tool, args, result } });
    const answer = await callLLM(`User asked: ${message}. Tool ${tool} returned: ${JSON.stringify(result).slice(0, 400)}.`);
    events.push({ type: "final", data: { answer } });
    return { mode: "agent_mcp", events, answer };
  }

  if (wantsRag) {
    events.push({ type: "decision", data: { path: "rag" } });
    const rag = await ragQuery(message);
    events.push({ type: "retrieval_result", data: rag });
    const answer = await synthesizeFromChunks(message, rag.hits);
    events.push({ type: "final", data: { answer } });
    return { mode: "agent_rag", events, answer };
  }

  events.push({ type: "decision", data: { path: "llm" } });
  const answer = await callLLM(message);
  events.push({ type: "final", data: { answer } });
  return { mode: "llm", events, answer };
}

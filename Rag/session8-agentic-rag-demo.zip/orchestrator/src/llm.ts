const USE_REAL_LLM = !!process.env.OPENAI_API_KEY;

// Placeholder LLM call; in a real setup, call OpenAI/Azure here.
export async function callLLM(prompt: string): Promise<string> {
  // Fallback synthesizer: echo plus small heuristic to sound coherent.
  return `Assistant (heuristic): ${prompt}`;
}

export async function synthesizeFromChunks(question: string, hits: any[]): Promise<string> {
  // Simple heuristic: combine top snippets and craft a summary.
  const parts = hits.map(h => `• (${h.score}) ${h.path.split('/').pop()}: ${h.snippet}`).join('\n');
  const summary = `Here is a concise answer based on retrieved docs:\n${parts}\n\nAnswer: For "${question}", the key points are summarized above.`;
  return summary;
}

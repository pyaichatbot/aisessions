import { createClient } from "mcp-use";

let clientPromise: Promise<any> | null = null;

async function getClient() {
  if (!clientPromise) {
    clientPromise = createClient({
      command: "python",
      args: ["mcp-server/server.py"],
    });
  }
  return clientPromise;
}

export async function runMcpTool(tool: string, args: any) {
  const client = await getClient();
  const result = await client.callTool(tool, args);
  return result;
}

from fastapi import FastAPI, Query
from pydantic import BaseModel
from typing import List, Dict, Tuple
import os, math, re, glob

DOC_DIR = os.environ.get("DOC_DIR", "/app/data")

app = FastAPI(title="RAG Service", version="1.0.0")

# In-memory store
DOCUMENTS: List[Dict] = []
VOCAB: Dict[str, int] = {}
DOC_VECTORS: List[Dict[int, float]] = []
IDF: Dict[int, float] = {}

def tokenize(text: str) -> List[str]:
    # lowercase, simple word tokens
    return re.findall(r"[a-zA-Z0-9]+", text.lower())

def build_index():
    global DOCUMENTS, VOCAB, DOC_VECTORS, IDF
    DOCUMENTS.clear()
    VOCAB.clear()
    DOC_VECTORS.clear()
    IDF.clear()

    files = glob.glob(os.path.join(DOC_DIR, "*"))
    for path in files:
        try:
            with open(path, "r", encoding="utf-8", errors="ignore") as f:
                text = f.read()
        except Exception:
            text = ""
        doc_id = len(DOCUMENTS)
        DOCUMENTS.append({"id": doc_id, "path": path, "text": text})
        # chunk by paragraphs (very simple)
        # For simplicity we treat each whole file as a chunk in this demo
    # Build vocab & tf
    df_counts = {}
    doc_term_counts = []
    for doc in DOCUMENTS:
        tokens = tokenize(doc["text"])
        term_counts = {}
        for tok in tokens:
            if tok not in VOCAB:
                VOCAB[tok] = len(VOCAB)
            tid = VOCAB[tok]
            term_counts[tid] = term_counts.get(tid, 0) + 1
        doc_term_counts.append(term_counts)
        for tid in term_counts.keys():
            df_counts[tid] = df_counts.get(tid, 0) + 1
    N = max(len(DOCUMENTS), 1)
    for tid, df in df_counts.items():
        IDF[tid] = math.log((N + 1) / (df + 1)) + 1.0
    # doc vectors (tf-idf normalized)
    for term_counts in doc_term_counts:
        vec = {}
        norm = 0.0
        for tid, tf in term_counts.items():
            val = (tf) * IDF.get(tid, 0.0)
            vec[tid] = val
            norm += val * val
        norm = math.sqrt(max(norm, 1e-9))
        for tid in list(vec.keys()):
            vec[tid] /= norm
        DOC_VECTORS.append(vec)

def vec_for_text(text: str) -> Dict[int, float]:
    tokens = tokenize(text)
    counts = {}
    for tok in tokens:
        tid = VOCAB.get(tok)
        if tid is not None:
            counts[tid] = counts.get(tid, 0) + 1
    vec = {}
    norm = 0.0
    for tid, tf in counts.items():
        val = tf * IDF.get(tid, 0.0)
        vec[tid] = val
        norm += val * val
    norm = math.sqrt(max(norm, 1e-9))
    for tid in list(vec.keys()):
        vec[tid] /= norm
    return vec

def cosine(a: Dict[int, float], b: Dict[int, float]) -> float:
    if not a or not b:
        return 0.0
    if len(a) > len(b):
        a, b = b, a
    s = 0.0
    for tid, aval in a.items():
        bval = b.get(tid)
        if bval is not None:
            s += aval * bval
    return float(max(min(s, 1.0), 0.0))

class QueryIn(BaseModel):
    question: str
    k: int = 3

class Hit(BaseModel):
    score: float
    path: str
    snippet: str

class QueryOut(BaseModel):
    hits: List[Hit]

@app.on_event("startup")
def startup():
    build_index()

@app.get("/health")
def health():
    return {"status": "ok", "docs": len(DOCUMENTS), "vocab": len(VOCAB)}

@app.post("/query", response_model=QueryOut)
def query(payload: QueryIn):
    qvec = vec_for_text(payload.question)
    scored: List[Tuple[float, Dict]] = []
    for doc, dvec in zip(DOCUMENTS, DOC_VECTORS):
        c = cosine(qvec, dvec)
        scored.append((c, doc))
    scored.sort(key=lambda x: x[0], reverse=True)
    hits = []
    for score, doc in scored[: max(1, payload.k)]:
        # simple snippet: first 200 chars
        txt = doc["text"].strip().replace("\n", " ")
        snippet = txt[:200] + ("..." if len(txt) > 200 else "")
        hits.append({"score": round(float(score), 4), "path": doc["path"], "snippet": snippet})
    return {"hits": hits}

# Merchant Onboarding Policy (Excerpt)

This document outlines the onboarding process for merchants, including KYC verification,
document collection, and risk checks. Merchants must provide proof of identity, business registration,
and recent bank statements. The onboarding pipeline includes preprocessing, validation, post-validation,
human-in-the-loop approval, and postprocessing steps. Exceptions require manual review.

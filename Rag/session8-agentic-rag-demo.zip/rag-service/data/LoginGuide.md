# Developer Login Guide

To log in to the developer portal, use your corporate SSO credentials. If local development
is required, create a personal access token and configure your git client. For code search,
use the semantic + lexical hybrid tool. For repository triage, the agent will grep for 'login'
implementations via MCP, then cross-check results.

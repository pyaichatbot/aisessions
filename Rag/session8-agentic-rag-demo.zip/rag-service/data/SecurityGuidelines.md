# Security Guidelines

Follow least-privilege access, rotate credentials regularly, and enable MFA.
Store secrets in a secure vault; never commit keys to source control. Run static analysis
on every merge request. Maintain audit logs for agent tool usage via MCP.


"use client";
import { useEffect, useMemo, useRef, useState } from "react";

const BACKEND = process.env.NEXT_PUBLIC_BACKEND_URL || "http://localhost:8000";

type Conversation = { id:number; title:string };
type Message = { id:number; role:"user"|"assistant"; content:string; created_at:string };
type RetrievalItem = { type:"doc"|"memory"; id:string; score:number; snippet:string; source:string };

export default function HomePage() {
  const [token, setToken] = useState<string | null>(null);
  const [convs, setConvs] = useState<Conversation[]>([]);
  const [selected, setSelected] = useState<number | null>(null);
  const [msgs, setMsgs] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [status, setStatus] = useState<"idle"|"thinking"|"responding">("idle");
  const [retrieval, setRetrieval] = useState<RetrievalItem[]>([]);
  const [streamed, setStreamed] = useState<string>("");
  const [file, setFile] = useState<File | null>(null);

  useEffect(() => {
    const tk = localStorage.getItem("token");
    setToken(tk);
    if (tk) { loadConvs(tk); }
  }, []);

  async function loadConvs(tk: string) {
    const res = await fetch(`${BACKEND}/api/conversations`, { headers: { Authorization: `Bearer ${tk}` } });
    if (res.ok) setConvs(await res.json());
  }
  async function openConv(id: number) {
    setSelected(id);
    if (!token) return;
    const res = await fetch(`${BACKEND}/api/conversations/${id}/messages`, { headers: { Authorization: `Bearer ${token}` } });
    if (res.ok) setMsgs(await res.json());
    setStreamed("");
    setRetrieval([]);
  }
  async function newConv() {
    if (!token) { alert("login"); return; }
    const res = await fetch(`${BACKEND}/api/conversations`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
      body: JSON.stringify({ title: "New Chat" })
    });
    if (res.ok) {
      await loadConvs(token!);
      const cs = await res.json();
      setSelected(cs.id);
    }
  }
  async function send() {
    if (!token || !selected || !input.trim()) return;
    setMsgs(m => [...m, { id: Date.now(), role: "user", content: input, created_at: new Date().toISOString() }]);
    setInput("");
    const es = new EventSource(`${BACKEND}/api/chat/stream`, { withCredentials: false } as any);
    // polyfill auth: we pass via POST body -> can't with EventSource, so we use fetch to create endpoint? Instead use fetch with ReadableStream.
    es.close();
    // Fallback: use fetch streaming
    const res = await fetch(`${BACKEND}/api/chat/stream`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
      body: JSON.stringify({ conversation_id: selected, message: msgs.length ? input : input })
    });
    if (!res.ok || !res.body) { console.error("stream error"); return; }
    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    setStreamed("");
    setStatus("thinking");
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      const chunk = decoder.decode(value, { stream: true });
      const events = chunk.split("\n\n").filter(Boolean);
      for (const ev of events) {
        const [evtLine, dataLine] = ev.split("\n");
        const event = evtLine?.replace("event: ","").trim();
        const dataRaw = dataLine?.replace("data: ","");
        if (!event || !dataRaw) continue;
        if (event === "status") {
          const obj = JSON.parse(dataRaw);
          setStatus(obj.phase);
        } else if (event === "retrieval") {
          const obj = JSON.parse(dataRaw);
          setRetrieval(obj.items || []);
        } else if (event === "delta") {
          setStatus("responding");
          setStreamed(s => s + dataRaw);
        } else if (event === "done") {
          setStatus("idle");
          // refresh messages
          openConv(selected);
        }
      }
    }
  }

  async function upload() {
    if (!token || !file) return;
    const fd = new FormData();
    fd.append("file", file);
    const res = await fetch(`${BACKEND}/api/documents`, { method: "POST", headers: { Authorization: `Bearer ${token}` }, body: fd });
    if (res.ok) alert("Uploaded & indexed!");
    else alert("Upload failed");
  }

  return (
    <div className="grid grid-cols-[280px_1fr] gap-6">
      <div className="space-y-3">
        <button onClick={newConv}>+ New conversation</button>
        <div className="space-y-1">
          {convs.map(c => (
            <div key={c.id} className={`p-2 rounded cursor-pointer ${selected===c.id?"bg-neutral-800":"hover:bg-neutral-900"}`} onClick={()=>openConv(c.id)}>
              {c.title}
            </div>
          ))}
        </div>
        <div className="pt-4 border-t border-neutral-800">
          <h3 className="font-semibold mb-2">Upload documents</h3>
          <input type="file" onChange={e=> setFile(e.target.files?.[0] || null)} />
          <button onClick={upload} className="mt-2">Upload & index</button>
          <p className="text-xs text-neutral-500 mt-2">PDF, TXT, HTML. Parsed → chunked → embedded → vector DB.</p>
        </div>
      </div>
      <div>
        <div className="min-h-[60vh] rounded border border-neutral-800 p-4">
          <div className="mb-2 text-sm text-neutral-400">Status: <StatusBadge status={status} /></div>
          <div className="space-y-4">
            {msgs.map(m => (
              <div key={m.id} className="whitespace-pre-wrap">
                <span className="text-xs mr-2 opacity-60">{m.role === "user" ? "You" : "AI"}</span>
                {m.content}
              </div>
            ))}
            {streamed && (
              <div className="whitespace-pre-wrap">
                <span className="text-xs mr-2 opacity-60">AI</span>
                {streamed}
              </div>
            )}
          </div>
        </div>

        <div className="mt-4 p-3 rounded border border-neutral-800">
          <h3 className="font-semibold mb-2">Retrieved context</h3>
          {retrieval.length === 0 ? <p className="text-sm text-neutral-400">No matches yet.</p> :
            <ul className="list-disc ml-6 space-y-1">
              {retrieval.map((r,i)=> (
                <li key={i}><span className="opacity-60">[{r.source}]</span> {r.snippet}</li>
              ))}
            </ul>
          }
        </div>

        <div className="mt-4 flex gap-2">
          <input className="flex-1" placeholder="Ask anything..." value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>{ if(e.key==="Enter") send(); }} />
          <button onClick={send}>Send</button>
        </div>
      </div>
    </div>
  );
}

function StatusBadge({ status }: { status:"idle"|"thinking"|"responding" }) {
  const label = status === "idle" ? "Idle" : status === "thinking" ? "Thinking…" : "Answering…";
  return <span className={`text-xs px-2 py-1 rounded-md ${status==="idle"?"bg-neutral-800":"bg-blue-900/40"}`}>{label}</span>;
}

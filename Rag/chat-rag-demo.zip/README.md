
# Chat+RAG Demo — Production‑grade, Extensible (Python FastAPI + Next.js)

End‑to‑end chat application with:
- Document uploads (PDF/Docx/TXT/HTML) and ingestion pipeline (chunking + embeddings)
- Multi‑conversation chat, user accounts, chat history
- Short‑term memory (Redis) and long‑term memory (Postgres + Vector DB)
- Pluggable Vector DBs: **Chroma** (default), **pgvector**, **Milvus** (optional profile)
- Streaming responses over **SSE** with UI indicators for **Thinking** → **Answering**
- Retrieval‑Augmented Generation across **all** of a user’s docs and memories
- Clean provider abstraction for LLMs (OpenAI, Azure OpenAI, Ollama, Dummy) and Embeddings
- Storage backends: Local disk (default) or S3/MinIO
- Batteries‑included Docker Compose for one‑command bring‑up

> **Good defaults:** Chroma + SentenceTransformers + local storage + Dummy LLM (streams tokens) run without API keys.  
> **Upgrade instantly:** Set env vars for OpenAI/Azure/Ollama, switch to pgvector/Milvus via `.env`.

## Quick Start

```bash
# 1) Copy env and tweak if needed
cp .env.example .env

# 2) Start everything (default profile: chroma)
docker compose up --build

# Optional: pgvector (instead of chroma)
docker compose --profile pgvector up --build

# Optional: milvus (heavy, needs ~4GB RAM free)
docker compose --profile milvus up --build

# 3) Open the app
# Frontend: http://localhost:3000
# Backend docs: http://localhost:8000/docs
```

Login flow: Register at `/login` (demo auth). Create conversations, upload documents, ask questions.  
If you don’t set any LLM keys, Dummy provider streams a templated answer together with retrieved context.

## Env Vars

See **.env.example**; key ones:
- `POSTGRES_URL=postgresql+psycopg2://app:app@postgres:5432/app`
- `REDIS_URL=redis://redis:6379/0`
- `VECTOR_DB=chroma|pgvector|milvus`
- `EMBEDDING_PROVIDER=sentence_transformers|openai`
- `LLM_PROVIDER=dummy|openai|azure_openai|ollama`
- `CHROMA_HOST=chroma` `CHROMA_PORT=8000`
- `MILVUS_URI=milvus:19530`
- `STORAGE_BACKEND=local|minio`
- `MINIO_*` for S3 compatible storage
- `JWT_SECRET=...`

## Tech Highlights

- **FastAPI** backend, **SQLAlchemy + Alembic** migrations, **Pydantic v2**
- **SSE** streaming endpoint (`/api/chat/stream`) emits: `status/thinking`, `delta`, `retrieval`, `done`
- **Chunking**: smart text splitter (by tokens/paragraphs), PDF parsing via `pypdf`
- **Embeddings**: default SentenceTransformers `all-MiniLM-L6-v2` (small, multilingual-ish); switchable
- **Retrieval**: per-user namespace across conversations & memories
- **Memory**: Redis keeps short-term summaries; Postgres + VectorDB for long-term memory items
- **Frontend**: Next.js 14 + TypeScript + Tailwind + shadcn/ui; clean chat UX with streaming & status pills
- **Security**: JWT auth (HS256), CORS tightened to frontend origin, file type allowlist, size limits

## Extending
- Add a new LLM: implement `services/llm/base.py` interface and register via `LLM_PROVIDER`
- Add tools/agents: create service modules and call from `chatflow.generate_stream(...)`
- Swap vector DB: implement `services/vectorstores/base.py` interface

## Dev Tips
- Migrations: `docker compose exec backend alembic upgrade head`
- Logs: `docker compose logs -f backend`
- Reset Chroma: remove `./volumes/chroma`
- Seed: `scripts/seed.py` has a simple seeder for demo users/docs

License: MIT. Built for enterprise‑grade demos.

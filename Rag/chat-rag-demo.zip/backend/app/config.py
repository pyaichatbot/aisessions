
from pydantic_settings import BaseSettings
from pydantic import Field

class Settings(BaseSettings):
    ENV: str = "dev"
    BACKEND_HOST: str = "0.0.0.0"
    BACKEND_PORT: int = 8000
    FRONTEND_URL: str = "http://localhost:3000"

    JWT_SECRET: str = "change-me"
    JWT_EXPIRE_MINUTES: int = 60 * 24 * 30

    POSTGRES_URL: str = "postgresql+psycopg2://app:app@postgres:5432/app"
    REDIS_URL: str = "redis://redis:6379/0"

    VECTOR_DB: str = "chroma"  # chroma | pgvector | milvus

    EMBEDDING_PROVIDER: str = "sentence_transformers"  # sentence_transformers | openai
    EMBEDDING_MODEL: str = "all-MiniLM-L6-v2"

    LLM_PROVIDER: str = "dummy"  # dummy | openai | azure_openai | ollama
    OPENAI_API_KEY: str | None = None
    AZURE_OPENAI_API_KEY: str | None = None
    AZURE_OPENAI_ENDPOINT: str | None = None
    AZURE_OPENAI_DEPLOYMENT: str | None = None
    OLLAMA_HOST: str = "http://ollama:11434"
    OLLAMA_MODEL: str = "llama3.1"

    STORAGE_BACKEND: str = "local"  # local | minio
    UPLOAD_DIR: str = "/data/uploads"

    MINIO_ENDPOINT: str = "minio:9000"
    MINIO_ACCESS_KEY: str = "minioadmin"
    MINIO_SECRET_KEY: str = "minioadmin"
    MINIO_BUCKET: str = "uploads"
    MINIO_SECURE: bool = False

    CHROMA_HOST: str = "chroma"
    CHROMA_PORT: int = 8000
    CHROMA_COLLECTION_PREFIX: str = "chatapp"

    MILVUS_URI: str = "milvus:19530"
    MILVUS_COLLECTION_PREFIX: str = "chatapp"

    PGVECTOR_DIM: int = 384

    class Config:
        env_file = ".env"

settings = Settings()


from abc import ABC, abstractmethod
from typing import List, Tuple, Dict

class VectorStore(ABC):
    @abstractmethod
    def upsert(self, namespace: str, ids: List[str], vectors: List[List[float]], metadatas: List[Dict]): ...
    @abstractmethod
    def query(self, namespace: str, vector: List[float], top_k: int = 5) -> List[Dict]: ...
    @abstractmethod
    def delete_namespace(self, namespace: str): ...


from .base import VectorStore
from chromadb import HttpClient
from chromadb.utils import embedding_functions
from ...config import settings

class ChromaVectorStore(VectorStore):
    def __init__(self, embedder):
        self.client = HttpClient(host=settings.CHROMA_HOST, port=settings.CHROMA_PORT)
        self.embedder = embedder

    def _collection(self, namespace: str):
        name = f"{settings.CHROMA_COLLECTION_PREFIX}_{namespace}"
        return self.client.get_or_create_collection(name=name)

    def upsert(self, namespace, ids, vectors, metadatas):
        col = self._collection(namespace)
        col.upsert(ids=ids, embeddings=vectors, metadatas=metadatas)

    def query(self, namespace, vector, top_k=5):
        col = self._collection(namespace)
        res = col.query(query_embeddings=[vector], n_results=top_k, include=["metadatas", "distances", "documents"])
        items = []
        if res and res["ids"] and res["ids"][0]:
            for i, _id in enumerate(res["ids"][0]):
                items.append({
                    "id": _id,
                    "score": 1.0 - float(res["distances"][0][i]) if res.get("distances") else 0.0,
                    "metadata": res["metadatas"][0][i],
                    "document": (res["documents"][0][i] if res.get("documents") else None)
                })
        return items

    def delete_namespace(self, namespace):
        col = self._collection(namespace)
        self.client.delete_collection(col.name)


import json
from typing import List, Dict
from redis import Redis
from ..config import settings

SHORT_KEY = "short:{user_id}:{conv_id}"

class MemoryService:
    def __init__(self):
        self.r = Redis.from_url(settings.REDIS_URL, decode_responses=True)

    def get_short_summary(self, user_id: int, conv_id: int) -> str | None:
        return self.r.get(SHORT_KEY.format(user_id=user_id, conv_id=conv_id))

    def set_short_summary(self, user_id: int, conv_id: int, summary: str):
        self.r.set(SHORT_KEY.format(user_id=user_id, conv_id=conv_id), summary, ex=60*60*24)  # 1 day

    # In a real system, you'd also maintain ephemeral scratchpads, per tool state, etc.


from .base import EmbeddingProvider
from sentence_transformers import SentenceTransformer
from ....config import settings

_model = None

class SentenceTransformerProvider(EmbeddingProvider):
    def __init__(self):
        global _model
        if _model is None:
            _model = SentenceTransformer(settings.EMBEDDING_MODEL)
        self._model = _model

    def embed(self, texts):
        return self._model.encode(texts, normalize_embeddings=True).tolist()

    def dim(self) -> int:
        return self._model.get_sentence_embedding_dimension()

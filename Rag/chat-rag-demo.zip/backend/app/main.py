
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .config import settings
from .db import Base, engine
from .routers import auth, conversations, documents, chat, health

# Create tables (use Alembic in prod; okay to bootstrap demo)
Base.metadata.create_all(bind=engine)

app = FastAPI(title="Chat+RAG Backend", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[settings.FRONTEND_URL, "http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(health.router)
app.include_router(auth.router)
app.include_router(conversations.router)
app.include_router(documents.router)
app.include_router(chat.router)


from typing import List, Tuple
from bs4 import BeautifulSoup
from pypdf import PdfReader
import chardet

def detect_encoding(data: bytes) -> str:
    return chardet.detect(data).get("encoding") or "utf-8"

def chunk_text(text: str, max_tokens: int = 500, overlap: int = 100) -> List[str]:
    # naive tokenization by words; replace with tiktoken if needed
    words = text.split()
    chunks = []
    i = 0
    while i < len(words):
        chunk = words[i:i+max_tokens]
        chunks.append(" ".join(chunk))
        i += max_tokens - overlap if max_tokens - overlap > 0 else max_tokens
    return chunks

def extract_text_from_pdf(data: bytes) -> str:
    import io
    reader = PdfReader(io.BytesIO(data))
    parts = []
    for page in reader.pages:
        parts.append(page.extract_text() or "")
    return "\n".join(parts)

def extract_text_from_html(data: bytes) -> str:
    html = data.decode(detect_encoding(data), errors="ignore")
    soup = BeautifulSoup(html, "html.parser")
    return soup.get_text(separator="\n")

def extract_text_from_txt(data: bytes) -> str:
    return data.decode(detect_encoding(data), errors="ignore")

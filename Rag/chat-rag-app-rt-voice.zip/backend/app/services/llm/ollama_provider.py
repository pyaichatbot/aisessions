
import httpx
from typing import AsyncGenerator, List, Dict
from .base import LLMProvider
from ....config import settings

class OllamaProvider(LLMProvider):
    async def stream_generate(self, messages: List[Dict]) -> AsyncGenerator[str, None]:
        # Compose a prompt
        prompt = ""
        for m in messages:
            prompt += f"{m['role']}: {m['content']}\n"
        async with httpx.AsyncClient(timeout=60) as client:
            async with client.stream("POST", f"{settings.OLLAMA_HOST}/api/generate", json={"model": settings.OLLAMA_MODEL, "prompt": prompt, "stream": True}) as r:
                async for line in r.aiter_lines():
                    if not line:
                        continue
                    try:
                        obj = httpx.Response(200, content=line).json()
                    except Exception:
                        continue
                    if obj.get("done"):
                        break
                    token = obj.get("response", "")
                    if token:
                        yield token


from typing import AsyncGenerator, List, Dict
from .base import LLMProvider
from ....config import settings
from openai import AsyncAzureOpenAI

class AzureOpenAIProvider(LLMProvider):
    def __init__(self):
        if not settings.AZURE_OPENAI_API_KEY or not settings.AZURE_OPENAI_ENDPOINT or not settings.AZURE_OPENAI_DEPLOYMENT:
            raise RuntimeError("Azure OpenAI env not set")
        self.client = AsyncAzureOpenAI(
            api_key=settings.AZURE_OPENAI_API_KEY,
            azure_endpoint=settings.AZURE_OPENAI_ENDPOINT,
            api_version="2024-02-15-preview"
        )
        self.deployment = settings.AZURE_OPENAI_DEPLOYMENT

    async def stream_generate(self, messages: List[Dict]) -> AsyncGenerator[str, None]:
        stream = await self.client.chat.completions.create(
            model=self.deployment,
            messages=messages,
            temperature=0.2,
            stream=True,
        )
        async for chunk in stream:
            if chunk.choices and chunk.choices[0].delta.content:
                yield chunk.choices[0].delta.content

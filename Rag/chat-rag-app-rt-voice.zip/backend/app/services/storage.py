
import os, hashlib
from typing import BinaryIO
from ..config import settings
from boto3.session import Session
from botocore.client import Config

def compute_sha256(fileobj: BinaryIO) -> str:
    pos = fileobj.tell()
    fileobj.seek(0)
    h = hashlib.sha256()
    while True:
        chunk = fileobj.read(8192)
        if not chunk:
            break
        h.update(chunk)
    fileobj.seek(pos)
    return h.hexdigest()

def save_file(fileobj: BinaryIO, filename: str) -> str:
    backend = settings.STORAGE_BACKEND
    if backend == "local":
        os.makedirs(settings.UPLOAD_DIR, exist_ok=True)
        dst = os.path.join(settings.UPLOAD_DIR, filename)
        with open(dst, "wb") as f:
            fileobj.seek(0)
            f.write(fileobj.read())
        return dst
    else:
        # MinIO/S3
        session = Session(aws_access_key_id=settings.MINIO_ACCESS_KEY, aws_secret_access_key=settings.MINIO_SECRET_KEY)
        s3 = session.resource('s3', endpoint_url=("https://" if settings.MINIO_SECURE else "http://") + settings.MINIO_ENDPOINT, config=Config(signature_version='s3v4'))
        bucket = s3.Bucket(settings.MINIO_BUCKET)
        fileobj.seek(0)
        bucket.put_object(Key=filename, Body=fileobj.read(), ContentType="application/octet-stream")
        return f"s3://{settings.MINIO_BUCKET}/{filename}"


from typing import List, Dict
from .embedding.base import EmbeddingProvider
from .vectorstores.base import VectorStore
from ..schemas import RetrievalItem

def build_namespace(user_id: int) -> str:
    return f"user{user_id}"

class Retriever:
    def __init__(self, embedder: EmbeddingProvider, vstore: VectorStore):
        self.embedder = embedder
        self.vstore = vstore

    def search(self, user_id: int, query: str, top_k: int = 5) -> List[RetrievalItem]:
        qv = self.embedder.embed([query])[0]
        ns = build_namespace(user_id)
        hits = self.vstore.query(ns, qv, top_k=top_k)
        items: List[RetrievalItem] = []
        for h in hits:
            meta = h.get("metadata", {}) or {}
            snippet = meta.get("text", "")[:300]
            source = meta.get("source", meta.get("filename", "doc"))
            items.append(RetrievalItem(
                type=meta.get("type","doc"),
                id=str(h.get("id")),
                score=float(h.get("score",0.0)),
                snippet=snippet,
                source=source
            ))
        return items

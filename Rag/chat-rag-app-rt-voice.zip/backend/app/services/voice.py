
import httpx
from ..config import settings

class STTClient:
    async def transcribe(self, filename: str, data: bytes) -> str:
        if settings.STT_PROVIDER == "disabled" or not settings.STT_URL:
            return "(voice transcription disabled – set STT_PROVIDER=rest and STT_URL)"
        headers = {}
        if settings.STT_BEARER:
            headers["Authorization"] = f"Bearer {settings.STT_BEARER}"
        files = {"file": (filename, data, "application/octet-stream")}
        async with httpx.AsyncClient(timeout=120) as client:
            r = await client.post(settings.STT_URL, files=files, headers=headers)
            r.raise_for_status()
            obj = r.json()
            return obj.get("text") or obj.get("transcript") or ""

class TTSClient:
    async def synth(self, text: str) -> tuple[bytes, str]:
        if settings.TTS_PROVIDER == "disabled" or not settings.TTS_URL:
            # Return a tiny silent WAV placeholder
            import wave, io, struct
            buf = io.BytesIO()
            with wave.open(buf, 'wb') as wf:
                wf.setnchannels(1); wf.setsampwidth(2); wf.setframerate(22050)
                for _ in range(2205):  # 0.1s silence
                    wf.writeframes(struct.pack('<h', 0))
            return buf.getvalue(), "audio/wav"
        headers = {"Content-Type":"application/json"}
        if settings.TTS_BEARER:
            headers["Authorization"] = f"Bearer {settings.TTS_BEARER}"
        async with httpx.AsyncClient(timeout=120) as client:
            r = await client.post(settings.TTS_URL, json={"text": text}, headers=headers)
            r.raise_for_status()
            ct = r.headers.get("content-type","application/octet-stream")
            return r.content, ct

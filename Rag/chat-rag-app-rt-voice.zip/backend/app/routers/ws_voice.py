
import asyncio, json, base64, io
from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Depends, HTTPException
from sqlalchemy.orm import Session
from ..db import get_db
from ..auth import get_current_user
from ..utils.security import decode_token
from ..models import Conversation, Message
from ..services.embedding.sentence_transformers_provider import SentenceTransformerProvider
from ..services.embedding.openai_provider import OpenAIEmbeddingProvider
from ..services.vectorstores.chroma_store import ChromaVectorStore
from ..services.vectorstores.pgvector_store import PgVectorStore
from ..services.vectorstores.milvus_store import MilvusVectorStore
from ..services.retrieval import Retriever
from ..services.memory import MemoryService
from ..services.voice import STTClient, TTSClient
from ..services.llm.dummy_provider import DummyProvider
from ..services.llm.openai_provider import OpenAIProvider
from ..services.llm.azure_openai_provider import AzureOpenAIProvider
from ..services.llm.ollama_provider import OllamaProvider
from ..config import settings

router = APIRouter()

def _embedder():
    if settings.EMBEDDING_PROVIDER == "openai":
        return OpenAIEmbeddingProvider()
    return SentenceTransformerProvider()

def _vstore(embedder):
    if settings.VECTOR_DB == "pgvector":
        return PgVectorStore(embedder)
    if settings.VECTOR_DB == "milvus":
        return MilvusVectorStore(embedder)
    return ChromaVectorStore(embedder)

def _llm():
    if settings.LLM_PROVIDER == "openai":
        return OpenAIProvider()
    if settings.LLM_PROVIDER == "azure_openai":
        return AzureOpenAIProvider()
    if settings.LLM_PROVIDER == "ollama":
        return OllamaProvider()
    return DummyProvider()

async def _send_json(ws: WebSocket, obj: dict):
    await ws.send_text(json.dumps(obj))

@router.websocket("/ws/voicechat")
async def voice_chat(ws: WebSocket, db: Session = Depends(get_db)):
    # Auth: token in query param ?token=
    token = ws.query_params.get("token")
    if not token:
        await ws.close(code=4401)
        return
    try:
        payload = decode_token(token)
        email = payload.get("sub")
    except Exception:
        await ws.close(code=4401)
        return
    # Load user
    from ..models import User
    user = db.query(User).filter(User.email==email).first()
    if not user:
        await ws.close(code=4401)
        return

    await ws.accept()

    embedder = _embedder()
    vstore = _vstore(embedder)
    retriever = Retriever(embedder, vstore)
    llm = _llm()
    memory = MemoryService()
    stt = STTClient()
    tts = TTSClient()

    conversation_id: int | None = None
    audio_buf = bytearray()

    async def handle_utterance(text: str):
        nonlocal conversation_id
        if conversation_id is None:
            await _send_json(ws, {"type":"error","message":"No conversation yet. Send a 'start' with conversation_id."})
            return
        # persist user message
        m_user = Message(conversation_id=conversation_id, user_id=user.id, role="user", content=text)
        db.add(m_user); db.commit(); db.refresh(m_user)

        # thinking
        await _send_json(ws, {"type":"status","phase":"thinking"})

        # retrieval
        items = retriever.search(user.id, text, top_k=5)
        await _send_json(ws, {"type":"retrieval","items":[i.model_dump() for i in items]})

        # messages
        system = {"role":"system","content":"You are a helpful enterprise assistant. Use provided context snippets if relevant."}
        context = "\n\n".join([f"[{i.source}] {i.snippet}" for i in items])
        short = memory.get_short_summary(user.id, conversation_id) or ""
        user_msg = {"role":"user","content": f"Short-memory: {short}\nContext:\n{context}\n\nUser question: {text}"}
        messages = [system, user_msg]

        # responding
        await _send_json(ws, {"type":"status","phase":"responding"})
        content_acc = ""
        async for tok in llm.stream_generate(messages):
            content_acc += tok
            await _send_json(ws, {"type":"delta","text":tok})

        # save assistant
        m_assist = Message(conversation_id=conversation_id, user_id=None, role="assistant", content=content_acc)
        db.add(m_assist); db.commit(); db.refresh(m_assist)

        # update short memory
        memory.set_short_summary(user.id, conversation_id, content_acc[-512:])

        await _send_json(ws, {"type":"done","message_id": m_assist.id})

        # TTS
        audio_bytes, content_type = await tts.synth(content_acc)
        b64 = base64.b64encode(audio_bytes).decode("ascii")
        await _send_json(ws, {"type":"tts_audio_b64","content_type": content_type, "data": b64})

    try:
        await _send_json(ws, {"type":"status","phase":"ready"})
        while True:
            msg = await ws.receive()
            if "text" in msg and msg["text"] is not None:
                try:
                    obj = json.loads(msg["text"])
                except Exception:
                    await _send_json(ws, {"type":"error","message":"Invalid JSON"})
                    continue
                t = obj.get("type")
                if t == "start":
                    conversation_id = int(obj.get("conversation_id"))
                    # Validate conversation belongs to user
                    conv = db.query(Conversation).filter(Conversation.id==conversation_id, Conversation.user_id==user.id).first()
                    if not conv:
                        await _send_json(ws, {"type":"error","message":"Conversation not found"})
                        continue
                    await _send_json(ws, {"type":"status","phase":"listening"})
                elif t == "audio_stop":
                    # Transcribe buffered audio
                    if audio_buf:
                        await _send_json(ws, {"type":"status","phase":"transcribing"})
                        text = await stt.transcribe("audio.webm", bytes(audio_buf))
                        await _send_json(ws, {"type":"transcript","final": True, "text": text})
                        audio_buf = bytearray()
                        await handle_utterance(text)
                    else:
                        await _send_json(ws, {"type":"transcript","final": True, "text": ""})
                elif t == "text":
                    # Text message via WS (no audio)
                    txt = obj.get("text") or ""
                    await handle_utterance(txt)
                else:
                    await _send_json(ws, {"type":"error","message":f"Unknown type {t}"})
            elif "bytes" in msg and msg["bytes"] is not None:
                # audio chunk from client
                chunk: bytes = msg["bytes"]
                audio_buf.extend(chunk)
            else:
                # ignore
                pass
    except WebSocketDisconnect:
        return


from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from ..db import get_db
from ..models import Conversation, Message
from ..schemas import ConversationCreate, ConversationOut
from ..auth import get_current_user

router = APIRouter(prefix="/api/conversations", tags=["conversations"])

@router.post("", response_model=ConversationOut)
def create_conv(payload: ConversationCreate, db: Session = Depends(get_db), user=Depends(get_current_user)):
    c = Conversation(user_id=user.id, title=payload.title or "New Chat")
    db.add(c); db.commit(); db.refresh(c)
    # add a system message for context if needed
    return c

@router.get("", response_model=list[ConversationOut])
def list_convs(db: Session = Depends(get_db), user=Depends(get_current_user)):
    cs = db.query(Conversation).filter(Conversation.user_id==user.id).order_by(Conversation.created_at.desc()).all()
    return cs

@router.get("/{conv_id}/messages")
def list_msgs(conv_id: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    msgs = db.query(Message).filter(Message.conversation_id==conv_id).order_by(Message.created_at.asc()).all()
    return [{"id": m.id, "role": m.role, "content": m.content, "created_at": m.created_at.isoformat()} for m in msgs]

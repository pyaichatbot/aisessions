
"use client";
import { useEffect, useRef, useState } from "react";

const BACKEND = process.env.NEXT_PUBLIC_BACKEND_URL || "http://localhost:8000";

type Conversation = { id:number; title:string };
type Message = { id:number; role:"user"|"assistant"; content:string; created_at:string };
type RetrievalItem = { type:"doc"|"memory"; id:string; score:number; snippet:string; source:string };

export default function HomePage() {
  const [token, setToken] = useState<string | null>(null);
  const [convs, setConvs] = useState<Conversation[]>([]);
  const [selected, setSelected] = useState<number | null>(null);
  const [msgs, setMsgs] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [status, setStatus] = useState<"idle"|"thinking"|"responding">("idle");
  const [retrieval, setRetrieval] = useState<RetrievalItem[]>([]);
  const [streamed, setStreamed] = useState<string>("");

  // Voice
  const [micOn, setMicOn] = useState(false);
  const [speakOut, setSpeakOut] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  useEffect(() => {
    const tk = localStorage.getItem("token");
    setToken(tk);
    if (tk) { loadConvs(tk); }
  }, []);

  async function loadConvs(tk: string) {
    const res = await fetch(`${BACKEND}/api/conversations`, { headers: { Authorization: `Bearer ${tk}` } });
    if (res.ok) setConvs(await res.json());
  }
  async function openConv(id: number) {
    setSelected(id);
    if (!token) return;
    const res = await fetch(`${BACKEND}/api/conversations/${id}/messages`, { headers: { Authorization: `Bearer ${token}` } });
    if (res.ok) setMsgs(await res.json());
    setStreamed(""); setRetrieval([]);
  }
  async function newConv() {
    if (!token) { alert("login"); return; }
    const res = await fetch(`${BACKEND}/api/conversations`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
      body: JSON.stringify({ title: "New Chat" })
    });
    if (res.ok) {
      const c = await res.json();
      await loadConvs(token!);
      setSelected(c.id);
    }
  }
  async function send() {
    if (!token || !selected) return;
    const msgToSend = input.trim();
    if (!msgToSend) return;
    setMsgs(m => [...m, { id: Date.now(), role: "user", content: msgToSend, created_at: new Date().toISOString() }]);
    setInput("");
    const res = await fetch(`${BACKEND}/api/chat/stream`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
      body: JSON.stringify({ conversation_id: selected, message: msgToSend })
    });
    if (!res.ok || !res.body) { console.error("stream error"); return; }
    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    setStreamed("");
    setStatus("thinking");
    let finalAnswer = "";
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      const chunk = decoder.decode(value, { stream: true });
      const events = chunk.split("\n\n").filter(Boolean);
      for (const ev of events) {
        const [evtLine, dataLine] = ev.split("\n");
        const event = evtLine?.replace("event: ","").trim();
        const dataRaw = dataLine?.replace("data: ","");
        if (!event || !dataRaw) continue;
        if (event === "status") {
          const obj = JSON.parse(dataRaw);
          setStatus(obj.phase);
        } else if (event === "retrieval") {
          const obj = JSON.parse(dataRaw);
          setRetrieval(obj.items || []);
        } else if (event === "delta") {
          setStatus("responding");
          setStreamed(s => s + dataRaw);
          finalAnswer += dataRaw;
        } else if (event === "done") {
          setStatus("idle");
          await openConv(selected);
          if (speakOut) {
            try {
              const tts = await fetch(`${BACKEND}/api/voice/tts`, {
                method: "POST",
                headers: { Authorization: `Bearer ${token}` },
                body: new URLSearchParams({ text: finalAnswer })
              });
              if (tts.ok) {
                const blob = await tts.blob();
                const url = URL.createObjectURL(blob);
                const audio = new Audio(url);
                audio.play();
              }
            } catch (e) { console.error(e); }
          }
        }
      }
    }
  }

  // Feedback
  async function sendFeedback(messageId: number, rating: "up"|"down", comment?: string) {
    if (!token || !selected) return;
    await fetch(`${BACKEND}/api/feedback`, {
      method: "POST",
      headers: { "Content-Type":"application/json", Authorization: `Bearer ${token}` },
      body: JSON.stringify({ conversation_id: selected, message_id: messageId, rating, comment })
    });
  }

  // Voice: record mic and transcribe
  async function toggleMic() {
    if (micOn) {
      mediaRecorderRef.current?.stop();
      setMicOn(false);
      return;
    }
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const mr = new MediaRecorder(stream);
    mediaRecorderRef.current = mr;
    audioChunksRef.current = [];
    mr.ondataavailable = (e) => { if (e.data.size > 0) audioChunksRef.current.push(e.data); };
    mr.onstop = async () => {
      const blob = new Blob(audioChunksRef.current, { type: "audio/webm" });
      if (!token) return;
      const fd = new FormData();
      fd.append("file", blob, "audio.webm");
      const res = await fetch(`${BACKEND}/api/voice/transcribe`, { method: "POST", headers: { Authorization: `Bearer ${token}` }, body: fd });
      const data = await res.json();
      if (data?.text) {
        setInput(data.text);
      }
    };
    mr.start();
    setMicOn(true);
  }

  return (
    <div className="grid grid-cols-[280px_1fr] gap-6">
      <div className="space-y-3">
        <button onClick={newConv}>+ New conversation</button>
        <div className="space-y-1">
          {convs.map(c => (
            <div key={c.id} className={`p-2 rounded cursor-pointer ${selected===c.id?"bg-neutral-800":"hover:bg-neutral-900"}`} onClick={()=>openConv(c.id)}>
              {c.title}
            </div>
          ))}
        </div>
        
        <div className="pt-4 border-t border-neutral-800 space-y-2">
          <h3 className="font-semibold">Realtime Voice (WebSocket)</h3>
          <RealtimeWS />
        </div>

          <h3 className="font-semibold">Voice</h3>
          <div className="flex items-center gap-2">
            <button onClick={toggleMic}>{micOn ? "⏹ Stop" : "🎙️ Record"}</button>
            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" checked={speakOut} onChange={e=>setSpeakOut(e.target.checked)} /> Read answers aloud
            </label>
          </div>
          <p className="text-xs text-neutral-500">Configure STT/TTS endpoints in <code>.env</code>.</p>
        </div>
      </div>
      <div>
        <div className="min-h-[60vh] rounded border border-neutral-800 p-4">
          <div className="mb-2 text-sm text-neutral-400">Status: <StatusBadge status={status} /></div>
          <div className="space-y-4">
            {msgs.map(m => (
              <div key={m.id} className="whitespace-pre-wrap group border-b border-neutral-900 pb-3">
                <div className="text-xs opacity-60 mb-1">{m.role === "user" ? "You" : "AI"}</div>
                <div>{m.content}</div>
                {m.role === "assistant" && (
                  <div className="mt-2 opacity-80 text-sm flex items-center gap-2">
                    <button className="hover:opacity-100" title="Good answer" onClick={()=>sendFeedback(m.id, "up")}>👍</button>
                    <button className="hover:opacity-100" title="Needs improvement" onClick={()=>{
                      const comment = prompt("Optional comment for '👎' feedback?") || undefined;
                      sendFeedback(m.id, "down", comment);
                    }}>👎</button>
                  </div>
                )}
              </div>
            ))}
            {streamed && (
              <div className="whitespace-pre-wrap">
                <span className="text-xs mr-2 opacity-60">AI</span>
                {streamed}
              </div>
            )}
          </div>
        </div>

        <div className="mt-4 p-3 rounded border border-neutral-800">
          <h3 className="font-semibold mb-2">Retrieved context</h3>
          {retrieval.length === 0 ? <p className="text-sm text-neutral-400">No matches yet.</p> :
            <ul className="list-disc ml-6 space-y-1">
              {retrieval.map((r,i)=> (
                <li key={i}><span className="opacity-60">[{r.source}]</span> {r.snippet}</li>
              ))}
            </ul>
          }
        </div>

        <div className="mt-4 flex gap-2">
          <input className="flex-1" placeholder="Ask anything..." value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>{ if(e.key==="Enter") send(); }} />
          <button onClick={send}>Send</button>
        </div>
      </div>
    </div>
  );
}

function StatusBadge({ status }: { status:"idle"|"thinking"|"responding" }) {
  const label = status === "idle" ? "Idle" : status === "thinking" ? "Thinking…" : "Answering…";
  return <span className={`text-xs px-2 py-1 rounded-md ${status==="idle"?"bg-neutral-800":"bg-blue-900/40"}`}>{label}</span>;
}


function RealtimeWS() {
  const BACKEND = process.env.NEXT_PUBLIC_BACKEND_URL || "http://localhost:8000";
  const [token, setToken] = useState<string | null>(null);
  const [status, setStatus] = useState<string>("disconnected");
  const [convId, setConvId] = useState<string>("");
  const wsRef = useRef<WebSocket | null>(null);
  const recRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<BlobPart[]>([]);
  const [partial, setPartial] = useState<string>("");
  const [answer, setAnswer] = useState<string>("");
  const ttsChunksRef = useRef<string[]>([]);

  useEffect(() => {
    setToken(localStorage.getItem("token"));
  }, []);

  async function connect() {
    if (!token) { alert("Login first"); return; }
    if (!convId) { alert("Enter conversation id"); return; }
    const url = BACKEND.replace("http","ws") + `/ws/voicechat?token=${encodeURIComponent(token)}`;
    const ws = new WebSocket(url);
    ws.onopen = () => { setStatus("connected"); ws.send(JSON.stringify({ type:"start", conversation_id: Number(convId) })); };
    ws.onclose = () => { setStatus("disconnected"); wsRef.current = null; };
    ws.onerror = () => { setStatus("error"); };
    ws.onmessage = (ev) => {
      if (typeof ev.data === "string") {
        const obj = JSON.parse(ev.data);
        if (obj.type === "status") setStatus(obj.phase);
        else if (obj.type === "transcript") setPartial(obj.text || "");
        else if (obj.type === "delta") setAnswer(a => a + obj.text);
        else if (obj.type === "done") { /* reset handled by parent UI */ }
        else if (obj.type === "tts_audio_b64") {
          ttsChunksRef.current.push(obj.data);
          const b64 = ttsChunksRef.current.join("");
          const bytes = Uint8Array.from(atob(b64), c => c.charCodeAt(0));
          const blob = new Blob([bytes], { type: obj.content_type || "audio/wav" });
          const url = URL.createObjectURL(blob);
          const audio = new Audio(url);
          audio.play();
          ttsChunksRef.current = [];
        }
      }
    };
    wsRef.current = ws;
  }

  function disconnect() {
    wsRef.current?.close();
    wsRef.current = null;
  }

  async function startRecord() {
    if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) { alert("Connect first"); return; }
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const rec = new MediaRecorder(stream, { mimeType: "audio/webm" });
    recRef.current = rec; chunksRef.current = [];
    rec.ondataavailable = (e) => {
      if (e.data.size > 0) {
        e.data.arrayBuffer().then(buf => {
          wsRef.current?.send(buf);
        });
      }
    };
    rec.onstop = () => {
      wsRef.current?.send(JSON.stringify({ type:"audio_stop" }));
    };
    rec.start(250); // chunk every 250ms
  }

  function stopRecord() {
    recRef.current?.stop();
  }

  return (
    <div className="space-y-2">
      <div className="text-xs text-neutral-400">Status: {status}</div>
      <input placeholder="Conversation ID" value={convId} onChange={e=>setConvId(e.target.value)} />
      <div className="flex gap-2">
        <button onClick={connect}>Connect</button>
        <button onClick={disconnect}>Disconnect</button>
      </div>
      <div className="flex gap-2">
        <button onClick={startRecord}>🎙️ Start</button>
        <button onClick={stopRecord}>⏹ Stop</button>
      </div>
      {partial && <div className="text-sm"><span className="opacity-60">Transcript:</span> {partial}</div>}
      {answer && <div className="text-sm"><span className="opacity-60">Answer:</span> {answer}</div>}
    </div>
  );
}

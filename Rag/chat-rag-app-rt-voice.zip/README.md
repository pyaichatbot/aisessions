
# Chat+RAG Demo — Production‑grade, Extensible (Python FastAPI + Next.js)

End‑to‑end chat application with:
- Document uploads (PDF/Docx/TXT/HTML) and ingestion pipeline (chunking + embeddings)
- Multi‑conversation chat, user accounts, chat history
- Short‑term memory (Redis) and long‑term memory (Postgres + Vector DB)
- Pluggable Vector DBs: **Chroma** (default), **pgvector**, **Milvus** (optional profile)
- Streaming responses over **SSE** with UI indicators for **Thinking** → **Answering**
- Retrieval‑Augmented Generation across **all** of a user’s docs and memories
- Clean provider abstraction for LLMs (OpenAI, Azure OpenAI, Ollama, Dummy) and Embeddings
- Storage backends: Local disk (default) or S3/MinIO
- Batteries‑included Docker Compose for one‑command bring‑up

> **Good defaults:** Chroma + SentenceTransformers + local storage + Dummy LLM (streams tokens) run without API keys.  
> **Upgrade instantly:** Set env vars for OpenAI/Azure/Ollama, switch to pgvector/Milvus via `.env`.

## Quick Start

```bash
# 1) Copy env and tweak if needed
cp .env.example .env

# 2) Start everything (default profile: chroma)
docker compose up --build

# Optional: pgvector (instead of chroma)
docker compose --profile pgvector up --build

# Optional: milvus (heavy, needs ~4GB RAM free)
docker compose --profile milvus up --build

# 3) Open the app
# Frontend: http://localhost:3000
# Backend docs: http://localhost:8000/docs
```

Login flow: Register at `/login` (demo auth). Create conversations, upload documents, ask questions.  
If you don’t set any LLM keys, Dummy provider streams a templated answer together with retrieved context.

## Env Vars

See **.env.example**; key ones:
- `POSTGRES_URL=postgresql+psycopg2://app:app@postgres:5432/app`
- `REDIS_URL=redis://redis:6379/0`
- `VECTOR_DB=chroma|pgvector|milvus`
- `EMBEDDING_PROVIDER=sentence_transformers|openai`
- `LLM_PROVIDER=dummy|openai|azure_openai|ollama`
- `CHROMA_HOST=chroma` `CHROMA_PORT=8000`
- `MILVUS_URI=milvus:19530`
- `STORAGE_BACKEND=local|minio`
- `MINIO_*` for S3 compatible storage
- `JWT_SECRET=...`

## Tech Highlights

- **FastAPI** backend, **SQLAlchemy + Alembic** migrations, **Pydantic v2**
- **SSE** streaming endpoint (`/api/chat/stream`) emits: `status/thinking`, `delta`, `retrieval`, `done`
- **Chunking**: smart text splitter (by tokens/paragraphs), PDF parsing via `pypdf`
- **Embeddings**: default SentenceTransformers `all-MiniLM-L6-v2` (small, multilingual-ish); switchable
- **Retrieval**: per-user namespace across conversations & memories
- **Memory**: Redis keeps short-term summaries; Postgres + VectorDB for long-term memory items
- **Frontend**: Next.js 14 + TypeScript + Tailwind + shadcn/ui; clean chat UX with streaming & status pills
- **Security**: JWT auth (HS256), CORS tightened to frontend origin, file type allowlist, size limits

## Extending
- Add a new LLM: implement `services/llm/base.py` interface and register via `LLM_PROVIDER`
- Add tools/agents: create service modules and call from `chatflow.generate_stream(...)`
- Swap vector DB: implement `services/vectorstores/base.py` interface

## Dev Tips
- Migrations: `docker compose exec backend alembic upgrade head`
- Logs: `docker compose logs -f backend`
- Reset Chroma: remove `./volumes/chroma`
- Seed: `scripts/seed.py` has a simple seeder for demo users/docs

License: MIT. Built for enterprise‑grade demos.


## New: Feedback + Voice

### Feedback
- Click **👍 / 👎** under assistant messages.
- Stored in Postgres (`feedback` table) via `/api/feedback`.

### Voice
- **Record** (Web Audio API) → `/api/voice/transcribe` → fills the chat input.
- **Read answers aloud** toggle: after streaming finishes, frontend calls `/api/voice/tts` to get audio and auto‑plays.
- Configure in `.env`:
  ```env
  STT_PROVIDER=rest
  STT_URL=http://stt:8000/transcribe
  STT_BEARER=
  TTS_PROVIDER=rest
  TTS_URL=http://tts:8000/speak
  TTS_BEARER=
  ```
  REST expectations:
  - **STT**: `multipart/form-data` with `file`; returns JSON like `{ "text": "..." }`.
  - **TTS**: JSON `{"text": "..."}`; returns raw audio bytes with appropriate `Content-Type`.

> Defaults are **disabled**; when disabled, STT returns a placeholder transcript and TTS returns a short silent WAV.


## Realtime Voice (WebSocket Duplex)

- Endpoint: `GET ws://<backend>/ws/voicechat?token=JWT`
- Flow:
  1. Client connects with `?token=<JWT>` and sends `{ "type":"start", "conversation_id": <id> }`
  2. Client streams audio chunks as **binary** WebSocket frames (e.g., `MediaRecorder` chunks).
  3. Client sends `{ "type":"audio_stop" }` to mark end-of-utterance.
  4. Server STT → emits `{ "type":"transcript", "final": true, "text": "..." }`
  5. Server retrieves + LLM streams `{ "type":"delta", "text": "..." }` and finally `{ "type":"done", "message_id": ... }`
  6. Server TTS → sends `{ "type":"tts_audio_b64", "content_type": "audio/wav", "data":"<base64>" }`

> This keeps audio **up** and tokens/audio **down** on the same socket.  
> If your STT/TTS support true streaming, swap `services/voice.py` to call those APIs incrementally.

Security: JWT in query param. For stricter setups, proxy WS and inject headers.

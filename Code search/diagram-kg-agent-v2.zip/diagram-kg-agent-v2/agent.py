#!/usr/bin/env python3
"""
diagram-kg-agent-v2
A Python agent that extracts entities and relationships from common architecture diagram sources
(Mermaid, PlantUML, draw.io, GraphML, and simple JSON) and pushes them into Neo4j.
"""

from __future__ import annotations
import re
import json
import os
import sys
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional, Tuple, Iterable, Set

from pydantic import BaseModel, Field
from lxml import etree
import networkx as nx
import typer
from rich.console import Console
from rich.table import Table
from rich import box
from rich.panel import Panel
from rich.progress import track

# Neo4j (bolt) driver
try:
    from neo4j import GraphDatabase
except Exception:  # pragma: no cover
    GraphDatabase = None  # to allow help/usage without driver installed

app = typer.Typer(add_completion=False, help="Diagram → Knowledge Graph Agent (v2)")
console = Console()

# -----------------------------
# Data Models
# -----------------------------

class KGNode(BaseModel):
    id: Optional[str] = Field(None, description="Stable node id if present in the source (e.g., draw.io cell id).")
    name: str
    type: str = Field("Component", description="Node type, e.g., Service, DB, Queue, Cache, API, Component")
    properties: Dict[str, str] = Field(default_factory=dict)

class KGRel(BaseModel):
    source: str  # node name or id (resolved later)
    target: str
    type: str = Field("CONNECTS_TO", description="Relationship type")
    properties: Dict[str, str] = Field(default_factory=dict)

class KG(BaseModel):
    nodes: List[KGNode] = Field(default_factory=list)
    relationships: List[KGRel] = Field(default_factory=list)

# -----------------------------
# Helpers
# -----------------------------

_TYPE_HEURISTICS = [
    (re.compile(r"db|database|postgres|mysql|mssql|oracle|sqlite", re.I), "Database"),
    (re.compile(r"cache|redis|memcached", re.I), "Cache"),
    (re.compile(r"queue|kafka|sqs|mq|pubsub|rabbit", re.I), "Queue"),
    (re.compile(r"api|service|svc|backend|server", re.I), "Service"),
    (re.compile(r"ui|frontend|web|spa|browser|app", re.I), "UI"),
    (re.compile(r"bucket|s3|blob|storage|fs", re.I), "Storage"),
    (re.compile(r"load balancer|lb|ingress|gateway", re.I), "Gateway"),
]

def infer_type(name: str) -> str:
    for rx, t in _TYPE_HEURISTICS:
        if rx.search(name):
            return t
    return "Component"

def normalize_label(label: str) -> str:
    s = re.sub(r"<[^>]+>", " ", label)  # strip HTML-ish
    s = re.sub(r"&[a-z]+;", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s

# -----------------------------
# Mermaid extractor
# -----------------------------

class MermaidExtractor:
    EDGE_RX = re.compile(r'^\s*([A-Za-z0-9_]+)\s*([\-\.]+)>\s*([A-Za-z0-9_]+)\s*(?::\s*(.+))?$')
    NODE_DEF_RX = re.compile(r'^\s*([A-Za-z0-9_]+)\s*(?:\[([^\]]+)\]|\(\(([^\)]+)\)\)|\(\[([^\]]+)\]\)|\{\{([^\}]+)\}\}|\"([^\"]+)\")')
    LABEL_IN_BRAKETS_RX = re.compile(r'^[A-Za-z0-9_]+\s*(?:\[([^\]]+)\]|\"([^\"]+)\"|\(\(([^\)]+)\)\)|\{\{([^\}]+)\}\))')

    @classmethod
    def can_handle(cls, text: str) -> bool:
        header = (text.splitlines() or [""])[0].lower()
        return header.startswith("graph ") or "graph " in text.lower()

    @classmethod
    def parse(cls, text: str) -> KG:
        nodes: Dict[str, KGNode] = {}
        rels: List[KGRel] = []

        lines = [l.strip() for l in text.splitlines() if l.strip() and not l.strip().startswith("%")]
        for line in lines:
            # Node definitions like: A[API]  or  B((DB))
            mdef = cls.NODE_DEF_RX.match(line)
            if mdef:
                nid = mdef.group(1)
                raw = next((g for g in mdef.groups()[1:] if g), nid)
                name = normalize_label(raw)
                nodes.setdefault(nid, KGNode(id=nid, name=name, type=infer_type(name)))
                continue

            # Edges like: A --> B : REST
            m = cls.EDGE_RX.match(line.replace("|",":"))
            if m:
                s, _, t, label = m.groups()
                if s not in nodes:
                    nodes[s] = KGNode(id=s, name=s, type=infer_type(s))
                if t not in nodes:
                    nodes[t] = KGNode(id=t, name=t, type=infer_type(t))
                rel_type = normalize_label(label or "CONNECTS_TO").upper().replace(" ", "_")
                rels.append(KGRel(source=s, target=t, type=rel_type))
        # Expand node names if bracket labels appear after references
        for line in lines:
            m = cls.LABEL_IN_BRAKETS_RX.match(line)
            if m:
                nid = line.split()[0]
                label = next((g for g in m.groups() if g), nid)
                if nid in nodes:
                    nodes[nid].name = normalize_label(label)
                    nodes[nid].type = infer_type(nodes[nid].name)

        return KG(nodes=list(nodes.values()), relationships=rels)

# -----------------------------
# PlantUML extractor
# -----------------------------

class PlantUMLExtractor:
    EDGE_RX = re.compile(r'^\s*([-\w]+)\s*[-\.]+>\s*([-\w]+)\s*(?::\s*(.+))?$')

    @classmethod
    def can_handle(cls, text: str) -> bool:
        low = text.lower()
        return "@startuml" in low or "skinparam" in low or "-->" in low

    @classmethod
    def parse(cls, text: str) -> KG:
        nodes: Dict[str, KGNode] = {}
        rels: List[KGRel] = []
        for line in text.splitlines():
            m = cls.EDGE_RX.match(line.strip())
            if not m:
                # node declarations like: component api as API
                if " as " in line.lower():
                    parts = re.split(r"\bas\b", line, flags=re.I)
                    if len(parts) == 2:
                        left, right = parts
                        name = normalize_label(right.strip())
                        ident = normalize_label(left.strip().split()[-1])
                        nodes.setdefault(ident, KGNode(id=ident, name=name, type=infer_type(name)))
                continue
            s, t, label = m.groups()
            for n in (s, t):
                if n not in nodes:
                    nodes[n] = KGNode(id=n, name=n, type=infer_type(n))
            rel_type = normalize_label(label or "CONNECTS_TO").upper().replace(" ", "_")
            rels.append(KGRel(source=s, target=t, type=rel_type))
        return KG(nodes=list(nodes.values()), relationships=rels)

# -----------------------------
# draw.io (.drawio XML) extractor
# -----------------------------

class DrawioExtractor:
    @classmethod
    def can_handle(cls, text: str) -> bool:
        return "<mxgraphmodel" in text.lower() or "<mxcell" in text.lower()

    @classmethod
    def parse(cls, text: str) -> KG:
        nodes: Dict[str, KGNode] = {}
        rels: List[KGRel] = []
        root = etree.fromstring(text.encode("utf-8"))
        # Map vertices
        for cell in root.xpath(".//mxCell[@vertex='1']"):
            cid = cell.get("id")
            value = cell.get("value") or ""
            name = normalize_label(etree.HTML(value).xpath("string()") if value else cid)
            nodes[cid] = KGNode(id=cid, name=name, type=infer_type(name))
        # Map edges
        for cell in root.xpath(".//mxCell[@edge='1']"):
            src = cell.get("source")
            trg = cell.get("target")
            if src and trg:
                label = normalize_label(etree.HTML((cell.get('value') or '')).xpath("string()"))
                rel_type = (label or "CONNECTS_TO").upper().replace(" ", "_")
                # Ensure endpoints exist (in case of missing vertex flag)
                for nid in (src, trg):
                    if nid not in nodes:
                        nodes[nid] = KGNode(id=nid, name=nid, type=infer_type(nid))
                rels.append(KGRel(source=src, target=trg, type=rel_type))
        return KG(nodes=list(nodes.values()), relationships=rels)

# -----------------------------
# GraphML extractor
# -----------------------------

class GraphMLExtractor:
    @classmethod
    def can_handle(cls, text: str) -> bool:
        return "<graphml" in text.lower()

    @classmethod
    def parse(cls, text: str) -> KG:
        g = nx.parse_graphml(text)
        nodes: Dict[str, KGNode] = {}
        rels: List[KGRel] = []
        for nid, data in g.nodes(data=True):
            name = normalize_label(str(data.get("label") or data.get("name") or nid))
            nodes[nid] = KGNode(id=nid, name=name, type=infer_type(name), properties={k:str(v) for k,v in data.items()})
        for u, v, data in g.edges(data=True):
            rel_type = normalize_label(str(data.get("label") or data.get("type") or "CONNECTS_TO")).upper().replace(" ", "_")
            rels.append(KGRel(source=u, target=v, type=rel_type, properties={k:str(v) for k,v in data.items()}))
        return KG(nodes=list(nodes.values()), relationships=rels)

# -----------------------------
# JSON extractor (simple)
# -----------------------------

class JsonExtractor:
    @classmethod
    def can_handle(cls, text: str) -> bool:
        s = text.strip()
        return (s.startswith("{") and s.endswith("}")) or (s.startswith("[") and s.endswith("]"))

    @classmethod
    def parse(cls, text: str) -> KG:
        data = json.loads(text)
        if isinstance(data, dict):
            data = [data]
        nodes: List[KGNode] = []
        rels: List[KGRel] = []
        for item in data:
            if "nodes" in item and "relationships" in item:
                nodes.extend([KGNode(**n) for n in item["nodes"]])
                rels.extend([KGRel(**r) for r in item["relationships"]])
        return KG(nodes=nodes, relationships=rels)

# -----------------------------
# Router
# -----------------------------

EXTRACTORS = [MermaidExtractor, PlantUMLExtractor, DrawioExtractor, GraphMLExtractor, JsonExtractor]

def extract_kg_from_text(text: str) -> KG:
    for ex in EXTRACTORS:
        if ex.can_handle(text):
            return ex.parse(text)
    raise ValueError("Unsupported diagram format. Supported: Mermaid, PlantUML, draw.io (.drawio XML), GraphML, simple JSON.")

# -----------------------------
# Neo4j client
# -----------------------------

class Neo4jClient:
    def __init__(self, uri: str, user: str, password: str, database: Optional[str] = None):
        if GraphDatabase is None:
            raise RuntimeError("neo4j driver is not installed. Please install requirements.txt")
        self._driver = GraphDatabase.driver(uri, auth=(user, password))
        self._database = database

    def close(self):
        if self._driver:
            self._driver.close()

    def init_constraints(self):
        cypher = [
            "CREATE CONSTRAINT IF NOT EXISTS FOR (n:Node) REQUIRE n.id IS UNIQUE",
            "CREATE CONSTRAINT IF NOT EXISTS FOR (n:Node) REQUIRE n.name IS UNIQUE"
        ]
        with self._driver.session(database=self._database) as session:
            for stmt in cypher:
                session.run(stmt)

    def upsert(self, kg: KG, namespace: str = "default"):
        node_map: Dict[str, str] = {}

        with self._driver.session(database=self._database) as session:
            # Upsert nodes
            for n in track(kg.nodes, description="[green]Upserting nodes"):
                labels = ":Node"
                node_props = {
                    "id": n.id or n.name,
                    "name": n.name,
                    "type": n.type,
                    "namespace": namespace,
                    **n.properties
                }
                session.run(
                    f"MERGE (n{labels} {{id: $id}}) "
                    f"SET n += $props",
                    {"id": node_props["id"], "props": node_props}
                )
                node_map[n.id or n.name] = node_props["id"]

            # Upsert relationships
            for r in track(kg.relationships, description="[cyan]Upserting relationships]"):
                s_id = node_map.get(r.source, r.source)
                t_id = node_map.get(r.target, r.target)
                rel_props = {"type": r.type, **r.properties, "namespace": namespace}
                session.run(
                    "MATCH (s:Node {id:$sid}), (t:Node {id:$tid}) "
                    f"MERGE (s)-[e:{r.type}]->(t) "
                    "SET e += $props",
                    {"sid": s_id, "tid": t_id, "props": rel_props}
                )

# -----------------------------
# CLI Commands
# -----------------------------

def read_text(path: str) -> str:
    with open(path, "r", encoding="utf-8") as f:
        return f.read()

def write_json(path: str, data: dict):
    import json as _json
    with open(path, "w", encoding="utf-8") as f:
        _json.dump(data, f, indent=2, ensure_ascii=False)

@app.command("extract")
def extract_cmd(
    input_path: str = typer.Argument(..., help="Path to a diagram file: .mmd/.mermaid, .puml, .drawio, .graphml, or JSON"),
    output_json: Optional[str] = typer.Option(None, help="Where to write the extracted KG JSON"),
):
    """Extract a knowledge graph from a diagram file into a structured JSON (nodes + relationships)."""
    text = read_text(input_path)
    kg = extract_kg_from_text(text)
    out = output_json or os.path.splitext(input_path)[0] + ".kg.json"
    write_json(out, kg.model_dump())
    console.print(Panel.fit(f"[bold green]Extracted KG → {out}", border_style="green"))
    print_preview(kg)

def print_preview(kg: KG):
    t = Table(title="Nodes", box=box.SIMPLE_HEAVY)
    t.add_column("id"); t.add_column("name"); t.add_column("type")
    for n in kg.nodes[:50]:
        t.add_row(n.id or n.name, n.name, n.type)
    console.print(t)
    tr = Table(title="Relationships", box=box.SIMPLE_HEAVY)
    tr.add_column("source"); tr.add_column("type"); tr.add_column("target")
    for r in kg.relationships[:100]:
        tr.add_row(r.source, r.type, r.target)
    console.print(tr)

@app.command("push")
def push_cmd(
    kg_json: str = typer.Argument(..., help="Path to KG JSON from `extract`"),
    neo4j_uri: str = typer.Option(os.getenv("NEO4J_URI", "bolt://localhost:7687")),
    neo4j_user: str = typer.Option(os.getenv("NEO4J_USER", "neo4j")),
    neo4j_password: str = typer.Option(os.getenv("NEO4J_PASSWORD", "neo4j")),
    neo4j_db: Optional[str] = typer.Option(os.getenv("NEO4J_DB", None)),
    namespace: str = typer.Option("default", help="Namespace tag to isolate imports"),
    init_constraints: bool = typer.Option(True, help="Create unique constraints for Node.id and Node.name"),
):
    """Push a KG JSON into Neo4j."""
    with open(kg_json, "r", encoding="utf-8") as f:
        kg_data = json.load(f)
    kg = KG(**kg_data)
    client = Neo4jClient(neo4j_uri, neo4j_user, neo4j_password, database=neo4j_db)
    try:
        if init_constraints:
            client.init_constraints()
        client.upsert(kg, namespace=namespace)
    finally:
        client.close()
    console.print(Panel.fit(f"[bold green]Pushed KG to Neo4j @ {neo4j_uri} (db={neo4j_db or 'default'})", border_style="green"))

@app.command("run")
def run_cmd(
    input_path: str = typer.Argument(..., help="Diagram file"),
    neo4j_uri: str = typer.Option(os.getenv("NEO4J_URI", "bolt://localhost:7687")),
    neo4j_user: str = typer.Option(os.getenv("NEO4J_USER", "neo4j")),
    neo4j_password: str = typer.Option(os.getenv("NEO4J_PASSWORD", "neo4j")),
    neo4j_db: Optional[str] = typer.Option(os.getenv("NEO4J_DB", None)),
    namespace: str = typer.Option("default"),
):
    """Convenience wrapper: extract from diagram and push to Neo4j in one go."""
    text = read_text(input_path)
    kg = extract_kg_from_text(text)
    tmp = os.path.splitext(input_path)[0] + ".kg.json"
    write_json(tmp, kg.model_dump())
    console.print(Panel.fit(f"[bold]Extracted → {tmp}", border_style="cyan"))
    print_preview(kg)
    client = Neo4jClient(neo4j_uri, neo4j_user, neo4j_password, database=neo4j_db)
    try:
        client.init_constraints()
        client.upsert(kg, namespace=namespace)
    finally:
        client.close()
    console.print(Panel.fit(f"[bold green]Completed import for {input_path}", border_style="green"))

if __name__ == "__main__":
    app()

# Diagram → Knowledge Graph Agent (v2)

Python agent to extract entities/relationships from **architecture diagrams** and push them into **Neo4j**.

**Focus formats** (no external binaries required):
- **Mermaid** (`graph TD`, `graph LR`, etc.)
- **PlantUML** (`@startuml` … arrows with `-->`)
- **draw.io** (`.drawio` XML — vertices + edges)
- **GraphML** (`.graphml` via NetworkX)
- **JSON** (pre-shaped `{nodes:[], relationships:[]}`)

> Image OCR (PNG/SVG/PDF) is intentionally excluded to keep dependencies light and cross‑platform. If you need OCR, add a pluggable extractor that calls your in‑house OCR API and returns the same `{nodes, relationships}` schema.

---

## Install

```bash
python -m venv .venv && source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## Configure Neo4j

Set environment variables (or use CLI options):

```bash
export NEO4J_URI=bolt://localhost:7687
export NEO4J_USER=neo4j
export NEO4J_PASSWORD=your-password
# export NEO4J_DB=neo4j   # optional, for multi-db
```

The agent will create **unique constraints** on `:Node(id)` and `:Node(name)` on first run.

## Usage

### 1) Extract only

```bash
python agent.py extract diagrams/sample.mmd --output-json sample.kg.json
```

### 2) Push extracted KG to Neo4j

```bash
python agent.py push sample.kg.json --namespace demo
```

### 3) One-shot: extract & push

```bash
python agent.py run diagrams/sample.mmd --namespace demo
```

### Supported inputs (examples)

#### Mermaid

```mermaid
graph LR
  A[Web App] -->|REST| B[(Postgres DB)]
  A --> C[Redis Cache]
  C --> B
```

#### PlantUML

```
@startuml
component API
database DB
API --> DB : JDBC
@enduml
```

#### draw.io

Supply the raw `.drawio` XML file (the agent parses `mxCell` vertices/edges).

#### GraphML

Provide a `.graphml` file. Node `label`/`name` and edge `label`/`type` are read into properties.

#### JSON

```json
{
  "nodes": [
    {"id":"api","name":"Orders API","type":"Service"}
  ],
  "relationships": [
    {"source":"api","target":"db","type":"WRITES_TO"}
  ]
}
```

## Output schema

```json
{
  "nodes": [
    {"id": "A", "name": "Web App", "type": "Service", "properties": {}}
  ],
  "relationships": [
    {"source": "A", "target": "B", "type": "REST_CALL", "properties": {}}
  ]
}
```

Type inference uses simple heuristics (e.g., names containing `db`, `redis`, `api`) and can be extended in `agent.py`.

## Neo4j model

- Every entity is stored as `(:Node {id, name, type, namespace, ...})`
- Edges are `-[TYPE]->` with `{type, namespace, ...}` properties
- Constraints:
  - `CREATE CONSTRAINT IF NOT EXISTS FOR (n:Node) REQUIRE n.id IS UNIQUE`
  - `CREATE CONSTRAINT IF NOT EXISTS FOR (n:Node) REQUIRE n.name IS UNIQUE`

> `namespace` lets you separate multiple imports without collisions.

## Tips

- Keep **IDs stable** across diagram versions to enable efficient `MERGE` upserts.
- If your diagram tool produces HTML in labels, the agent strips tags safely.
- You can add new extractors by implementing `.can_handle()` + `.parse(text) -> KG` and registering in `EXTRACTORS`.

## Troubleshooting

- `neo4j` driver not installed → `pip install -r requirements.txt`
- Auth/connection errors → verify `NEO4J_URI`, `NEO4J_USER`, `NEO4J_PASSWORD`, and network access
- Unsupported format → confirm the file is raw text (e.g., Mermaid code, PlantUML code, `.drawio` XML, GraphML).

---

**License:** MIT  
**Author:** Diagram → KG Agent (v2)

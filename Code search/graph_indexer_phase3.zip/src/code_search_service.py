
from fastapi import FastAPI, Query, HTTPException
from neo4j import GraphDatabase
from typing import List
import os

app = FastAPI(title="Code Search Service", version="1.0.0")

NEO4J_URI = os.getenv("NEO4J_URI", "bolt://neo4j:7687")
NEO4J_USER = os.getenv("NEO4J_USER", "neo4j")
NEO4J_PASSWORD = os.getenv("NEO4J_PASSWORD", "pleasechangeme")

driver = GraphDatabase.driver(NEO4J_URI, auth=(NEO4J_USER, NEO4J_PASSWORD))

def run_query(cypher: str, params: dict):
    with driver.session() as session:
        result = session.run(cypher, **params)
        return [r.data() for r in result]

@app.get("/search/symbol")
def search_symbol(q: str = Query(..., description="Search symbol name")):
    cypher = """
        MATCH (s:Symbol)
        WHERE toLower(s.display) CONTAINS toLower($query)
        RETURN s.symbolKey as symbolKey, s.display as display,
               s.kind as kind, s.language as language
        LIMIT 50
    """
    data = run_query(cypher, {"query": q})
    if not data:
        raise HTTPException(status_code=404, detail="No symbols found")
    return {"results": data}

@app.get("/search/references")
def find_references(q: str = Query(..., description="SymbolKey to find references")):
    cypher = """
        MATCH (s:Symbol {symbolKey:$symbol})<-[:REF|CALLS]-(ref:Symbol)
        RETURN ref.symbolKey as symbolKey, ref.display as display,
               ref.language as language, ref.kind as kind
        LIMIT 100
    """
    data = run_query(cypher, {"symbol": q})
    return {"results": data}

@app.get("/search/impact")
def impact_analysis(q: str = Query(..., description="SymbolKey for impact analysis")):
    cypher = """
        MATCH (s:Symbol {symbolKey:$symbol})-[*1..3]-(related:Symbol)
        RETURN DISTINCT related.symbolKey as symbolKey,
                        related.display as display,
                        related.language as language,
                        related.kind as kind
        LIMIT 100
    """
    data = run_query(cypher, {"symbol": q})
    return {"results": data}

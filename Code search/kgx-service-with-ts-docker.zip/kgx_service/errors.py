from fastapi import HTTPException, status

class UnsupportedLanguage(HTTPException):
    def __init__(self, language: str):
        super().__init__(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Unsupported language '{language}'"
        )

class ExtractorError(HTTPException):
    def __init__(self, detail: str):
        super().__init__(status_code=500, detail=detail)

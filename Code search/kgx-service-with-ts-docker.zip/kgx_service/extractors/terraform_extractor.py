import hcl2, io, re
from typing import Optional
from ..core.graph import Graph
from .base import BaseExtractor

_ref = re.compile(r'\b(\w+)\.(\w+)\.(\w+)\b')  # resource_type.resource_name.attribute

class TerraformExtractor(BaseExtractor):
    def extract(self, content: str, path: Optional[str] = None) -> Graph:
        g = Graph()
        try:
            data = hcl2.load(io.StringIO(content or ""))
        except Exception as e:
            g.add_node("TerraformError", path=path or "<stdin>", error=str(e))
            return g
        mod = g.add_node("TerraformFile", path=path or "<stdin>")

        for prov in (data.get("provider") or []):
            for name in prov.keys():
                p = g.add_node("TFProvider", name=name)
                g.add_edge("USES_PROVIDER", mod, p)

        for modblk in (data.get("module") or []):
            for name, cfg in modblk.items():
                m = g.add_node("TFModule", name=name, source=(cfg or {}).get("source"))
                g.add_edge("CONTAINS", mod, m)

        for res in (data.get("resource") or []):
            for rtype, items in (res or {}).items():
                for rname, cfg in (items or {}).items():
                    r = g.add_node("TFResource", type=rtype, name=rname)
                    g.add_edge("CONTAINS", mod, r)
                    for dep in (cfg or {}).get("depends_on", []):
                        for m in _ref.finditer(dep):
                            dep_r = g.add_node("TFRef", type=m.group(1), name=m.group(2), attr=m.group(3))
                            g.add_edge("DEPENDS_ON", r, dep_r)
                    for v in _walk_values(cfg):
                        for m in _ref.finditer(str(v)):
                            dep_r = g.add_node("TFRef", type=m.group(1), name=m.group(2), attr=m.group(3))
                            g.add_edge("REFERS_TO", r, dep_r)
        return g

def _walk_values(obj):
    if isinstance(obj, dict):
        for v in obj.values():
            yield from _walk_values(v)
    elif isinstance(obj, list):
        for v in obj:
            yield from _walk_values(v)
    else:
        yield obj

import sqlparse, re
from typing import Optional
from ..core.graph import Graph
from .base import BaseExtractor

class SQLExtractor(BaseExtractor):
    _fk = re.compile(r'FOREIGN\s+KEY\s*\([`"]?(\w+)[`"]?\)\s*REFERENCES\s+[`"]?(\w+)[`"]?\s*\([`"]?(\w+)[`"]?\)', re.I)

    def extract(self, content: str, path: Optional[str] = None) -> Graph:
        g = Graph()
        mod = g.add_node("SQLScript", language="sql", path=path or "<stdin>")
        statements = sqlparse.split(content or "")
        for stmt in statements:
            s_low = stmt.lower()
            if "create table" in s_low:
                tbl = self._table_name(stmt)
                if tbl:
                    tnode = g.add_node("Table", name=tbl)
                    g.add_edge("CONTAINS", mod, tnode)
                    for col in self._columns(stmt):
                        cnode = g.add_node("Column", table=tbl, name=col)
                        g.add_edge("HAS_COLUMN", tnode, cnode)
                    for fk_col, ref_table, ref_col in self._fk.findall(stmt):
                        ref_t = g.add_node("Table", name=ref_table)
                        g.add_edge("FK_TO", tnode, ref_t, column=fk_col, ref_col=ref_col)
            elif "select" in s_low:
                for tbl in self._from_tables(stmt):
                    t = g.add_node("TableRef", name=tbl)
                    g.add_edge("SELECTS_FROM", mod, t)
        return g

    def _table_name(self, txt: str):
        m = re.search(r'create\s+table\s+[`"]?(\w+)[`"]?', txt, re.I)
        return m.group(1) if m else None

    def _columns(self, txt: str):
        body = re.search(r'\((.*)\)', txt, re.S)
        if not body: return []
        cols = []
        for line in body.group(1).split(','):
            m = re.match(r'\s*[`"]?(\w+)[`"]?\s+\w+', line.strip(), re.I)
            if m: cols.append(m.group(1))
        return cols

    def _from_tables(self, txt: str):
        return re.findall(r'\bfrom\s+[`"]?(\w+)[`"]?', txt, re.I)

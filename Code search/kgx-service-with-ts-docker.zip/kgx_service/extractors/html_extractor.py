from bs4 import BeautifulSoup
from typing import Optional
from ..core.graph import Graph
from .base import BaseExtractor

class HTMLExtractor(BaseExtractor):
    def extract(self, content: str, path: Optional[str] = None) -> Graph:
        g = Graph()
        doc = BeautifulSoup(content or "", "html.parser")
        page = g.add_node("HTML", path=path or "<stdin>")

        for link in doc.find_all("a", href=True):
            tgt = g.add_node("Link", href=link["href"], text=(link.get_text() or "").strip()[:120])
            g.add_edge("LINKS_TO", page, tgt)

        for s in doc.find_all("script", src=True):
            scr = g.add_node("Script", src=s["src"])
            g.add_edge("LOADS_SCRIPT", page, scr)

        for s in doc.find_all("link", rel=True, href=True):
            if "stylesheet" in s.get("rel", []):
                css = g.add_node("Stylesheet", href=s["href"])
                g.add_edge("LOADS_STYLE", page, css)

        for el in doc.find_all(True):
            if el.get("id"):
                nid = g.add_node("DOMId", id=el["id"], tag=el.name)
                g.add_edge("HAS_DOM_ID", page, nid)
            if el.get("class"):
                for c in el["class"]:
                    cls = g.add_node("DOMClass", className=c, tag=el.name)
                    g.add_edge("HAS_DOM_CLASS", page, cls)
        return g

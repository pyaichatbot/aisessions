import ast
from typing import Optional
from ..core.graph import Graph
from .base import BaseExtractor

class PythonExtractor(BaseExtractor):
    """Conservative Python AST extractor (classes, functions, imports, calls)."""
    def extract(self, content: str, path: Optional[str] = None) -> Graph:
        g = Graph()
        try:
            module = ast.parse(content)
        except SyntaxError as e:
            # still return an empty module node for traceability
            g.add_node("ModuleError", language="python", path=path or "<stdin>", error=str(e))
            return g

        mod_node = g.add_node("Module", language="python", path=path or "<stdin>")

        def qname(parent_q: str, name: str) -> str:
            return f"{parent_q}.{name}" if parent_q else name

        def _call_edges(caller_node, call: ast.Call):
            callee = None
            if isinstance(call.func, ast.Name):
                callee = call.func.id
            elif isinstance(call.func, ast.Attribute):
                callee = call.func.attr
            if callee:
                callee_n = g.add_node("CallTarget", language="python", name=str(callee))
                g.add_edge("CALLS", caller_node, callee_n)

        def visit(node, parent_q=""):
            if isinstance(node, ast.ClassDef):
                n = g.add_node("Class", language="python", name=qname(parent_q, node.name), line=node.lineno)
                g.add_edge("CONTAINS", mod_node, n)
                for base in node.bases:
                    if isinstance(base, ast.Name):
                        base_n = g.add_node("ClassRef", language="python", name=base.id)
                        g.add_edge("INHERITS", n, base_n)
                for b in node.body:
                    visit(b, qname(parent_q, node.name))

            elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                n = g.add_node("Function", language="python", name=qname(parent_q, node.name), line=node.lineno)
                g.add_edge("CONTAINS", mod_node, n)
                for dec in node.decorator_list:
                    if isinstance(dec, ast.Name):
                        d = g.add_node("Decorator", language="python", name=dec.id)
                        g.add_edge("DECORATED_BY", n, d)
                for b in node.body:
                    if isinstance(b, ast.Expr) and isinstance(getattr(b, "value", None), ast.Call):
                        _call_edges(n, b.value)
                    visit(b, parent_q)

            elif isinstance(node, ast.Import):
                for alias in node.names:
                    imp = g.add_node("Import", language="python", name=alias.name)
                    g.add_edge("IMPORTS", mod_node, imp)

            elif isinstance(node, ast.ImportFrom):
                target = (node.module or "")
                for alias in node.names:
                    imp = g.add_node("Import", language="python", name=(target + "." + alias.name) if target else alias.name)
                    g.add_edge("IMPORTS", mod_node, imp)

            elif isinstance(node, ast.Expr) and isinstance(getattr(node, "value", None), ast.Call):
                _call_edges(mod_node, node.value)

            for child in ast.iter_child_nodes(node):
                visit(child, parent_q)

        visit(module)
        return g

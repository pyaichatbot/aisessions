import json
from typing import Optional
from ..core.graph import Graph
from .base import BaseExtractor

class JSONExtractor(BaseExtractor):
    def extract(self, content: str, path: Optional[str] = None) -> Graph:
        g = Graph()
        try:
            root = json.loads(content)
        except Exception as e:
            g.add_node("JSONError", path=path or "<stdin>", error=str(e))
            return g
        mod = g.add_node("JSON", path=path or "<stdin>")

        def walk(obj, parent_node, key_path=""):
            if isinstance(obj, dict):
                for k, v in obj.items():
                    n = g.add_node("JSONKey", key=k, path=f"{key_path}/{k}")
                    g.add_edge("CONTAINS", parent_node, n)
                    if k == "$ref" and isinstance(v, str):
                        ref = g.add_node("JSONRef", target=v)
                        g.add_edge("REFERS_TO", n, ref)
                    walk(v, n, f"{key_path}/{k}")
            elif isinstance(obj, list):
                arr = g.add_node("JSONArray", length=len(obj), path=key_path)
                g.add_edge("CONTAINS", parent_node, arr)
                for i, v in enumerate(obj):
                    idx = g.add_node("JSONIndex", index=i, path=f"{key_path}[{i}]")
                    g.add_edge("CONTAINS", arr, idx)
                    walk(v, idx, f"{key_path}[{i}]")
            else:
                val = g.add_node("JSONValue", type=type(obj).__name__, value=str(obj)[:256], path=key_path)
                g.add_edge("HAS_VALUE", parent_node, val)

        walk(root, mod, "")
        return g

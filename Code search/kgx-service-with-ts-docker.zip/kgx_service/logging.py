import logging, sys, json, time, uuid
from pythonjsonlogger import jsonlogger

def configure_logging(level: str = "INFO"):
    handler = logging.StreamHandler(sys.stdout)
    fmt = jsonlogger.JsonFormatter("%(levelname)s %(message)s")
    handler.setFormatter(fmt)
    root = logging.getLogger()
    root.handlers.clear()
    root.addHandler(handler)
    root.setLevel(level)

class RequestContextFilter(logging.Filter):
    def filter(self, record):
        if not hasattr(record, "request_id"):
            record.request_id = str(uuid.uuid4())
        record.ts = int(time.time()*1000)
        return True

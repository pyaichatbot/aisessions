from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from .logging import configure_logging, RequestContextFilter
from .config import settings
from .errors import UnsupportedLanguage, ExtractorError
from .models import ExtractRequest, UpsertRequest, GraphDict
from .registry import get_registry
from .core.neo4j_writer import Neo4jWriter
import logging
import uuid

configure_logging(settings.app_log_level)
log = logging.getLogger(__name__)
log.addFilter(RequestContextFilter())

app = FastAPI(title="KGX Service", version="1.0.0")

registry = get_registry(settings.ts_lang_so)

@app.middleware("http")
async def add_request_id(request: Request, call_next):
    request_id = str(uuid.uuid4())
    setattr(request.state, "request_id", request_id)
    response = await call_next(request)
    response.headers["X-Request-ID"] = request_id
    return response

@app.get("/healthz")
async def healthz():
    return {"status": "ok"}

@app.post("/extract", response_model=GraphDict)
async def extract(req: ExtractRequest, request: Request):
    lang = req.language.strip().lower()
    extractor = registry.get(lang)
    if not extractor:
        raise UnsupportedLanguage(lang)
    try:
        g = extractor.extract(req.content, req.path)
        payload = g.to_dict()
        log.info("extracted", extra={"request_id": request.state.request_id, "language": lang, "nodes": len(payload["nodes"]), "edges": len(payload["edges"])})
        return payload
    except Exception as e:
        log.exception("extract_failed", extra={"request_id": request.state.request_id, "language": lang})
        raise ExtractorError(str(e))

@app.post("/neo4j/upsert")
async def neo4j_upsert(req: UpsertRequest):
    if not (settings.neo4j_uri and settings.neo4j_user and settings.neo4j_password):
        return JSONResponse(status_code=400, content={"error": "Neo4j environment not configured"})
    writer = Neo4jWriter(settings.neo4j_uri, settings.neo4j_user, settings.neo4j_password, settings.neo4j_database)
    try:
        writer.upsert(req.graph.model_dump())
        return {"status": "upserted", "nodes": len(req.graph.nodes), "edges": len(req.graph.edges)}
    finally:
        writer.close()

# KGX Service — Multi-language Knowledge Graph Extractors for Code Search

Production-grade FastAPI microservice that extracts *language-agnostic* knowledge graphs
from source files and DevOps infra-as-code and (optionally) writes to Neo4j.

**Supported inputs (per-file):**
- Code: Python, Java, PHP, SQL, JSON, HTML
- DevOps: Dockerfile, Kubernetes YAML, Terraform HCL
- (You already have C# Roslyn & TypeScript — integrate similarly via your orchestrator.)

## Features
- Clean, uniform graph schema (nodes/edges) with stable deterministic IDs
- Stateless `/extract` API: accepts content + language + optional path; returns graph JSON
- Optional `/neo4j/upsert` to write a returned graph to Neo4j (disabled by default in prod)
- Structured logging (JSON), request IDs, error handling, and input validation
- 100% type-hinted Python, docstrings & unit tests for core modules
- Dockerfile and docker-compose for local runs
- Zero network calls at parse time; all extractors are offline
- Conservative parsing to avoid false positives; easily swappable backends

## Quick start

```bash
# 1) Build & run
docker compose up --build

# 2) Call the service
curl -s http://localhost:8080/healthz
curl -s -X POST http://localhost:8080/extract -H 'Content-Type: application/json' -d '{
  "language": "python",
  "path": "sample.py",
  "content": "import os\nclass A: pass\n"
}' | jq .
```

> NOTE: PHP parsing uses Tree-sitter. You must prebuild a shared lib once (see below) or disable PHP extractor.

## Environment

- `APP_LOG_LEVEL` (default: `INFO`)
- `NEO4J_URI`, `NEO4J_USER`, `NEO4J_PASSWORD`, `NEO4J_DATABASE` (optional; only needed if you use `/neo4j/upsert`)

## Tree-sitter PHP (optional)

```
git clone https://github.com/tree-sitter/tree-sitter-php vendor/tree-sitter-php
python - <<'PY'
from tree_sitter import Language
Language.build_library('vendor/build/my-languages.so', ['vendor/tree-sitter-php'])
PY
export TS_LANG_SO=vendor/build/my-languages.so
```

## Production notes
- Run behind your API gateway; enable authN/Z and rate limiting there.
- Keep `/neo4j/upsert` disabled outside trusted networks.
- For deeper accuracy, swap parsers to language-native servers and feed their JSON into these extractors.

## License
Apache-2.0

## Zero-setup TypeScript & PHP in Docker
The provided Dockerfile **automatically downloads and compiles** Tree-sitter grammars for
**TypeScript (typescript + tsx)** and **PHP** during image build. No manual steps needed.
The service reads the shared libraries from:
- `TYPESCRIPT_LANG_SO=/opt/vendor/build/ts-languages.so`
- `TS_LANG_SO=/opt/vendor/build/my-languages.so`

Just run:
```bash
docker compose up --build
```

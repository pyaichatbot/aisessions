from dockerfile_parse import DockerfileParser
from io import StringIO
from typing import Optional
from ..core.graph import Graph
from .base import BaseExtractor

class DockerfileExtractor(BaseExtractor):
    def extract(self, content: str, path: Optional[str] = None) -> Graph:
        g = Graph()
        dfp = DockerfileParser(fileobj=StringIO(content or ""))
        mod = g.add_node("Dockerfile", path=path or "Dockerfile")

        if dfp.baseimage:
            base = g.add_node("Image", name=dfp.baseimage)
            g.add_edge("FROM", mod, base)

        for instr in dfp.structure or []:
            cmd = (instr.get("instruction") or "").upper()
            val = instr.get("value", "") or ""
            ins = g.add_node("DockerInstr", cmd=cmd, value=val[:300])
            g.add_edge("HAS_INSTR", mod, ins)
            if cmd == "COPY":
                g.add_edge("COPIES", mod, g.add_node("Copy", args=val))
            if cmd == "EXPOSE":
                g.add_edge("EXPOSES", mod, g.add_node("Port", value=val))
        return g

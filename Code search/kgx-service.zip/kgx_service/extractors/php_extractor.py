import os
from tree_sitter import Language, Parser
from typing import Optional
from ..core.graph import Graph
from .base import BaseExtractor

class PHPExtractor(BaseExtractor):
    """PHP extractor via Tree-sitter (requires TS_LANG_SO with php grammar)."""
    def __init__(self, ts_lang_so: str | None = None):
        lib = ts_lang_so or os.getenv("TS_LANG_SO")
        if not lib or not os.path.exists(lib):
            self.parser = None
            self._error = "Tree-sitter PHP .so not found; set TS_LANG_SO"
        else:
            PHP = Language(lib, 'php')
            self.parser = Parser()
            self.parser.set_language(PHP)
            self._error = None

    def extract(self, content: str, path: Optional[str] = None) -> Graph:
        g = Graph()
        mod = g.add_node("Module", language="php", path=path or "<stdin>")
        if not self.parser:
            g.add_node("ParserError", language="php", error=self._error or "Parser not initialized")
            return g

        tree = self.parser.parse(bytes(content, "utf8"))
        root = tree.root_node

        def text(node):
            return content[node.start_byte:node.end_byte]

        def walk(n):
            t = n.type
            if t == "class_declaration":
                name = next((c for c in n.children if c.type == "name"), None)
                if name:
                    cls = g.add_node("Class", language="php", name=text(name))
                    g.add_edge("CONTAINS", mod, cls)
            elif t in ("function_definition", "method_declaration"):
                name = next((c for c in n.children if c.type == "name"), None)
                if name:
                    fn = g.add_node("Function", language="php", name=text(name))
                    g.add_edge("CONTAINS", mod, fn)
            for c in n.children:
                walk(c)

        walk(root)
        return g

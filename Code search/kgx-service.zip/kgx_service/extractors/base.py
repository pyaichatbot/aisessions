from abc import ABC, abstractmethod
from typing import Optional
from ..core.graph import Graph

class BaseExtractor(ABC):
    @abstractmethod
    def extract(self, content: str, path: Optional[str] = None) -> Graph: ...

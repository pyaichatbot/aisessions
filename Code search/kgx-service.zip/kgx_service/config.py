from pydantic import BaseModel
import os

class Settings(BaseModel):
    app_log_level: str = os.getenv("APP_LOG_LEVEL", "INFO")
    neo4j_uri: str | None = os.getenv("NEO4J_URI")
    neo4j_user: str | None = os.getenv("NEO4J_USER")
    neo4j_password: str | None = os.getenv("NEO4J_PASSWORD")
    neo4j_database: str | None = os.getenv("NEO4J_DATABASE")
    ts_lang_so: str | None = os.getenv("TS_LANG_SO")  # tree-sitter languages .so

settings = Settings()

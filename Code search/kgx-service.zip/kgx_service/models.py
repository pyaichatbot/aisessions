from pydantic import BaseModel, Field
from typing import Any, Dict, List

class ExtractRequest(BaseModel):
    language: str = Field(..., description="Language or filetype, e.g., python, java, php, sql, json, html, dockerfile, k8s, terraform")
    content: str = Field(..., description="File content")
    path: str | None = Field(default=None, description="Optional logical path for stable IDs")

class GraphDict(BaseModel):
    nodes: List[Dict[str, Any]]
    edges: List[Dict[str, Any]]

class UpsertRequest(BaseModel):
    graph: GraphDict

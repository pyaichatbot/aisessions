from fastapi import APIRouter, Depends, HTTPException
from ...dependencies import require_api_key
from ....services.graph_service import GraphService

router = APIRouter()

@router.get("/{doc_id}")
def get_document(doc_id: str, _=Depends(require_api_key)):
    cypher = """
    MATCH (d:Document {id: $doc_id})
    OPTIONAL MATCH (d)-[:HAS_PAGE]->(p:Page)
    OPTIONAL MATCH (p)-[:HAS_CHUNK]->(c:Chunk)
    RETURN d as document, count(DISTINCT p) as pages, count(DISTINCT c) as chunks
    """
    records = GraphService.run_read(cypher, {"doc_id": doc_id})
    if not records:
        raise HTTPException(status_code=404, detail="Document not found")
    rec = records[0]
    return {
        "document": rec.get("document"),
        "pages": rec.get("pages"),
        "chunks": rec.get("chunks"),
    }

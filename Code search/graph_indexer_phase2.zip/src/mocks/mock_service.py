
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Dict, Optional
import ast, re, hashlib, uuid

app = FastAPI(title="Mock Analyzers")

class AnalyzeRequest(BaseModel):
    language: str
    projectId: str
    filePath: str
    content: str

def file_id(pid: str, path: str, content: str) -> str:
    h = hashlib.sha256((pid + path + hashlib.sha256(content.encode()).hexdigest()).encode()).hexdigest()
    return str(uuid.UUID(h[0:32]))

def base_response(req: AnalyzeRequest):
    return {
        "file": {"id": file_id(req.projectId, req.filePath, req.content), "path": req.filePath, "hash": hashlib.sha256(req.content.encode()).hexdigest()},
        "symbols": [],
        "edges": [],
        "externals": []
    }

@app.post("/analyze")
def analyze(req: AnalyzeRequest):
    lang = req.language.lower()
    if lang == "csharp":
        return analyze_csharp(req)
    if lang == "java":
        return analyze_java(req)
    if lang in ("typescript","ts","javascript","js"):
        return analyze_js_ts(req)
    if lang == "python":
        return analyze_python(req)
    if lang == "php":
        return analyze_php(req)
    if lang == "sql":
        return analyze_sql(req)
    raise HTTPException(status_code=400, detail=f"Unsupported language {req.language}")

def analyze_csharp(req: AnalyzeRequest):
    r = base_response(req)
    ns_match = re.search(r"namespace\s+([\w\.]+)", req.content)
    ns = ns_match.group(1) if ns_match else "Global"
    ns_key = f"N:{ns}"
    r["symbols"].append({"symbolKey": ns_key, "display": ns, "kind": "namespace", "language": "csharp"})
    for cls in re.finditer(r"class\s+(\w+)", req.content):
        class_name = cls.group(1)
        key = f"T:{ns}.{class_name}"
        r["symbols"].append({"symbolKey": key, "display": f"{ns}.{class_name}", "kind": "type", "containerKey": ns_key, "language": "csharp"})
    for m in re.finditer(r"(public|private|protected)\s+\w+[<\w,>\[\]]*\s+(\w+)\s*\(", req.content):
        method_name = m.group(2)
        key = f"M:{ns}.{method_name}()"
        r["symbols"].append({"symbolKey": key, "display": f"{ns}.{method_name}()", "kind": "member", "containerKey": ns_key, "language": "csharp"})
    return r

def analyze_java(req: AnalyzeRequest):
    r = base_response(req)
    pkg_match = re.search(r"package\s+([\w\.]+);", req.content)
    pkg = pkg_match.group(1) if pkg_match else "default"
    pkg_key = f"N:{pkg}"
    r["symbols"].append({"symbolKey": pkg_key, "display": pkg, "kind": "namespace", "language": "java"})
    for cls in re.finditer(r"class\s+(\w+)", req.content):
        cname = cls.group(1)
        key = f"T:{pkg}.{cname}"
        r["symbols"].append({"symbolKey": key, "display": f"{pkg}.{cname}", "kind": "type", "containerKey": pkg_key, "language": "java"})
    return r

def analyze_python(req: AnalyzeRequest):
    r = base_response(req)
    module = req.filePath.replace("/", ".")
    container = f"N:{module}"
    r["symbols"].append({"symbolKey": container, "display": module, "kind": "namespace", "language": "python"})
    try:
        tree = ast.parse(req.content)
    except Exception:
        return r
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef):
            name = node.name
            key = f"M:{module}.{name}()"
            r["symbols"].append({"symbolKey": key, "display": f"{module}.{name}()", "kind": "member", "containerKey": container, "language": "python"})
        elif isinstance(node, ast.ClassDef):
            cname = node.name
            key = f"T:{module}.{cname}"
            r["symbols"].append({"symbolKey": key, "display": f"{module}.{cname}", "kind": "type", "containerKey": container, "language": "python"})
    return r

def analyze_js_ts(req: AnalyzeRequest):
    r = base_response(req)
    module = req.filePath.replace("/", ".")
    container = f"N:{module}"
    r["symbols"].append({"symbolKey": container, "display": module, "kind": "namespace", "language": "javascript"})
    for m in re.finditer(r"function\s+(\w+)\s*\(", req.content):
        name = m.group(1)
        key = f"M:{module}.{name}()"
        r["symbols"].append({"symbolKey": key, "display": f"{module}.{name}()", "kind": "member", "containerKey": container, "language": "javascript"})
    return r

def analyze_php(req: AnalyzeRequest):
    r = base_response(req)
    ns_match = re.search(r"namespace\s+([\\\w]+);", req.content)
    ns = ns_match.group(1) if ns_match else "Global"
    ns_key = f"N:{ns}"
    r["symbols"].append({"symbolKey": ns_key, "display": ns, "kind": "namespace", "language": "php"})
    for cls in re.finditer(r"class\s+(\w+)", req.content):
        cname = cls.group(1)
        key = f"T:{ns}.{cname}"
        r["symbols"].append({"symbolKey": key, "display": f"{ns}.{cname}", "kind": "type", "containerKey": ns_key, "language": "php"})
    return r

def analyze_sql(req: AnalyzeRequest):
    r = base_response(req)
    ns = f"N:{req.filePath}"
    r["symbols"].append({"symbolKey": ns, "display": req.filePath, "kind": "namespace", "language": "sql"})
    for m in re.finditer(r"FROM\s+([\w\.]+)", req.content, re.IGNORECASE):
        t = m.group(1)
        key = f"T:{t}"
        r["symbols"].append({"symbolKey": key, "display": t, "kind": "type", "containerKey": ns, "language": "sql"})
    return r

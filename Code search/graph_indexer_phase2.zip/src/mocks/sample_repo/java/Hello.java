package demo.core;
public class Hello {
    public void say() {
        System.out.println("Hello Java");
    }
}
<?php
namespace Demo\Core;
class Util {
    public function ping() {
        echo "pong";
    }
}
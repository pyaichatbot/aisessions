class Animal:
    pass
class Dog(Animal):
    def bark(self):
        print("woof")
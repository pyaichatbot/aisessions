class Order { }
function place(orderId: number) {
    console.log(orderId);
}
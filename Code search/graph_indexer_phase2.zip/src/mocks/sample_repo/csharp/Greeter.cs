using System;
namespace Demo.Core {
    public class Greeter {
        public void SayHello() {
            Console.WriteLine("Hello from C#");
        }
    }
}
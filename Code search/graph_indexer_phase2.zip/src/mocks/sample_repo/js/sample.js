function greet(name) {
    console.log("Hello " + name);
}
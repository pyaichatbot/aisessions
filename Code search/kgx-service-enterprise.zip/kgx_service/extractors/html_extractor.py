from bs4 import BeautifulSoup
from typing import Optional
from ..core.graph import Graph
from .base import BaseExtractor

MAX_INLINE_LEN = 2000

class HTMLExtractor(BaseExtractor):
    def extract(self, content: str, path: Optional[str] = None) -> Graph:
        g = Graph()
        doc = BeautifulSoup(content or "", "html.parser")
        page = g.add_node("HTML", path=path or "<stdin>")

        # Meta & canonical
        for m in doc.find_all("meta"):
            name = m.get("name") or m.get("property")
            if name:
                meta = g.add_node("Meta", name=name, content=(m.get("content") or "")[:256])
                g.add_edge("HAS_META", page, meta)
        link_canon = doc.find("link", rel=lambda v: v and "canonical" in v)
        if link_canon and link_canon.get("href"):
            canon = g.add_node("Canonical", href=link_canon["href"])
            g.add_edge("HAS_CANONICAL", page, canon)

        for link in doc.find_all("a", href=True):
            tgt = g.add_node("Link", href=link["href"], text=(link.get_text() or "").strip()[:120])
            g.add_edge("LINKS_TO", page, tgt)

        for s in doc.find_all("script"):
            if s.get("src"):
                scr = g.add_node("Script", src=s["src"])
                g.add_edge("LOADS_SCRIPT", page, scr)
            else:
                body = (s.string or "")[:MAX_INLINE_LEN]
                if body.strip():
                    scr = g.add_node("InlineScript", length=len(body))
                    g.add_edge("HAS_INLINE_SCRIPT", page, scr)
        for st in doc.find_all("style"):
            body = (st.string or "")[:MAX_INLINE_LEN]
            if body.strip():
                css = g.add_node("InlineStyle", length=len(body))
                g.add_edge("HAS_INLINE_STYLE", page, css)

        for s in doc.find_all("link", rel=True, href=True):
            if "stylesheet" in s.get("rel", []):
                css = g.add_node("Stylesheet", href=s["href"])
                g.add_edge("LOADS_STYLE", page, css)

        for el in doc.find_all(True):
            if el.get("id"):
                nid = g.add_node("DOMId", id=el["id"], tag=el.name)
                g.add_edge("HAS_DOM_ID", page, nid)
            if el.get("class"):
                for c in el["class"]:
                    cls = g.add_node("DOMClass", className=c, tag=el.name)
                    g.add_edge("HAS_DOM_CLASS", page, cls)
        return g

import yaml
from typing import Optional, Dict, Any
from ..core.graph import Graph
from .base import BaseExtractor

class K8sExtractor(BaseExtractor):
    def extract(self, content: str, path: Optional[str] = None) -> Graph:
        g = Graph()
        docs = list(yaml.safe_load_all(content or ""))
        bundle = g.add_node("K8sBundle", path=path or "<stdin>")

        for d in docs:
            if not isinstance(d, dict): 
                continue
            kind = d.get("kind")
            meta = d.get("metadata", {}) or {}
            name = meta.get("name")
            ns = meta.get("namespace", "default")
            labels = meta.get("labels", {}) or {}
            ann = meta.get("annotations", {}) or {}
            rnode = g.add_node("K8sResource", kind=kind, name=name, namespace=ns)
            g.add_edge("CONTAINS", bundle, rnode)
            for k, v in labels.items():
                lbl = g.add_node("Label", key=k, value=v)
                g.add_edge("HAS_LABEL", rnode, lbl)
            for k, v in ann.items():
                an = g.add_node("Annotation", key=k, value=str(v)[:256])
                g.add_edge("HAS_ANNOTATION", rnode, an)

            if kind in ("Deployment", "StatefulSet", "DaemonSet"):
                spec = (d.get("spec") or {})
                tmpl = ((spec.get("template") or {}).get("spec") or {})
                for c in (tmpl.get("containers") or []):
                    img = g.add_node("Image", name=c.get("image"))
                    g.add_edge("USES_IMAGE", rnode, img)
                for v in (tmpl.get("volumes") or []):
                    if "configMap" in v:
                        cfg = g.add_node("ConfigMapRef", name=v["configMap"]["name"])
                        g.add_edge("MOUNTS", rnode, cfg)
                    if "secret" in v:
                        sec = g.add_node("SecretRef", name=v["secret"]["secretName"])
                        g.add_edge("MOUNTS", rnode, sec)

            if kind == "Service":
                selector = (d.get("spec") or {}).get("selector", {}) or {}
                if selector:
                    sel = g.add_node("Selector", **{f"label_{k}": v for k, v in selector.items()})
                    g.add_edge("SELECTS", rnode, sel)

            if kind == "Ingress":
                rules = ((d.get("spec") or {}).get("rules") or [])
                for r in rules:
                    host = r.get("host")
                    if host:
                        h = g.add_node("IngressHost", host=host)
                        g.add_edge("ROUTES_HOST", rnode, h)
        return g

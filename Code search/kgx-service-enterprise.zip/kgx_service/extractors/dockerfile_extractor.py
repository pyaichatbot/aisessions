from dockerfile_parse import DockerfileParser
from io import StringIO
from typing import Optional
from ..core.graph import Graph
from .base import BaseExtractor

class DockerfileExtractor(BaseExtractor):
    def extract(self, content: str, path: Optional[str] = None) -> Graph:
        g = Graph()
        dfp = DockerfileParser(fileobj=StringIO(content or ""))
        mod = g.add_node("Dockerfile", path=path or "Dockerfile")

        if dfp.baseimage:
            base = g.add_node("Image", name=dfp.baseimage)
            g.add_edge("FROM", mod, base)

        entrypoint = dfp.entrypoint or None
        if entrypoint:
            g.add_edge("ENTRYPOINT", mod, g.add_node("Entrypoint", value=str(entrypoint)))
        cmd = dfp.cmd or None
        if cmd:
            g.add_edge("CMD", mod, g.add_node("Cmd", value=str(cmd)))

        envs = dfp.envs or {}
        for k, v in envs.items():
            g.add_edge("SETS_ENV", mod, g.add_node("Env", key=k, value=v))

        for instr in dfp.structure or []:
            cmdi = (instr.get("instruction") or "").upper()
            val = instr.get("value", "") or ""
            ins = g.add_node("DockerInstr", cmd=cmdi, value=val[:300])
            g.add_edge("HAS_INSTR", mod, ins)
            if cmdi == "COPY":
                g.add_edge("COPIES", mod, g.add_node("Copy", args=val))
            if cmdi == "EXPOSE":
                g.add_edge("EXPOSES", mod, g.add_node("Port", value=val))
            if cmdi == "ARG":
                parts = [p.strip() for p in val.split("=")]
                key = parts[0]; default = parts[1] if len(parts) > 1 else None
                g.add_edge("HAS_ARG", mod, g.add_node("Arg", key=key, default=default))
        return g

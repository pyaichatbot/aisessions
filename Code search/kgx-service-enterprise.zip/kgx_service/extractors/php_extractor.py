import os
from tree_sitter import Language, Parser
from typing import Optional
from ..core.graph import Graph
from .base import BaseExtractor
from .html_extractor import HTMLExtractor

class PHPExtractor(BaseExtractor):
    """PHP extractor via Tree-sitter (requires TS_LANG_SO with php grammar).
    - Classes, functions
    - Embedded HTML segments are parsed by HTMLExtractor and merged.
    """
    def __init__(self, ts_lang_so: str | None = None):
        lib = ts_lang_so or os.getenv("TS_LANG_SO")
        if not lib or not os.path.exists(lib):
            self.parser = None
            self._error = "Tree-sitter PHP .so not found; set TS_LANG_SO"
        else:
            PHP = Language(lib, 'php')
            self.parser = Parser()
            self.parser.set_language(PHP)
            self._error = None
        self.html = HTMLExtractor()

    def extract(self, content: str, path: Optional[str] = None) -> Graph:
        g = Graph()
        mod = g.add_node("Module", language="php", path=path or "<stdin>")
        if not self.parser:
            g.add_node("ParserError", language="php", error=self._error or "Parser not initialized")
            return g

        src = content or ""
        tree = self.parser.parse(bytes(src, "utf8"))
        root = tree.root_node

        def text(node):
            return src[node.start_byte:node.end_byte]

        def walk(n):
            t = n.type
            if t == "class_declaration":
                name = next((c for c in n.children if c.type == "name"), None)
                if name:
                    cls = g.add_node("Class", language="php", name=text(name))
                    g.add_edge("CONTAINS", mod, cls)
            elif t in ("function_definition", "method_declaration"):
                name = next((c for c in n.children if c.type == "name"), None)
                if name:
                    fn = g.add_node("Function", language="php", name=text(name))
                    g.add_edge("CONTAINS", mod, fn)
            elif t in ("text", "inline_html"):
                html_txt = text(n)
                if "<" in html_txt and ">" in html_txt:
                    hg = self.html.extract(html_txt, path=f"{(path or '<stdin>')}:inline_html")
                    # stitch: link a synthetic HTML root under this PHP module
                    html_root_nodes = [nn for nn in hg.to_dict()["nodes"] if nn["kind"] == "HTML"]
                    # merge nodes
                    for nid, node in hg.nodes.items():
                        g.nodes.setdefault(nid, node)
                    g.edges.extend(hg.edges)
                    # add an EMBEDS_HTML edge
                    for nn in html_root_nodes:
                        # we need a Node object; re-create a thin one
                        from ..core.graph import Node
                        html_node = g.nodes.get(nn["id"]) or g.add_node("HTML", path=nn.get("path"))
                        g.add_edge("EMBEDS_HTML", mod, html_node)

            for c in n.children:
                walk(c)

        walk(root)
        return g

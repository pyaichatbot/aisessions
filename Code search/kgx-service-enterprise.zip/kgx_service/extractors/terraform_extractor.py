import hcl2, io, re
from typing import Optional
from ..core.graph import Graph
from .base import BaseExtractor

# Matches: aws_instance.web.id, data.aws_ami.ubuntu.id, var.env, module.vpc.id, local.name
_ref = re.compile(r'\b(?:(data|var|module|local)s?)?(?:\.)?([A-Za-z0-9_]+)\.(?:([A-Za-z0-9_]+))(?:(?:\.)([A-Za-z0-9_]+))?\b')

class TerraformExtractor(BaseExtractor):
    def extract(self, content: str, path: Optional[str] = None) -> Graph:
        g = Graph()
        try:
            data = hcl2.load(io.StringIO(content or ""))
        except Exception as e:
            g.add_node("TerraformError", path=path or "<stdin>", error=str(e))
            return g
        mod = g.add_node("TerraformFile", path=path or "<stdin>")

        for prov in (data.get("provider") or []):
            for name in prov.keys():
                p = g.add_node("TFProvider", name=name)
                g.add_edge("USES_PROVIDER", mod, p)

        for modblk in (data.get("module") or []):
            for name, cfg in modblk.items():
                m = g.add_node("TFModule", name=name, source=(cfg or {}).get("source"))
                g.add_edge("CONTAINS", mod, m)

        for out in (data.get("output") or []):
            for name, cfg in out.items():
                o = g.add_node("TFOutput", name=name)
                g.add_edge("CONTAINS", mod, o)

        for loc in (data.get("locals") or []):
            for name, val in (loc or {}).items():
                l = g.add_node("TFLocal", name=name)
                g.add_edge("CONTAINS", mod, l)

        for dat in (data.get("data") or []):
            for dtype, items in (dat or {}).items():
                for dname, cfg in (items or {}).items():
                    r = g.add_node("TFData", type=dtype, name=dname)
                    g.add_edge("CONTAINS", mod, r)

        for res in (data.get("resource") or []):
            for rtype, items in (res or {}).items():
                for rname, cfg in (items or {}).items():
                    r = g.add_node("TFResource", type=rtype, name=rname)
                    g.add_edge("CONTAINS", mod, r)
                    for dep in (cfg or {}).get("depends_on", []):
                        for m in _walk_refs(dep):
                            g.add_edge("DEPENDS_ON", r, m)
                    for v in _walk_values(cfg):
                        for m in _walk_refs(v):
                            g.add_edge("REFERS_TO", r, m)
        return g

def _walk_values(obj):
    if isinstance(obj, dict):
        for v in obj.values():
            yield from _walk_values(v)
    elif isinstance(obj, list):
        for v in obj:
            yield from _walk_values(v)
    else:
        yield obj

def _walk_refs(s):
    from ..core.graph import Graph
    # We can't access the graph here; instead we return lightweight nodes to attach later.
    # To keep consistent, create detached descriptors; the caller will create nodes.
    class _Ref:
        def __init__(self, kind, type_, name, attr):
            self.kind = kind; self.type = type_; self.name = name; self.attr = attr
    refs = []
    for m in _ref.finditer(str(s)):
        prefix, t1, t2, t3 = m.groups()
        if prefix in ("data", "datas"):
            refs.append(_Ref("TFDataRef", t1, t2, t3))
        elif prefix in ("var", "vars"):
            refs.append(_Ref("TFVarRef", t1, t2, t3))
        elif prefix in ("module", "modules"):
            refs.append(_Ref("TFModuleRef", t1, t2, t3))
        elif prefix in ("local", "locals"):
            refs.append(_Ref("TFLocalRef", t1, t2, t3))
        else:
            refs.append(_Ref("TFRef", t1, t2, t3))
    # Convert to nodes
    nodes = []
    from ..core.graph import Graph as _G
    g = _G()  # temp graph to create Node ids; we'll copy props
    for r in refs:
        n = g.add_node(r.kind, type=r.type, name=r.name, attr=r.attr)
        nodes.append(n)
    return nodes

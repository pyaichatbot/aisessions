import os, re
from tree_sitter import Language, Parser
from typing import Optional
from ..core.graph import Graph
from .base import BaseExtractor

_A_SELECTOR = re.compile(r"selector\s*:\s*['\"]([^'\"]+)['\"]")
_A_TEMPLATEURL = re.compile(r"templateUrl\s*:\s*['\"]([^'\"]+)['\"]")
_A_STYLEURLS = re.compile(r"styleUrls\s*:\s*\[([^\]]*)\]")
_A_PROVIDERS = re.compile(r"providers\s*:\s*\[([^\]]*)\]")
_A_DECLS = re.compile(r"declarations\s*:\s*\[([^\]]*)\]")
_A_IMPORTS = re.compile(r"imports\s*:\s*\[([^\]]*)\]")

def _arr_items(txt: str):
    return [x.strip().strip('"\'') for x in txt.split(',') if x.strip()]

def _first(seq):
    return seq[0] if seq else None

class TypeScriptExtractor(BaseExtractor):
    """TypeScript/Angular extractor using Tree-sitter.
    - Classes, Functions, Imports
    - Decorators: @Component, @Injectable, @Directive, @Pipe, @NgModule (basic metadata)
    Supports TS and TSX: tries 'typescript', falls back to 'tsx' grammar if available.
    """
    def __init__(self, ts_lang_so: str | None = None):
        lib = ts_lang_so or os.getenv("TYPESCRIPT_LANG_SO")
        self.parsers = []
        self._error = None
        if not lib or not os.path.exists(lib):
            self._error = "Tree-sitter typescript .so not found; set TYPESCRIPT_LANG_SO"
        else:
            try:
                TS = Language(lib, 'typescript')
                p = Parser(); p.set_language(TS)
                self.parsers.append(p)
            except Exception as e:
                self._error = f"typescript load failed: {e}"
            try:
                TSX = Language(lib, 'tsx')
                p2 = Parser(); p2.set_language(TSX)
                self.parsers.append(p2)
            except Exception:
                # TSX optional
                pass

    def extract(self, content: str, path: Optional[str] = None) -> Graph:
        g = Graph()
        mod = g.add_node("Module", language="typescript", path=path or "<stdin>")
        if not self.parsers:
            g.add_node("ParserError", language="typescript", error=self._error or "Parser not initialized")
            return g

        src = content or ""
        tree = None
        parser_used = None
        for p in self.parsers:
            try:
                tree = p.parse(bytes(src, "utf8"))
                parser_used = p
                break
            except Exception:
                continue
        if tree is None:
            g.add_node("ParserError", language="typescript", error="parse failed")
            return g

        root = tree.root_node

        def text(node):
            return src[node.start_byte:node.end_byte]

        def walk(n, parent=None):
            t = n.type
            if t == "import_statement":
                imp = g.add_node("Import", language="typescript", text=text(n)[:300])
                g.add_edge("IMPORTS", mod, imp)
            if t in ("function_declaration",):
                name = None
                for c in n.children:
                    if c.type in ("identifier", "type_identifier"):
                        name = text(c)
                        break
                if name:
                    fn = g.add_node("Function", language="typescript", name=name)
                    g.add_edge("CONTAINS", mod, fn)
            if t == "class_declaration":
                cname = None
                decos = []
                for c in n.children:
                    if c.type in ("identifier", "type_identifier") and cname is None:
                        cname = text(c)
                    if c.type == "decorator":
                        decos.append(c)
                if cname:
                    cls = g.add_node("Class", language="typescript", name=cname)
                    g.add_edge("CONTAINS", mod, cls)
                    for d in decos:
                        deco_txt = text(d)
                        if "@Component" in deco_txt:
                            comp = g.add_node("AngularComponent", name=cname,
                                              selector=_first(_A_SELECTOR.findall(deco_txt)),
                                              templateUrl=_first(_A_TEMPLATEURL.findall(deco_txt)))
                            g.add_edge("ANGULAR_COMPONENT", cls, comp)
                            for arr_re, kind in [(_A_STYLEURLS, "StyleUrl"), (_A_PROVIDERS, "Provider")]:
                                m = arr_re.search(deco_txt)
                                if m:
                                    for item in _arr_items(m.group(1)):
                                        nitem = g.add_node(kind, value=item)
                                        g.add_edge("HAS_META", comp, nitem)
                            # link external template reference if present
                            tpl = _first(_A_TEMPLATEURL.findall(deco_txt))
                            if tpl:
                                ref = g.add_node("ExternalTemplateRef", path=tpl)
                                g.add_edge("USES_TEMPLATE", comp, ref)
                        elif "@NgModule" in deco_txt:
                            ng = g.add_node("AngularModule", name=cname)
                            g.add_edge("ANGULAR_MODULE", cls, ng)
                            for arr_re, kind in [(_A_DECLS, "Declaration"), (_A_IMPORTS, "ImportRef"), (_A_PROVIDERS, "Provider")]:
                                m = arr_re.search(deco_txt)
                                if m:
                                    for item in _arr_items(m.group(1)):
                                        nitem = g.add_node(kind, value=item)
                                        g.add_edge("HAS_META", ng, nitem)
                        elif "@Injectable" in deco_txt:
                            inj = g.add_node("AngularInjectable", name=cname)
                            g.add_edge("ANGULAR_INJECTABLE", cls, inj)
                        elif "@Directive" in deco_txt:
                            dr = g.add_node("AngularDirective", name=cname)
                            g.add_edge("ANGULAR_DIRECTIVE", cls, dr)
                        elif "@Pipe" in deco_txt:
                            pp = g.add_node("AngularPipe", name=cname)
                            g.add_edge("ANGULAR_PIPE", cls, pp)
            for c in n.children:
                walk(c, n)

        walk(root, None)
        return g

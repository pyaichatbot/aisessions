from .extractors.python_extractor import PythonExtractor
from .extractors.java_extractor import JavaExtractor
from .extractors.php_extractor import PHPExtractor
from .extractors.sql_extractor import SQLExtractor
from .extractors.json_extractor import JSONExtractor
from .extractors.html_extractor import HTMLExtractor
from .extractors.dockerfile_extractor import DockerfileExtractor
from .extractors.k8s_extractor import K8sExtractor
from .extractors.terraform_extractor import TerraformExtractor
from .extractors.typescript_extractor import TypeScriptExtractor
from .config import settings

def get_registry(ts_lang_so: str | None = None):
    return {
        "python": PythonExtractor(),
        "java": JavaExtractor(),
        "php": PHPExtractor(ts_lang_so=ts_lang_so or settings.ts_lang_so),
        "sql": SQLExtractor(),
        "json": JSONExtractor(),
        "html": HTMLExtractor(),
        "dockerfile": DockerfileExtractor(),
        "k8s": K8sExtractor(),
        "terraform": TerraformExtractor(),
        "typescript": TypeScriptExtractor(ts_lang_so=settings.typescript_lang_so),
        "ts": TypeScriptExtractor(ts_lang_so=settings.typescript_lang_so),
        "tsx": TypeScriptExtractor(ts_lang_so=settings.typescript_lang_so),
    }

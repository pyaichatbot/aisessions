"""PDF Knowledge Graph Extractor Application"""
__version__ = "1.0.0"

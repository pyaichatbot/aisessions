from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    # Application
    app_name: str = "PDF Knowledge Graph Extractor"
    app_version: str = "1.0.0"
    environment: str = "development"
    debug: bool = False
    log_level: str = "INFO"
    # Server
    host: str = "0.0.0.0"
    port: int = 8000
    workers: int = 4
    # Neo4j
    neo4j_uri: str = "bolt://localhost:7687"
    neo4j_user: str = "neo4j"
    neo4j_password: str = "password"
    neo4j_database: str = "neo4j"
    # Redis
    redis_url: str = "redis://localhost:6379/0"
    # File handling
    upload_dir: str = "/tmp/uploads"
    max_file_size: int = 50 * 1024 * 1024  # 50MB
    # NLP
    spacy_model: str = "en_core_web_sm"
    sentence_transformer_model: str = "all-MiniLM-L6-v2"

    class Config:
        env_file = ".env"
        case_sensitive = False

settings = Settings()

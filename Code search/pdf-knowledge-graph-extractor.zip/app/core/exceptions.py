class PDFExtractorException(Exception):
    """Base exception for PDF extractor"""
    pass

class PDFProcessingError(PDFExtractorException):
    """Raised when PDF processing fails"""
    pass

class Neo4jConnectionError(PDFExtractorException):
    """Raised when Neo4j connection fails"""
    pass

class NLPProcessingError(PDFExtractorException):
    """Raised when NLP processing fails"""
    pass

class ValidationError(PDFExtractorException):
    """Raised when input validation fails"""
    pass

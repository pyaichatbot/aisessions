from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import structlog

from app.core.config import settings
from app.core.logging import setup_logging
from app.api.endpoints import pdf_processing, graph_query
from app.api.dependencies import get_neo4j_service

# Setup logging
setup_logging(settings.log_level)
logger = structlog.get_logger(__name__)

app = FastAPI(
    title=settings.app_name,
    version=settings.app_version,
    description="Enterprise-grade PDF Knowledge Graph Extractor",
    docs_url="/docs" if settings.debug else None,
    redoc_url="/redoc" if settings.debug else None
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"] if settings.debug else [],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Routers
app.include_router(pdf_processing.router, prefix="/api/v1")
app.include_router(graph_query.router, prefix="/api/v1")

@app.on_event("startup")
async def startup_event():
    logger.info("Starting PDF Knowledge Graph Extractor",
                version=settings.app_version,
                environment=settings.environment)
    # Ensure Neo4j connection & constraints
    get_neo4j_service()

@app.on_event("shutdown")
async def shutdown_event():
    svc = get_neo4j_service()
    svc.close()
    logger.info("Shutting down PDF Knowledge Graph Extractor")

@app.get("/")
async def root():
    return {
        "name": settings.app_name,
        "version": settings.app_version,
        "environment": settings.environment,
        "status": "running"
    }

@app.get("/health")
async def health_check():
    return {"status": "healthy", "version": settings.app_version}

import PyPDF2
import pdfplumber
from typing import Dict, List, Any
import structlog
from pathlib import Path
import anyio

from app.core.exceptions import PDFProcessingError
from app.models.entities import PDFContent, DocumentMetadata

logger = structlog.get_logger(__name__)

class PDFExtractorService:
    """Service for extracting comprehensive content from PDF files"""
    def __init__(self):
        self.logger = logger.bind(service="pdf_extractor")

    async def extract_content(self, file_path: Path) -> PDFContent:
        """Async wrapper that offloads sync PDF work to a thread."""
        try:
            return await anyio.to_thread.run_sync(self._extract_content_sync, file_path)
        except Exception as e:
            self.logger.error("PDF extraction failed", error=str(e))
            raise PDFProcessingError(f"Failed to extract PDF content: {str(e)}")

    # ---- sync implementation (runs in thread) ----
    def _extract_content_sync(self, file_path: Path) -> PDFContent:
        self.logger.info("Starting PDF content extraction", file_path=str(file_path))
        metadata = self._extract_metadata(file_path)
        text_content = self._extract_text(file_path)
        images = self._extract_images(file_path)
        tables = self._extract_tables(file_path)
        page_contents = self._extract_page_contents(file_path)

        pdf_content = PDFContent(
            text=text_content,
            images=images,
            tables=tables,
            metadata=metadata,
            page_contents=page_contents
        )
        self.logger.info("PDF extraction completed",
                         text_length=len(text_content),
                         image_count=len(images),
                         table_count=len(tables))
        return pdf_content

    def _extract_metadata(self, file_path: Path) -> DocumentMetadata:
        try:
            with open(file_path, 'rb') as f:
                pdf_reader = PyPDF2.PdfReader(f)
                meta = pdf_reader.metadata or {}
                return DocumentMetadata(
                    filename=file_path.name,
                    file_size=file_path.stat().st_size,
                    page_count=len(pdf_reader.pages),
                    author=meta.get('/Author'),
                    title=meta.get('/Title'),
                    subject=meta.get('/Subject')
                )
        except Exception as e:
            self.logger.warning("Metadata extraction failed", error=str(e))
            return DocumentMetadata(
                filename=file_path.name,
                file_size=file_path.stat().st_size,
                page_count=0
            )

    def _extract_text(self, file_path: Path) -> str:
        chunks = []
        with pdfplumber.open(file_path) as pdf:
            for i, page in enumerate(pdf.pages, start=1):
                try:
                    t = page.extract_text() or ""
                    if t:
                        chunks.append(f"[Page {i}]\n{t}")
                except Exception as e:
                    self.logger.warning("Failed to extract text", page=i, error=str(e))
        return "\n\n".join(chunks)

    def _extract_images(self, file_path: Path) -> List[Dict[str, Any]]:
        images: List[Dict[str, Any]] = []
        try:
            with pdfplumber.open(file_path) as pdf:
                for i, page in enumerate(pdf.pages, start=1):
                    for idx, img in enumerate(getattr(page, 'images', [])):
                        try:
                            images.append({
                                "page": i,
                                "index": idx,
                                "bbox": [img.get('x0',0), img.get('top',0), img.get('x1',0), img.get('bottom',0)],
                                "width": img.get('width',0),
                                "height": img.get('height',0),
                            })
                        except Exception as e:
                            self.logger.warning("Image extraction failed", error=str(e))
        except Exception as e:
            self.logger.warning("Image extraction failed", error=str(e))
        return images

    def _extract_tables(self, file_path: Path) -> List[Dict[str, Any]]:
        tables: List[Dict[str, Any]] = []
        try:
            with pdfplumber.open(file_path) as pdf:
                for i, page in enumerate(pdf.pages, start=1):
                    try:
                        tbs = page.extract_tables() or []
                        for idx, tb in enumerate(tbs):
                            tables.append({
                                "page": i,
                                "index": idx,
                                "data": tb,
                                "rows": len(tb),
                                "columns": len(tb[0]) if tb else 0
                            })
                    except Exception as e:
                        self.logger.warning("Table extraction failed", error=str(e))
        except Exception as e:
            self.logger.warning("Table extraction failed", error=str(e))
        return tables

    def _extract_page_contents(self, file_path: Path) -> List[Dict[str, Any]]:
        out: List[Dict[str, Any]] = []
        try:
            with pdfplumber.open(file_path) as pdf:
                for i, page in enumerate(pdf.pages, start=1):
                    try:
                        out.append({
                            "page_number": i,
                            "text": page.extract_text() or "",
                            "width": page.width,
                            "height": page.height,
                            "bbox": page.bbox
                        })
                    except Exception as e:
                        self.logger.warning("Page content extraction failed", error=str(e))
        except Exception as e:
            self.logger.warning("Page content extraction failed", error=str(e))
        return out

import spacy
from sentence_transformers import SentenceTransformer
import nltk
from typing import List
import structlog

from app.core.exceptions import NLPProcessingError
from app.models.entities import Entity, Relationship, EntityType, RelationType
from app.core.config import settings

logger = structlog.get_logger(__name__)

class NLPProcessorService:
    """Service for NLP processing and entity extraction"""
    def __init__(self):
        self.logger = logger.bind(service="nlp_processor")
        self._load_models()

    def _load_models(self):
        try:
            self.nlp = spacy.load(settings.spacy_model)
            self.sentence_transformer = SentenceTransformer(settings.sentence_transformer_model)
            try:
                nltk.data.find('tokenizers/punkt')
            except LookupError:
                nltk.download('punkt')
            self.logger.info("NLP models loaded successfully")
        except Exception as e:
            self.logger.error("Failed to load NLP models", error=str(e))
            raise NLPProcessingError(f"Failed to load NLP models: {str(e)}")

    async def extract_entities(self, text: str) -> List[Entity]:
        try:
            doc = self.nlp(text or "")
            entities: List[Entity] = []
            for ent in doc.ents:
                et = self._map_entity_type(ent.label_)
                if et:
                    entities.append(Entity(
                        text=ent.text.strip(),
                        label=ent.label_,
                        start_char=ent.start_char,
                        end_char=ent.end_char,
                        confidence=1.0,
                        entity_type=et,
                        metadata={"source": "spacy"}
                    ))
            return self._remove_overlapping_entities(entities)
        except Exception as e:
            self.logger.error("Entity extraction failed", error=str(e))
            raise NLPProcessingError(f"Entity extraction failed: {str(e)}")

    async def extract_relationships(self, text: str, entities: List[Entity]) -> List[Relationship]:
        try:
            rels: List[Relationship] = []
            sentences = nltk.sent_tokenize(text or "")
            for sent in sentences:
                present = [e for e in entities if e.text.lower() in (sent or "").lower()]
                for i, e1 in enumerate(present):
                    for e2 in present[i+1:]:
                        rels.append(Relationship(
                            source_entity=e1.text,
                            target_entity=e2.text,
                            relation_type=RelationType.MENTIONS,
                            confidence=0.5,
                            context=sent,
                            metadata={"extraction_method": "cooccurrence"}
                        ))
            return self._dedup(rels)
        except Exception as e:
            self.logger.error("Relationship extraction failed", error=str(e))
            raise NLPProcessingError(f"Relationship extraction failed: {str(e)}")

    async def generate_embeddings(self, texts: List[str]) -> List[List[float]]:
        try:
            embs = self.sentence_transformer.encode(texts, convert_to_tensor=False)
            return embs.tolist()
        except Exception as e:
            self.logger.error("Embedding generation failed", error=str(e))
            raise NLPProcessingError(f"Embedding generation failed: {str(e)}")

    def _map_entity_type(self, lbl: str):
        m = {
            'PERSON': EntityType.PERSON, 'ORG': EntityType.ORGANIZATION,
            'GPE': EntityType.LOCATION, 'LOC': EntityType.LOCATION,
            'DATE': EntityType.DATE, 'TIME': EntityType.DATE,
            'MONEY': EntityType.MONEY, 'QUANTITY': EntityType.CONCEPT,
            'ORDINAL': EntityType.CONCEPT, 'CARDINAL': EntityType.CONCEPT,
            'EVENT': EntityType.CONCEPT, 'PRODUCT': EntityType.CONCEPT,
            'WORK_OF_ART': EntityType.CONCEPT, 'LAW': EntityType.CONCEPT,
            'LANGUAGE': EntityType.CONCEPT, 'NORP': EntityType.CONCEPT,
            'FAC': EntityType.LOCATION
        }
        return m.get(lbl)

    def _remove_overlapping_entities(self, es: List[Entity]) -> List[Entity]:
        es = sorted(es, key=lambda x: (x.start_char, -(x.end_char - x.start_char)))
        out = []
        for e in es:
            if not any((e.start_char < ex.end_char and e.end_char > ex.start_char) for ex in out):
                out.append(e)
        return out

    def _dedup(self, rels: List[Relationship]) -> List[Relationship]:
        seen, out = set(), []
        for r in rels:
            k = (r.source_entity.lower(), r.target_entity.lower(), r.relation_type)
            if k not in seen:
                seen.add(k); out.append(r)
        return out

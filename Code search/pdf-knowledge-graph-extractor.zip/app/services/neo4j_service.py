from neo4j import GraphDatabase
from typing import List, Dict, Any, Optional
import structlog

from app.core.config import settings
from app.core.exceptions import Neo4jConnectionError
from app.models.entities import Entity, Relationship, PDFContent
from app.models.graph_models import GraphNode, GraphRelationship, GraphResponse

logger = structlog.get_logger(__name__)

class Neo4jService:
    """Service for Neo4j database operations"""
    def __init__(self):
        self.logger = logger.bind(service="neo4j")
        self.driver = None
        self._connect()
        self._ensure_constraints()

    def _connect(self):
        try:
            self.driver = GraphDatabase.driver(
                settings.neo4j_uri,
                auth=(settings.neo4j_user, settings.neo4j_password)
            )
            with self.driver.session(database=settings.neo4j_database) as session:
                session.run("RETURN 1").consume()
            self.logger.info("Connected to Neo4j successfully")
        except Exception as e:
            self.logger.error("Failed to connect to Neo4j", error=str(e))
            raise Neo4jConnectionError(f"Failed to connect to Neo4j: {str(e)}")

    def _ensure_constraints(self):
        stmts = [
            "CREATE CONSTRAINT doc_id IF NOT EXISTS FOR (d:Document) REQUIRE d.id IS UNIQUE",
            "CREATE CONSTRAINT entity_key IF NOT EXISTS FOR (e:Entity) REQUIRE e.key IS UNIQUE"
        ]
        with self.driver.session(database=settings.neo4j_database) as s:
            for c in stmts:
                s.run(c).consume()

    async def create_document_node(self, document_id: str, content: PDFContent) -> str:
        try:
            with self.driver.session(database=settings.neo4j_database) as session:
                rec = session.run("""                    MERGE (d:Document {id: $document_id})
                    ON CREATE SET d.created_at = datetime()
                    SET d.filename=$filename, d.file_size=$file_size, d.page_count=$page_count,
                        d.author=$author, d.title=$title, d.subject=$subject,
                        d.text_length=$text_length, d.image_count=$image_count, d.table_count=$table_count
                    RETURN d.id as id
                """, {
                    "document_id": document_id,
                    "filename": content.metadata.filename,
                    "file_size": content.metadata.file_size,
                    "page_count": content.metadata.page_count,
                    "author": content.metadata.author,
                    "title": content.metadata.title,
                    "subject": content.metadata.subject,
                    "text_length": len(content.text),
                    "image_count": len(content.images),
                    "table_count": len(content.tables)
                }).single()
                self.logger.info("Document node upserted", document_id=document_id)
                return rec["id"]
        except Exception as e:
            self.logger.error("Failed to create document node", error=str(e))
            raise Neo4jConnectionError(f"Failed to create document node: {str(e)}")

    async def create_entity_nodes(self, document_id: str, entities: List[Entity]) -> None:
        try:
            with self.driver.session(database=settings.neo4j_database) as session:
                for e in entities:
                    session.run("""                        WITH toLower($text) AS v, $type AS t
                        MERGE (ent:Entity {key: t + '|' + v})
                        SET ent.text=$text, ent.type=t, ent.label=$label, ent.confidence=$confidence, ent.metadata=$metadata
                        WITH ent
                        MATCH (d:Document {id: $document_id})
                        MERGE (d)-[:CONTAINS_ENTITY]->(ent)
                    """, {
                        "text": e.text, "type": e.entity_type.value, "label": e.label,
                        "confidence": e.confidence, "metadata": e.metadata, "document_id": document_id
                    }).consume()
            self.logger.info("Entity nodes upserted", count=len(entities))
        except Exception as e:
            self.logger.error("Failed to create entity nodes", error=str(e))
            raise Neo4jConnectionError(f"Failed to create entity nodes: {str(e)}")

    async def create_relationships(self, document_id: str, relationships: List[Relationship]) -> None:
        try:
            with self.driver.session(database=settings.neo4j_database) as session:
                for r in relationships:
                    session.run("""                        MATCH (e1:Entity) WHERE toLower(e1.text) = toLower($t1)
                        MATCH (e2:Entity) WHERE toLower(e2.text) = toLower($t2)
                        MERGE (e1)-[rel:RELATIONSHIP {type: $rel_type}]->(e2)
                        SET rel.confidence=$confidence, rel.context=$context, rel.metadata=$metadata
                    """, {
                        "t1": r.source_entity, "t2": r.target_entity,
                        "rel_type": r.relation_type.value, "confidence": r.confidence,
                        "context": r.context, "metadata": r.metadata
                    }).consume()
            self.logger.info("Relationships created", count=len(relationships))
        except Exception as e:
            self.logger.warning("Some relationships could not be created", error=str(e))

    async def query_graph(self, query: str, parameters: Optional[Dict[str, Any]] = None) -> GraphResponse:
        try:
            with self.driver.session(database=settings.neo4j_database) as session:
                result = list(session.run(query, parameters or {}))
            nodes, rels = {}, {}
            for rec in result:
                for v in rec.values():
                    cname = v.__class__.__name__
                    if cname == "Node":
                        nodes[str(v.id)] = {
                            "id": str(v.id),
                            "labels": list(v.labels),
                            "properties": dict(v.items())
                        }
                    elif cname == "Relationship":
                        rels[str(v.id)] = {
                            "id": str(v.id),
                            "type": v.type,
                            "start_node": str(v.start_node.id),
                            "end_node": str(v.end_node.id),
                            "properties": dict(v.items())
                        }
            return GraphResponse(
                nodes=[GraphNode(**n) for n in nodes.values()],
                relationships=[GraphRelationship(**r) for r in rels.values()],
                metadata={"count_records": len(result), "query": query, "parameters": parameters or {}}
            )
        except Exception as e:
            self.logger.error("Graph query failed", error=str(e))
            raise Neo4jConnectionError(f"Graph query failed: {str(e)}")

    async def get_document_graph(self, document_id: str) -> GraphResponse:
        q = """        MATCH (d:Document {id: $document_id})-[:CONTAINS_ENTITY]->(e:Entity)
        OPTIONAL MATCH (e)-[r:RELATIONSHIP]->(e2:Entity)
        RETURN d, e, r, e2
        """
        return await self.query_graph(q, {"document_id": document_id})

    def close(self):
        if self.driver:
            self.driver.close()
            self.driver = None
            self.logger.info("Neo4j connection closed")

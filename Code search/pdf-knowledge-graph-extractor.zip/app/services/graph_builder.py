import structlog
import uuid, time
from pathlib import Path

from app.models.entities import ProcessingResult, PDFContent
from app.services.pdf_extractor import PDFExtractorService
from app.services.nlp_processor import NLPProcessorService
from app.services.neo4j_service import Neo4jService

logger = structlog.get_logger(__name__)

class GraphBuilderService:
    """Service for building knowledge graphs from PDF content"""
    def __init__(self):
        self.logger = logger.bind(service="graph_builder")
        self.pdf_extractor = PDFExtractorService()
        self.nlp_processor = NLPProcessorService()
        self.neo4j_service = Neo4jService()

    async def process_pdf_to_graph(self, file_path: str) -> ProcessingResult:
        start = time.time()
        document_id = str(uuid.uuid4())
        try:
            self.logger.info("Starting PDF to graph", document_id=document_id, file_path=file_path)
            content: PDFContent = await self.pdf_extractor.extract_content(Path(file_path))
            entities = await self.nlp_processor.extract_entities(content.text or "")
            relationships = await self.nlp_processor.extract_relationships(content.text or "", entities)

            await self.neo4j_service.create_document_node(document_id, content)
            await self.neo4j_service.create_entity_nodes(document_id, entities)
            await self.neo4j_service.create_relationships(document_id, relationships)

            return ProcessingResult(
                document_id=document_id,
                entities=entities,
                relationships=relationships,
                content=content,
                processing_time=time.time() - start,
                status="completed"
            )
        except Exception as e:
            self.logger.error("Pipeline failed", error=str(e), document_id=document_id)
            return ProcessingResult(
                document_id=document_id,
                entities=[], relationships=[],
                content=PDFContent(text="", images=[], tables=[], metadata=None, page_contents=[]),
                processing_time=time.time() - start,
                status="failed", error_message=str(e)
            )

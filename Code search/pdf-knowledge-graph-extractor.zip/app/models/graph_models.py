from pydantic import BaseModel
from typing import Dict, Any, Optional, List

class GraphNode(BaseModel):
    id: str
    labels: List[str]
    properties: Dict[str, Any]

class GraphRelationship(BaseModel):
    id: str
    type: str
    start_node: str
    end_node: str
    properties: Dict[str, Any]

class GraphQuery(BaseModel):
    query: str
    parameters: Optional[Dict[str, Any]] = {}

class GraphResponse(BaseModel):
    nodes: List[GraphNode]
    relationships: List[GraphRelationship]
    metadata: Dict[str, Any]

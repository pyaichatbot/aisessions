import aiofiles
from pathlib import Path
import structlog

from app.core.config import settings
from app.core.exceptions import ValidationError

logger = structlog.get_logger(__name__)

class FileHandler:
    """Handle file operations and validation"""
    def __init__(self):
        self.logger = logger.bind(service="file_handler")
        self.upload_dir = Path(settings.upload_dir)
        self.upload_dir.mkdir(parents=True, exist_ok=True)

    async def save_uploaded_file(self, file_content: bytes, filename: str) -> Path:
        self._validate_file(file_content, filename)
        file_path = self._unique_path(filename)
        async with aiofiles.open(file_path, 'wb') as f:
            await f.write(file_content)
        self.logger.info("File saved successfully", file_path=str(file_path))
        return file_path

    def _validate_file(self, file_content: bytes, filename: str) -> None:
        if len(file_content) > settings.max_file_size:
            raise ValidationError(f"File size exceeds {settings.max_file_size} bytes")
        if not filename.lower().endswith('.pdf'):
            raise ValidationError("Only PDF files are allowed")
        if not file_content.startswith(b'%PDF-'):
            raise ValidationError("Invalid PDF file format")

    def _unique_path(self, filename: str) -> Path:
        path = self.upload_dir / filename
        base = path
        i = 1
        while path.exists():
            path = self.upload_dir / f"{base.stem}_{i}{base.suffix}"
            i += 1
        return path

    async def cleanup_file(self, file_path: Path) -> None:
        try:
            if file_path.exists():
                file_path.unlink()
                self.logger.info("File cleaned up", file_path=str(file_path))
        except Exception as e:
            self.logger.warning("Failed to cleanup file", file_path=str(file_path), error=str(e))

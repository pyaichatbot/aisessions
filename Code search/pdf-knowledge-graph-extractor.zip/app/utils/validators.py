from typing import Any, Dict, Optional
from pydantic import BaseModel, validator
import re

class PDFUploadValidator(BaseModel):
    filename: str
    content_type: Optional[str] = None

    @validator('filename')
    def validate_filename(cls, v):
        if not v:
            raise ValueError("Filename is required")
        if not v.lower().endswith('.pdf'):
            raise ValueError("Only PDF files are allowed")
        if not re.match(r'^[a-zA-Z0-9._-]+$', v):
            raise ValueError("Filename contains invalid characters")
        return v

    @validator('content_type')
    def validate_content_type(cls, v):
        if v and v != 'application/pdf':
            raise ValueError("Invalid content type for PDF file")
        return v

class GraphQueryValidator(BaseModel):
    query: str
    parameters: Optional[Dict[str, Any]] = {}

    @validator('query')
    def validate_query(cls, v):
        if not v or not v.strip():
            raise ValueError("Query cannot be empty")
        up = v.strip().upper()
        allowed_prefixes = ("MATCH", "WITH", "RETURN", "CALL DB.", "CALL APOC.META.")
        if not up.startswith(allowed_prefixes):
            raise ValueError("Only read-only queries are allowed")
        for kw in ("DELETE", "DETACH", "REMOVE", "DROP", "CREATE ", "SET "):
            if kw in up:
                raise ValueError(f"Query contains disallowed keyword: {kw.strip()}")
        return v.strip()

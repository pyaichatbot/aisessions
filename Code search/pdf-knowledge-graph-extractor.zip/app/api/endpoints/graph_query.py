from fastapi import APIRouter, HTTPException, Depends
import structlog
from app.services.neo4j_service import Neo4jService
from app.models.graph_models import GraphQuery, GraphResponse
from app.utils.validators import GraphQueryValidator
from app.api.dependencies import get_neo4j_service
from app.core.exceptions import Neo4jConnectionError

logger = structlog.get_logger(__name__)

router = APIRouter(prefix="/graph", tags=["Graph Queries"])

@router.post("/query", response_model=GraphResponse)
async def execute_graph_query(
    query_data: GraphQuery,
    neo4j_service: Neo4jService = Depends(get_neo4j_service)
):
    try:
        validator = GraphQueryValidator(query=query_data.query, parameters=query_data.parameters or {})
        return await neo4j_service.query_graph(validator.query, validator.parameters)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=f"Query validation failed: {e}")
    except Neo4jConnectionError as e:
        raise HTTPException(status_code=500, detail=f"Graph query failed: {e}")
    except Exception:
        raise HTTPException(status_code=500, detail="Unexpected error during query execution")

@router.get("/document/{document_id}", response_model=GraphResponse)
async def get_document_graph(document_id: str, neo4j_service: Neo4jService = Depends(get_neo4j_service)):
    try:
        return await neo4j_service.get_document_graph(document_id)
    except Exception:
        raise HTTPException(status_code=500, detail="Failed to get document graph")

@router.get("/stats")
async def get_graph_stats(neo4j_service: Neo4jService = Depends(get_neo4j_service)):
    q = "CALL db.labels() YIELD label RETURN collect(label) as labels"
    res = await neo4j_service.query_graph(q)
    return {"meta": res.metadata}

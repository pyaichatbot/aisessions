from fastapi import APIRouter, UploadFile, File, HTTPException, Depends, status
import structlog
from app.services.graph_builder import GraphBuilderService
from app.utils.file_handler import FileHandler
from app.utils.validators import PDFUploadValidator
from app.models.entities import ProcessingResult
from app.api.dependencies import get_graph_builder, get_file_handler
from app.core.exceptions import PDFProcessingError, ValidationError

logger = structlog.get_logger(__name__)

router = APIRouter(prefix="/pdf", tags=["PDF Processing"])

@router.post("/process", response_model=ProcessingResult)
async def process_pdf(
    file: UploadFile = File(...),
    graph_builder: GraphBuilderService = Depends(get_graph_builder),
    file_handler: FileHandler = Depends(get_file_handler)
):
    try:
        PDFUploadValidator(filename=file.filename, content_type=file.content_type)
        content = await file.read()
        path = await file_handler.save_uploaded_file(content, file.filename)
        try:
            result = await graph_builder.process_pdf_to_graph(str(path))
            return result
        finally:
            await file_handler.cleanup_file(path)
    except ValidationError as e:
        logger.error("PDF validation failed", error=str(e))
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=f"File validation failed: {e}")
    except PDFProcessingError as e:
        logger.error("PDF processing failed", error=str(e))
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"PDF processing failed: {e}")
    except Exception as e:
        logger.error("Unexpected error during PDF processing", error=str(e))
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Unexpected error")

@router.get("/health")
async def health_check():
    return {"status": "healthy", "service": "PDF Processing"}

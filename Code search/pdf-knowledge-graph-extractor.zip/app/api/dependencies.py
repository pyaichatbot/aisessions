import structlog
from app.services.graph_builder import GraphBuilderService
from app.services.neo4j_service import Neo4jService
from app.utils.file_handler import FileHandler

logger = structlog.get_logger(__name__)

_graph_builder = None
_neo4j_service = None
_file_handler = None

def get_graph_builder() -> GraphBuilderService:
    global _graph_builder
    if _graph_builder is None:
        _graph_builder = GraphBuilderService()
    return _graph_builder

def get_neo4j_service() -> Neo4jService:
    global _neo4j_service
    if _neo4j_service is None:
        _neo4j_service = Neo4jService()
    return _neo4j_service

def get_file_handler() -> FileHandler:
    global _file_handler
    if _file_handler is None:
        _file_handler = FileHandler()
    return _file_handler

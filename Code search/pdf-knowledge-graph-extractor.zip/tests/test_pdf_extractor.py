import pytest
from pathlib import Path
from app.services.pdf_extractor import PDFExtractorService
from app.core.exceptions import PDFProcessingError

@pytest.mark.asyncio
async def test_extract_content_invalid_file():
    svc = PDFExtractorService()
    with pytest.raises(PDFProcessingError):
        await svc.extract_content(Path("/nonexistent/file.pdf"))

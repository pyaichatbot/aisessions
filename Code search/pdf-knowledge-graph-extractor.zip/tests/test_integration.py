import pytest
from unittest.mock import Mock, patch
from app.services.graph_builder import GraphBuilderService
from app.models.entities import ProcessingResult

@pytest.mark.asyncio
@patch('app.services.neo4j_service.Neo4jService')
async def test_pipeline_initializes(mock_neo4j):
    mock_neo4j_instance = Mock()
    mock_neo4j_instance.create_document_node = Mock()
    mock_neo4j_instance.create_entity_nodes = Mock()
    mock_neo4j_instance.create_relationships = Mock()
    mock_neo4j.return_value = mock_neo4j_instance

    svc = GraphBuilderService()
    assert isinstance(svc, GraphBuilderService)

# PDF Knowledge Graph Extractor

Enterprise-grade solution for extracting comprehensive knowledge graphs from PDF documents using Neo4j.

## Quick Start (Docker Compose)
```bash
cd docker
docker compose up -d --build
```
- API: http://localhost:8000/docs
- Neo4j Browser: http://localhost:7474 (neo4j/password)

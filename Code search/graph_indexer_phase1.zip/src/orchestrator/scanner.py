
import os
from typing import Iterator, Tuple

EXT_TO_LANG = {
    ".cs": "csharp",
    ".py": "python",
    ".ts": "typescript",
    ".js": "javascript",
    ".java": "java",
    ".php": "php",
    ".sql": "sql"
}

def iter_files(repo_root: str) -> Iterator[Tuple[str,str]]:
    for root, _, files in os.walk(repo_root):
        for f in files:
            ext = os.path.splitext(f)[1].lower()
            if ext in EXT_TO_LANG:
                full = os.path.join(root, f)
                rel = os.path.relpath(full, repo_root)
                yield rel, EXT_TO_LANG[ext]


import os, asyncio
from .models import AnalyzeRequest
from .clients.base import BaseAnalyzerClient
from .storage.neo4j_store import Neo4jStore
from ..config import settings

class Dispatcher:
    def __init__(self, store: Neo4jStore):
        self.client = BaseAnalyzerClient(settings.analyzer_base_url)
        self.store = store

    async def process_file(self, project_id: str, repo_root: str, rel_path: str, language: str):
        full = os.path.join(repo_root, rel_path)
        with open(full, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read()

        req = AnalyzeRequest(language=language, projectId=project_id, filePath=rel_path, content=content)
        resp = await self.client.analyze(req)
        self.store.delete_file_emissions(resp.file.id)
        self.store.ingest_file(project_id, resp)

    async def run_repo(self, repo_root: str, project_id: str):
        sem = asyncio.Semaphore(settings.max_in_flight)
        from .scanner import iter_files
        tasks = []
        for rel_path, lang in iter_files(repo_root):
            async def bound(rel=rel_path, l=lang):
                async with sem:
                    await self.process_file(project_id, repo_root, rel, l)
            tasks.append(asyncio.create_task(bound()))
        await asyncio.gather(*tasks)

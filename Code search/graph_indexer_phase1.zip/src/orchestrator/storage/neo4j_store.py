
from neo4j import GraphDatabase
from ..models import AnalyzeResponse

class Neo4jStore:
    def __init__(self, uri: str, user: str, password: str):
        self.driver = GraphDatabase.driver(uri, auth=(user, password))

    def close(self):
        self.driver.close()

    def setup_constraints(self):
        cyphers = [
            "CREATE CONSTRAINT IF NOT EXISTS FOR (p:Project) REQUIRE p.id IS UNIQUE",
            "CREATE CONSTRAINT IF NOT EXISTS FOR (f:File) REQUIRE f.id IS UNIQUE",
            "CREATE CONSTRAINT IF NOT EXISTS FOR (s:Symbol) REQUIRE s.symbolKey IS UNIQUE"
        ]
        with self.driver.session() as sess:
            for c in cyphers:
                sess.run(c)

    def upsert_project(self, project_id: str, name: str):
        with self.driver.session() as sess:
            sess.run("MERGE (p:Project {id: $id}) SET p.name = $name",
                     id=project_id, name=name)

    def delete_file_emissions(self, file_id: str):
        with self.driver.session() as sess:
            sess.run("MATCH (f:File {id: $fid})-[r:EMITTED]->() DETACH DELETE r", fid=file_id)

    def ingest_file(self, project_id: str, resp: AnalyzeResponse):
        with self.driver.session() as sess:
            sess.run("""
                MERGE (p:Project {id: $pid})
                MERGE (f:File {id: $fid})
                SET f.path = $path, f.hash = $hash
                MERGE (p)-[:HAS_FILE]->(f)
            """, pid=project_id, fid=resp.file.id, path=resp.file.path, hash=resp.file.hash)

            for sym in resp.symbols + resp.externals:
                sess.run("""
                    MERGE (s:Symbol {symbolKey: $key})
                    ON CREATE SET s.display=$display, s.kind=$kind, s.language=$lang
                    ON MATCH SET s.display=coalesce(s.display,$display)
                """, key=sym.symbolKey, display=sym.display, kind=sym.kind, lang=sym.language or "")

            for sym in resp.symbols:
                sess.run("""
                    MATCH (f:File {id: $fid}), (s:Symbol {symbolKey:$key})
                    MERGE (f)-[:CONTAINS]->(s)
                    MERGE (f)-[:EMITTED]->(s)
                """, fid=resp.file.id, key=sym.symbolKey)

            for e in resp.edges:
                sess.run(f"""
                    MATCH (a:Symbol {{symbolKey:$from}}), (b:Symbol {{symbolKey:$to}})
                    MERGE (a)-[r:{e.type}]->(b)
                    ON CREATE SET r.data=$data
                """, from=e.from_, to=e.to, data=e.data)


import httpx
from tenacity import retry, stop_after_attempt, wait_exponential_jitter
from ..models import AnalyzeRequest, AnalyzeResponse

class AnalyzerError(Exception):
    pass

class BaseAnalyzerClient:
    def __init__(self, base_url: str, timeout: float = 20.0):
        self.base_url = base_url.rstrip('/')
        self.timeout = timeout

    @retry(stop=stop_after_attempt(3), wait=wait_exponential_jitter(initial=0.5, max=3))
    async def analyze(self, req: AnalyzeRequest) -> AnalyzeResponse:
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            r = await client.post(f"{self.base_url}/analyze", json=req.model_dump())
            if r.status_code != 200:
                raise AnalyzerError(f"HTTP {r.status_code}: {r.text}")
            return AnalyzeResponse.model_validate(r.json())

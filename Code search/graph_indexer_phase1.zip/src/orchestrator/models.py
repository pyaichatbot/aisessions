
from pydantic import BaseModel, Field
from typing import List, Optional, Dict

class Span(BaseModel):
    s: int
    l: int

class FileDescriptor(BaseModel):
    id: str
    path: str
    hash: str

class Symbol(BaseModel):
    symbolKey: str
    display: str
    kind: str
    containerKey: Optional[str] = None
    language: Optional[str] = None
    data: Optional[Dict] = None

class Edge(BaseModel):
    from_: str = Field(alias="from")
    to: str
    type: str
    span: Optional[Span] = None
    data: Optional[Dict] = None
    model_config = {"populate_by_name": True}

class AnalyzeRequest(BaseModel):
    language: str
    projectId: str
    filePath: str
    content: str

class AnalyzeResponse(BaseModel):
    file: FileDescriptor
    symbols: List[Symbol] = Field(default_factory=list)
    edges: List[Edge] = Field(default_factory=list)
    externals: List[Symbol] = Field(default_factory=list)

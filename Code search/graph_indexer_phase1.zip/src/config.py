
from pydantic_settings import BaseSettings
from pydantic import Field
from typing import List

class Settings(BaseSettings):
    repo_paths: List[str] = Field(default_factory=lambda: ["src/sample_repo"], alias="REPO_PATHS")
    analyzer_base_url: str = Field(default="http://mock-analyzers:8081", alias="ANALYZER_BASE_URL")
    project_name: str = Field(default="DemoProject", alias="PROJECT_NAME")
    project_id: str = Field(default="11111111-1111-1111-1111-111111111111", alias="PROJECT_ID")
    max_in_flight: int = Field(default=8, alias="MAX_IN_FLIGHT")

    neo4j_uri: str = Field(default="bolt://neo4j:7687", alias="NEO4J_URI")
    neo4j_user: str = Field(default="neo4j", alias="NEO4J_USER")
    neo4j_password: str = Field(default="pleasechangeme", alias="NEO4J_PASSWORD")

    class Config:
        env_file = ".env"
        case_sensitive = False

settings = Settings()


import asyncio, typer, os
from .config import settings
from .orchestrator.storage.neo4j_store import Neo4jStore
from .orchestrator.dispatcher import Dispatcher

app = typer.Typer()

@app.command()
def run(repo: str = typer.Option(None, help="Repo path")):
    repo_paths = [repo] if repo else settings.repo_paths
    store = Neo4jStore(settings.neo4j_uri, settings.neo4j_user, settings.neo4j_password)
    store.setup_constraints()
    store.upsert_project(settings.project_id, settings.project_name)
    disp = Dispatcher(store)

    async def _run():
        for r in repo_paths:
            r = os.path.abspath(r)
            typer.echo(f"Indexing repo: {r}")
            await disp.run_repo(r, settings.project_id)

    asyncio.run(_run())
    store.close()

if __name__ == "__main__":
    app()

from kgx_service.extractors.python_extractor import PythonExtractor

def test_py_extract_basic():
    code = "import os\nclass A: pass\n"
    g = PythonExtractor().extract(code, path="x.py")
    d = g.to_dict()
    kinds = {n["kind"] for n in d["nodes"]}
    assert "Module" in kinds
    assert "Class" in kinds
    assert any(e["kind"] == "CONTAINS" for e in d["edges"])

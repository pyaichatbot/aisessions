from kgx_service.core.graph import Graph

def test_stable_ids():
    g1, g2 = Graph(), Graph()
    n1 = g1.add_node("X", a=1)
    n2 = g2.add_node("X", a=1)
    assert n1.id == n2.id

from neo4j import GraphDatabase
from typing import Dict, Any

class Neo4jWriter:
    def __init__(self, uri: str, user: str, password: str, database: str | None = None):
        self._driver = GraphDatabase.driver(uri, auth=(user, password))
        self._db = database

    def close(self):
        self._driver.close()

    def upsert(self, graph_dict: Dict[str, Any]):
        if not graph_dict.get("nodes"):
            return
        cypher_node = '''
        UNWIND $nodes AS n
        MERGE (x:Entity {id: n.id})
        SET x.kind = n.kind
        SET x += apoc.map.removeKeys(n, ['id','kind'])
        '''
        cypher_edge = '''
        UNWIND $edges AS e
        MATCH (s:Entity {id: e.src})
        MATCH (t:Entity {id: e.dst})
        MERGE (s)-[r:REL {kind: e.kind, src: e.src, dst: e.dst}]->(t)
        SET r += apoc.map.removeKeys(e, ['kind','src','dst'])
        '''
        with self._driver.session(database=self._db) as sess:
            sess.run(cypher_node, nodes=graph_dict.get("nodes", []))
            if graph_dict.get("edges"):
                sess.run(cypher_edge, edges=graph_dict["edges"])

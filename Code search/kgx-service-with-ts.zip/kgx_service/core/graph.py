from dataclasses import dataclass, field
from typing import Dict, List, Any
import hashlib, json

def _stable_id(kind: str, props: Dict[str, Any]) -> str:
    m = hashlib.sha1()
    m.update(kind.encode())
    m.update(json.dumps(props, sort_keys=True, default=str).encode())
    return m.hexdigest()

@dataclass
class Node:
    kind: str
    props: Dict[str, Any]
    id: str = field(init=False)
    def __post_init__(self):
        self.id = _stable_id(self.kind, self.props)

@dataclass
class Edge:
    kind: str
    src: str
    dst: str
    props: Dict[str, Any] = field(default_factory=dict)

class Graph:
    def __init__(self):
        self.nodes: Dict[str, Node] = {}
        self.edges: List[Edge] = []

    def add_node(self, kind: str, **props) -> Node:
        n = Node(kind, props)
        self.nodes.setdefault(n.id, n)
        return self.nodes[n.id]

    def add_edge(self, kind: str, src: Node, dst: Node, **props):
        self.edges.append(Edge(kind, src.id, dst.id, props))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "nodes": [dict(id=n.id, kind=n.kind, **n.props) for n in self.nodes.values()],
            "edges": [dict(kind=e.kind, src=e.src, dst=e.dst, **e.props) for e in self.edges],
        }

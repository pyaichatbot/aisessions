import javalang
from typing import Optional
from ..core.graph import Graph
from .base import BaseExtractor

class JavaExtractor(BaseExtractor):
    """Java extractor using javalang (classes, methods, imports, interfaces)."""
    def extract(self, content: str, path: Optional[str] = None) -> Graph:
        g = Graph()
        try:
            tree = javalang.parse.parse(content)
        except (javalang.parser.JavaSyntaxError, Exception) as e:
            g.add_node("CompilationUnitError", language="java", path=path or "<stdin>", error=str(e))
            return g

        mod = g.add_node("CompilationUnit", language="java", path=path or "<stdin>",
                         package=getattr(tree.package, "name", None))

        for i in getattr(tree, "imports", []) or []:
            imp = g.add_node("Import", language="java", name=i.path)
            g.add_edge("IMPORTS", mod, imp)

        for _, node in tree.filter(javalang.tree.ClassDeclaration):
            cls = g.add_node("Class", language="java", name=node.name,
                             extends=(node.extends.name if node.extends else None))
            g.add_edge("CONTAINS", mod, cls)
            for ext in (node.implementing or []):
                iface = g.add_node("InterfaceRef", language="java", name=ext.name)
                g.add_edge("IMPLEMENTS", cls, iface)
            for m in node.methods:
                fn = g.add_node("Method", language="java", name=m.name,
                                return_type=(getattr(m.return_type, "name", None)))
                g.add_edge("CONTAINS", cls, fn)
        return g

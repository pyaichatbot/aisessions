# Session 9 – Prefect Demo (RAG flow with retries + logging)

This demo wraps a simple RAG pipeline inside **Prefect 2.x** to show:
- Tasks & Flows
- Retries / timeouts
- Structured logging
- Parameterized runs

It can call the **RAG service** from your Session 8 stack (`RAG_SERVICE_URL`), or run in mock mode.

## Quick start (local)
```bash
python -m venv .venv && . .venv/Scripts/activate  # on Windows PowerShell: .venv\Scripts\Activate.ps1
pip install -r requirements.txt
prefect version
python flow.py  # runs once
```

## With Docker
```bash
docker build -t prefect-rag .
docker run --rm -e RAG_SERVICE_URL=http://host.docker.internal:8000 prefect-rag
```

import os,glob
ALLOWED_ROOT=os.path.abspath("./data")
def _safe(p): 
    f=os.path.abspath(p)
    if not f.startswith(ALLOWED_ROOT): raise ValueError("outside root")
    return f
def list_files(path="./data"): return glob.glob(os.path.join(_safe(path),"*"))[:100]
def read_file(path): 
    try:
        with open(_safe(path),"r",encoding="utf-8",errors="ignore") as f: return f.read(5000)
    except Exception as e: return str(e)

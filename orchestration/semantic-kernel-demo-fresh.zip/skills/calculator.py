def add(a:float,b:float)->float:
    return float(a)+float(b)

# Demo 1 — Semantic Kernel (Python)

A minimal **Semantic Kernel (SK)** agent with Python native skills:
- calculator.add(a,b)
- files.list(path), files.read(path) scoped to ./data
- Optional LLM routing via OpenAI if OPENAI_API_KEY set

Exposes a FastAPI service with POST /chat.

## Local
python -m venv .venv && . .venv/Scripts/activate
pip install -r requirements.txt
uvicorn app:app --reload --port 8080

## Docker Compose
docker compose up --build

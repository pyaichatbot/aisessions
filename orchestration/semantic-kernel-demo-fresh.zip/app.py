import os, re, glob
from fastapi import FastAPI
from pydantic import BaseModel
from skills.calculator import add
from skills.files import list_files, read_file

USE_LLM = bool(os.getenv("OPENAI_API_KEY"))

app = FastAPI()

class ChatIn(BaseModel):
    message: str

def heuristic_route(msg: str):
    low = msg.lower()
    if "add" in low or "+" in low:
        nums = [float(x) for x in re.findall(r"[-+]?[0-9]*\.?[0-9]+", low)]
        a, b = (nums+[0,0])[:2]
        return {"route":"calculator.add","args":{"a":a,"b":b}}
    if "list" in low and "file" in low:
        return {"route":"files.list","args":{"path":"./data"}}
    if "read" in low and "file" in low:
        return {"route":"files.read","args":{"path":"./data/OnboardingPolicy.md"}}
    return {"route":"none","args":{}}

def llm_route(msg: str):
    from openai import OpenAI
    client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
    system = "Route to calculator.add, files.list, files.read with args JSON only"
    resp = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role":"system","content":system},{"role":"user","content":msg}],
        response_format={"type":"json_object"},temperature=0,max_tokens=200
    )
    import json
    try:
        return json.loads(resp.choices[0].message.content)
    except Exception:
        return heuristic_route(msg)

@app.post("/chat")
def chat(payload: ChatIn):
    route = llm_route(payload.message) if USE_LLM else heuristic_route(payload.message)
    r, args = route.get("route"), route.get("args",{})
    if r=="calculator.add": out={"result":add(args.get("a",0),args.get("b",0))}
    elif r=="files.list": out={"files":list_files(args.get("path","./data"))}
    elif r=="files.read": out={"content":read_file(args.get("path","./data/OnboardingPolicy.md"))[:500]}
    else: out={"message":"No matching tool"}
    return {"route":route,"answer":out}

@app.get("/health")
def health():
    return {"status":"ok","files":len(glob.glob("./data/*"))}

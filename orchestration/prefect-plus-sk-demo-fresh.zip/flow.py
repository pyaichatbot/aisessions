import os,json,re,glob,time
from prefect import flow,task,get_run_logger

USE_LLM=bool(os.getenv("OPENAI_API_KEY"))

def heuristic_route(msg:str):
    low=msg.lower()
    if "add" in low or "+" in low:
        nums=[float(x) for x in re.findall(r"[-+]?[0-9]*\.?[0-9]+",low)]
        a,b=(nums+[0,0])[:2]
        return {"route":"calculator.add","args":{"a":a,"b":b}}
    if "list" in low: return {"route":"files.list","args":{"path":"./data"}}
    if "read" in low: return {"route":"files.read","args":{"path":"./data/OnboardingPolicy.md"}}
    return {"route":"none","args":{}}

def llm_route(msg:str):
    from openai import OpenAI
    client=OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
    system="Route to calculator.add, files.list, files.read with args JSON only"
    resp=client.chat.completions.create(model="gpt-4o-mini",
        messages=[{"role":"system","content":system},{"role":"user","content":msg}],
        response_format={"type":"json_object"},temperature=0,max_tokens=200)
    import json as _j
    try: return _j.loads(resp.choices[0].message.content)
    except Exception: return heuristic_route(msg)

def tool_add(a,b): return a+b
def tool_list(path): return glob.glob(os.path.join(path,"*"))[:50]
def tool_read(path): 
    try: return open(path,"r",encoding="utf-8",errors="ignore").read(1000)
    except Exception as e: return str(e)

@task
def ingest(q): return {"question":q}
@task
def route_with_sk(q): return llm_route(q) if USE_LLM else heuristic_route(q)
@task
def run_tool(route):
    r=route.get("route")
    args=route.get("args",{})
    if r=="calculator.add": return {"result":tool_add(args.get("a",0),args.get("b",0))}
    if r=="files.list": return {"files":tool_list(args.get("path","./data"))}
    if r=="files.read": return {"content":tool_read(args.get("path","./data/OnboardingPolicy.md"))}
    return {"message":"no tool"}
@task
def synthesize(q,route,res): return f"Q:{q}\nRoute:{route}\nRes:{res}"

@flow
def main_flow(q="list files"):
    log=get_run_logger();t0=time.time()
    iq=ingest(q);route=route_with_sk(iq["question"]);res=run_tool(route);ans=synthesize(iq["question"],route,res)
    log.info(f"done in {time.time()-t0:.2f}s")
    print(json.dumps({"route":route,"res":res,"ans":ans},indent=2))

if __name__=="__main__":
    os.makedirs("data",exist_ok=True)
    if not os.path.exists("data/OnboardingPolicy.md"):
        open("data/OnboardingPolicy.md","w").write("Policy content")
    main_flow()

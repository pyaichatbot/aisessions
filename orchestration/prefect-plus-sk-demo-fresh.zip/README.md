# Demo 2 — Prefect + Semantic Kernel (Python)
Prefect orchestrates workflow steps. SK agent decides which tool to call.

Flow: ingest -> route_with_SK -> run_tool -> synthesize

## Local
python -m venv .venv && . .venv/Scripts/activate
pip install -r requirements.txt
python flow.py

## Docker
docker compose up --build

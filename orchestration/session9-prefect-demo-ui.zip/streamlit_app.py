import os, time
import streamlit as st
from flow import rag_flow

st.set_page_config(page_title="Prefect RAG Flow", layout="wide")
st.title("Prefect RAG Flow (Session 9)")

with st.sidebar:
    st.header("Settings")
    rag_url = os.getenv("RAG_SERVICE_URL", "http://localhost:8000")
    st.write(f"RAG_SERVICE_URL: `{rag_url}`")
    question = st.text_input("Question", "Summarize the onboarding policy")
    k = st.slider("Top-K", 1, 8, 4)
    mock = st.checkbox("Mock mode", False)
    if mock:
        os.environ["MOCK"] = "1"
    else:
        os.environ.pop("MOCK", None)

col1, col2 = st.columns(2)

if st.button("Run Flow"):
    with st.spinner("Running Prefect flow..."):
        t0 = time.time()
        result = rag_flow.fn(question=question, k=k)  # call underlying function synchronously for demo
        dt = time.time() - t0
    with col1:
        st.subheader("Answer")
        st.code(result["answer"][:2000])
        st.metric("Elapsed (s)", f"{result['elapsed']:.2f}")
    with col2:
        st.subheader("Retrieved Hits")
        st.json(result["hits"])

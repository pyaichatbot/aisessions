# Session 9 – Prefect Demo (with Streamlit UI)

This wraps a simple RAG flow in **Prefect 2.x** and adds a **Streamlit UI** so you can run it live on stage.

## What you'll show
- Start/End state, retries, and elapsed time
- The retrieved hits and the synthesized answer
- Env var `RAG_SERVICE_URL` to point at your Session 8 RAG service

## Quick start (local)
```bash
python -m venv .venv && . .venv/Scripts/activate   # PowerShell: .venv\Scripts\Activate.ps1
pip install -r requirements.txt
# Run the Streamlit UI
streamlit run streamlit_app.py
```

## With Docker
```bash
docker build -t prefect-rag-ui .
docker run --rm -p 8501:8501 -e RAG_SERVICE_URL=http://host.docker.internal:8000 prefect-rag-ui
# Open http://localhost:8501
```

import os, time
import httpx
from prefect import task, flow, get_run_logger
from prefect.tasks import task_input_hash
from datetime import timedelta

RAG_URL = os.getenv("RAG_SERVICE_URL", "http://localhost:8000")

@task(retries=3, retry_delay_seconds=2, cache_key_fn=task_input_hash, cache_expiration=timedelta(minutes=5), timeout_seconds=20)
def fetch_context(question: str, k: int = 4):
    if os.getenv("MOCK", "0") == "1":
        return {"hits": [{"score":0.88,"path":"Policy.md","chunk":0,"text":"Policy text..."}]}
    r = httpx.post(f"{RAG_URL}/query", json={"question": question, "k": k}, timeout=10.0)
    r.raise_for_status()
    return r.json()

@task
def synthesize_answer(question: str, hits: list[dict]) -> str:
    bullets = []
    for h in hits or []:
        bullets.append(f"- ({h.get('score',0):.3f}) {os.path.basename(h.get('path',''))}#{h.get('chunk',0)}: {h.get('text','')[:120].replace('\n',' ')}...")
    return f"Answer for: '{question}'\n" + "\n".join(bullets)

@flow(name="RAG Prefect Flow")
def rag_flow(question: str = "Summarize the onboarding policy", k: int = 4):
    log = get_run_logger()
    t0 = time.time()
    ctx = fetch_context(question, k)
    hits = ctx.get("hits", [])
    ans = synthesize_answer(question, hits)
    dt = time.time() - t0
    log.info("Retrieved %s hits in %.2fs", len(hits), dt)
    return {"answer": ans, "hits": hits, "elapsed": dt}

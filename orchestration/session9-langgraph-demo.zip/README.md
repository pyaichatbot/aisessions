# Session 9 – LangGraph Demo (LLM-native orchestration)

This demo builds a tiny **LangGraph** that routes a query to either:
- RAG retriever (HTTP to your Session 8 RAG service), or
- a mocked GitLab tool (read-only), or
- LLM-only fallback (heuristic),

and then synthesizes an answer.

## Quick start (local)
```bash
python -m venv .venv && . .venv/Scripts/activate
pip install -r requirements.txt
python graph_app.py
```

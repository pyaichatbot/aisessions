import os, json, re, httpx
from typing import TypedDict, Literal, Any
from langgraph.graph import StateGraph, END

RAG_URL = os.getenv("RAG_SERVICE_URL", "http://localhost:8000")

class State(TypedDict, total=False):
    query: str
    route: Literal["rag","gitlab","llm"]
    events: list[dict]
    hits: list[dict]
    tool_result: Any
    answer: str

def add_event(s: State, t: str, data: Any):
    s.setdefault("events", []).append({"type": t, "data": data})

def router(s: State) -> State:
    q = s["query"].lower()
    if any(k in q for k in ["policy","document","onboarding","guidelines","summarize"]):
        s["route"] = "rag"; add_event(s,"router",{"route":"rag"}); return s
    if any(k in q for k in ["mr","merge request","repo","project","diff","gitlab"]):
        s["route"] = "gitlab"; add_event(s,"router",{"route":"gitlab"}); return s
    s["route"] = "llm"; add_event(s,"router",{"route":"llm"}); return s

def rag_node(s: State) -> State:
    q = s["query"]
    try:
        r = httpx.post(f"{RAG_URL}/query", json={"question": q, "k": 4}, timeout=20.0)
        r.raise_for_status()
        out = r.json()
    except Exception as e:
        out = {"hits": [], "error": str(e)}
    s["hits"] = out.get("hits", [])
    add_event(s,"retrieval_result", s["hits"])
    return s

def gitlab_tool_node(s: State) -> State:
    q = s["query"]
    m = re.search(r"project\s+(\d+)", q.lower())
    project = int(m.group(1)) if m else 123
    result = {"tool":"gitlab_search_code","args":{"project_id":project,"query":"login","ref":"main"},"matches":[{"path":"src/auth/login.py","snippet":"def login(..."}]}
    s["tool_result"] = result
    add_event(s,"tool_result", result)
    return s

def llm_node(s: State) -> State:
    s["answer"] = f"Heuristic answer to: {s['query']}"
    add_event(s,"final",{"answer": s["answer"]})
    return s

def synth_node(s: State) -> State:
    if s.get("route") == "rag":
        bullets = [f"- ({h.get('score',0):.3f}) {os.path.basename(h.get('path',''))}#{h.get('chunk',0)}: {h.get('text','')[:100].replace('\n',' ')}..." for h in (s.get('hits') or [])]
        s["answer"] = "Synthesized from RAG:\n" + "\n".join(bullets)
    elif s.get("route") == "gitlab":
        s["answer"] = f"Synthesized from GitLab tool: {json.dumps(s.get('tool_result'), indent=2)[:400]}"
    add_event(s,"final",{"answer": s["answer"]})
    return s

workflow = StateGraph(State)
workflow.add_node("router", router)
workflow.add_node("rag", rag_node)
workflow.add_node("gitlab", gitlab_tool_node)
workflow.add_node("llm", llm_node)
workflow.add_node("synth", synth_node)

workflow.set_entry_point("router")
workflow.add_edge("rag","synth")
workflow.add_edge("gitlab","synth")
workflow.add_edge("llm", END)
workflow.add_conditional_edges("router", lambda s: s["route"], {"rag":"rag","gitlab":"gitlab","llm":"llm"})
graph = workflow.compile()

if __name__ == "__main__":
    start = {"query":"Summarize the onboarding policy"}
    final: State = graph.invoke(start)
    print(json.dumps({"events": final.get("events",[]), "answer": final.get("answer")}, indent=2))

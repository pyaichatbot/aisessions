# Session 9 – LangGraph Demo (with Streamlit UI)

This shows a minimal **LangGraph** for routing a query to RAG / GitLab (mock) / LLM fallback,
with a small **Streamlit UI** to visualize the steps and final answer.

## Quick start (local)
```bash
python -m venv .venv && . .venv/Scripts/activate
pip install -r requirements.txt
streamlit run streamlit_app.py
```

## With Docker
```bash
docker build -t langgraph-agent-ui .
docker run --rm -p 8502:8501 -e RAG_SERVICE_URL=http://host.docker.internal:8000 langgraph-agent-ui
# Open http://localhost:8502
```

import streamlit as st
from graph_app import graph

st.set_page_config(page_title="LangGraph Orchestration", layout="wide")
st.title("LangGraph Orchestration (Session 9)")

query = st.text_input("Query", "Summarize the onboarding policy")

if st.button("Run Graph"):
    with st.spinner("Running LangGraph..."):
        final = graph.invoke({"query": query})
    st.subheader("Events")
    st.json(final.get("events", []))
    st.subheader("Answer")
    st.code(final.get("answer", ""))

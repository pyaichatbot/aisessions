# Offline step: download dots.ocr weights to ./models/DotsOCR

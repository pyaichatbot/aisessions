from fastapi import APIRouter
from app.core.config import settings

router = APIRouter()

@router.get("/healthz")
async def healthz():
    return {"status":"ok","mode":"inprocess-cpu","model_path": settings.model_path}

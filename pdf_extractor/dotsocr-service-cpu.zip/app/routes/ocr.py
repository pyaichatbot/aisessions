from fastapi import APIRouter, UploadFile, File, HTTPException
from app.core.config import settings
from app.schemas.responses import ExtractResponse
from app.services.pdf_loader import load_pdf_as_images
from app.services.extractor import process_pages
from PIL import Image
import io

router = APIRouter()

@router.post("/extract", response_model=ExtractResponse)
async def extract(file: UploadFile = File(...)):
    content = await file.read()
    ct = file.content_type or ""
    max_bytes = settings.max_upload_mb * 1024 * 1024
    if len(content) > max_bytes:
        raise HTTPException(status_code=413, detail=f"File too large. Limit {settings.max_upload_mb} MB.")
    try:
        if ct in ("application/pdf",) or file.filename.lower().endswith(".pdf"):
            with open("/tmp/_upload.pdf","wb") as f:
                f.write(content)
            pages = load_pdf_as_images("/tmp/_upload.pdf", max_pages=settings.max_pdf_pages)
        else:
            img = Image.open(io.BytesIO(content))
            pages = [(0, img)]
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Unsupported or corrupt file: {e}")
    resp = await process_pages(
        file_name=file.filename,
        content_type=ct or ("application/pdf" if file.filename.lower().endswith(".pdf") else "image"),
        pages=pages,
        detect_tables=settings.detect_tables,
        detect_arrows_flag=settings.detect_arrows,
        model_name="DotsOCR-CPU"
    )
    return resp

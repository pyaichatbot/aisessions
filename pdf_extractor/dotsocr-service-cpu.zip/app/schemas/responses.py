from typing import List, Optional, Any, Dict
from pydantic import BaseModel

class BBox(BaseModel):
    x: int
    y: int
    w: int
    h: int

class OCRWord(BaseModel):
    text: str
    bbox: Optional[BBox] = None
    confidence: Optional[float] = None

class OCRBlock(BaseModel):
    type: str
    text: Optional[str] = None
    bbox: Optional[BBox] = None
    words: Optional[List[OCRWord]] = None
    extra: Optional[Dict[str, Any]] = None

class ArrowEdge(BaseModel):
    start: BBox
    end: BBox
    confidence: float

class TableCell(BaseModel):
    row: int
    col: int
    text: Optional[str] = None
    bbox: Optional[BBox] = None

class TableResult(BaseModel):
    bbox: Optional[BBox] = None
    n_rows: int
    n_cols: int
    cells: List[TableCell]

class PageResult(BaseModel):
    page_index: int
    width: int
    height: int
    blocks: List[OCRBlock]
    tables: Optional[List[TableResult]] = None
    arrows: Optional[List[ArrowEdge]] = None

class ExtractResponse(BaseModel):
    file_name: str
    content_type: str
    pages: List[PageResult]
    model: str
    metadata: Optional[Dict[str, Any]] = None

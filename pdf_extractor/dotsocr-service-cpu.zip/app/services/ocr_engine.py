from PIL import Image
from anyio import to_thread
from app.core.config import settings
from app.services.ocr_engine_inprocess import infer_image_json_sync

async def ocr_page(img: Image.Image) -> str:
    return await to_thread.run_sync(infer_image_json_sync, img, settings.model_path)

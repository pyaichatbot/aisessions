import json, asyncio
from typing import List, Tuple
from PIL import Image
import numpy as np, cv2
from loguru import logger
from app.schemas.responses import ExtractResponse, PageResult, OCRBlock, BBox, TableResult, TableCell, ArrowEdge
from app.services.ocr_engine import ocr_page
from app.services.vision_utils import detect_arrows, detect_table_grid
from app.core.config import settings

async def _process_one(page_index: int, pil_img: Image.Image, detect_tables: bool, detect_arrows_flag: bool) -> PageResult:
    w, h = pil_img.size
    logger.info(f"CPU OCR on page {page_index} ({w}x{h})")
    ocr_json_text = await ocr_page(pil_img)
    try:
        ocr_json = json.loads(ocr_json_text)
    except Exception as e:
        ocr_json = {"blocks": []}
    blocks: List[OCRBlock] = []
    for blk in ocr_json.get("blocks", []):
        bbox = blk.get("bbox") or {}
        blocks.append(OCRBlock(
            type=str(blk.get("type","text")),
            text=blk.get("text"),
            bbox=BBox(x=int(bbox.get("x",0)), y=int(bbox.get("y",0)), w=int(bbox.get("w",0)), h=int(bbox.get("h",0))) if bbox else None,
            words=None,
            extra=blk.get("extra")
        ))
    tables = None
    arrows = None
    rgb = np.array(pil_img.convert("RGB"))
    bgr = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
    if detect_tables:
        grid = detect_table_grid(bgr)
        if grid:
            ys, xs = grid
            cells = [TableCell(row=ri, col=ci) for ri in range(len(ys)-1) for ci in range(len(xs)-1)]
            tables = [TableResult(bbox=None, n_rows=len(ys)-1, n_cols=len(xs)-1, cells=cells)]
    if detect_arrows_flag:
        arrs = detect_arrows(bgr)
        arrows = [ArrowEdge(
            start=BBox(x=a[0][0], y=a[0][1], w=1, h=1),
            end=BBox(x=a[1][0], y=a[1][1], w=1, h=1),
            confidence=float(a[2])
        ) for a in arrs]
    return PageResult(page_index=page_index, width=w, height=h, blocks=blocks, tables=tables, arrows=arrows)

async def process_pages(file_name: str, content_type: str, pages: List[Tuple[int, Image.Image]], 
                        detect_tables: bool, detect_arrows_flag: bool, model_name: str) -> ExtractResponse:
    sem = asyncio.Semaphore(settings.max_concurrency)
    async def bounded(p):
        i, img = p
        async with sem:
            return await _process_one(i, img, detect_tables, detect_arrows_flag)
    results = await asyncio.gather(*[bounded(p) for p in pages])
    results.sort(key=lambda r: r.page_index)
    return ExtractResponse(
        file_name=file_name, content_type=content_type, pages=results, model=model_name,
        metadata={"notes": "CPU mode with bounded concurrency. Tune MAX_CONCURRENCY and thread env vars."}
    )

from typing import List, Tuple, Optional
import numpy as np
import cv2

def detect_arrows(bgr: np.ndarray) -> List[Tuple[Tuple[int,int], Tuple[int,int], float]]:
    gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
    gray = cv2.GaussianBlur(gray, (3,3), 0)
    edges = cv2.Canny(gray, 50, 150, apertureSize=3)
    lines = cv2.HoughLinesP(edges, 1, np.pi/180, threshold=70, minLineLength=40, maxLineGap=10)
    results = []
    if lines is None:
        return results
    for l in lines[:,0,:]:
        x1,y1,x2,y2 = map(int, l)
        length = np.hypot(x2-x1, y2-y1)
        if length < 50:
            continue
        roi = edges[max(0,y2-6):y2+6, max(0,x2-6):x2+6]
        conf = 0.6 if roi.size and roi.sum() > 1000 else 0.4
        results.append(((x1,y1),(x2,y2), conf))
    return results

def detect_table_grid(bgr: np.ndarray) -> Optional[Tuple[List[int], List[int]]]:
    gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
    bw = cv2.adaptiveThreshold(~gray,255,cv2.ADAPTIVE_THRESH_MEAN_C,cv2.THRESH_BINARY,15,-2)
    horizontalsize = max(10, bgr.shape[1]//30)
    horizontalStructure = cv2.getStructuringElement(cv2.MORPH_RECT, (horizontalsize,1))
    hor = cv2.erode(bw, horizontalStructure); hor = cv2.dilate(hor, horizontalStructure)
    verticalsize = max(10, bgr.shape[0]//30)
    verticalStructure = cv2.getStructuringElement(cv2.MORPH_RECT, (1,verticalsize))
    ver = cv2.erode(bw, verticalStructure); ver = cv2.dilate(ver, verticalStructure)
    mask = cv2.add(hor, ver)
    ys = [int(i) for i in np.where(mask.sum(axis=1).flatten()> (mask.sum(axis=1).max()*0.5))[0]]
    xs = [int(i) for i in np.where(mask.sum(axis=0).flatten()> (mask.sum(axis=0).max()*0.5))[0]]
    if len(xs) < 2 or len(ys) < 2:
        return None
    def pick_peaks(arr, min_gap=12):
        sel, last = [], -9999
        for idx in arr:
            if idx - last >= min_gap:
                sel.append(int(idx)); last = idx
        return sel
    xs = pick_peaks(xs, 20); ys = pick_peaks(ys, 20)
    if len(xs) < 2 or len(ys) < 2:
        return None
    return ys, xs

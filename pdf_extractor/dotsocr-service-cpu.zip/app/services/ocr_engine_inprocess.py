import os
from PIL import Image
from loguru import logger

_model = None
_tokenizer = None
_processor = None

SYSTEM_PROMPT = (
    "You are dots.ocr, a unified multilingual document parser. "
    "Given an image of a document page, extract a structured JSON with: "
    "blocks (type one of ['title','text','table','figure','formula']), reading order, "
    "plain text for each block, and bounding boxes in pixel coordinates. "
    "For tables, include a markdown or CSV rendition under extra.markdown if available. "
    "Respond ONLY with JSON."
)

def _lazy_load(model_path: str):
    global _model, _tokenizer, _processor
    if _model is not None:
        return
    import torch
    from transformers import AutoTokenizer, AutoProcessor, AutoModelForCausalLM
    os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
    for k in ["OMP_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS"]:
        os.environ.setdefault(k, "4")
    logger.info(f"Loading DotsOCR from {model_path} on CPU...")
    _tokenizer = AutoTokenizer.from_pretrained(model_path, trust_remote_code=True)
    _processor = AutoProcessor.from_pretrained(model_path, trust_remote_code=True)
    _model = AutoModelForCausalLM.from_pretrained(
        model_path,
        trust_remote_code=True,
        torch_dtype="float32",
        low_cpu_mem_usage=True,
    )
    _model.eval()

def infer_image_json_sync(img: Image.Image, model_path: str) -> str:
    _lazy_load(model_path)
    import torch
    inputs = _processor(
        text=SYSTEM_PROMPT,
        images=img,
        return_tensors="pt"
    )
    with torch.no_grad():
        out = _model.generate(
            **inputs,
            max_new_tokens=1536,
            do_sample=False,
        )
    txt = _tokenizer.decode(out[0], skip_special_tokens=True)
    i = txt.find("{")
    return txt[i:] if i >= 0 else txt

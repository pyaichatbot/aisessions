import os
from pydantic import BaseModel

class Settings(BaseModel):
    app_name: str = "dotsocr-service-cpu"
    api_prefix: str = "/api"
    environment: str = os.getenv("ENVIRONMENT", "production")

    # In-process CPU inference
    use_inprocess: bool = os.getenv("USE_INPROCESS", "true").lower() == "true"
    model_path: str = os.getenv("MODEL_PATH", "/models/DotsOCR")

    # Concurrency (bounded)
    max_concurrency: int = int(os.getenv("MAX_CONCURRENCY", "3"))

    # Limits
    max_upload_mb: int = int(os.getenv("MAX_UPLOAD_MB", "50"))
    max_pdf_pages: int = int(os.getenv("MAX_PDF_PAGES", "30"))

    # Processing toggles
    detect_tables: bool = os.getenv("DETECT_TABLES", "true").lower() == "true"
    detect_arrows: bool = os.getenv("DETECT_ARROWS", "true").lower() == "true"

    # CORS
    allow_origins: str = os.getenv("CORS_ALLOW_ORIGINS", "*")

settings = Settings()

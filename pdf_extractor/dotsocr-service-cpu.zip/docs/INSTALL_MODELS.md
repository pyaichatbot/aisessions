# Offline Model Installation (DotsOCR) — CPU-only

This service **does not download any models at runtime**. Place the DotsOCR weights under
`./models/DotsOCR` **before** building/running Docker.

## Required files to copy from `rednote-hilab/dots.ocr`
- `model-00001-of-00002.safetensors`
- `model-00002-of-00002.safetensors`
- `model.safetensors.index.json`
- `config.json`
- `preprocessor_config.json`
- `tokenizer.json`, `tokenizer_config.json`, `special_tokens_map.json`, `vocab.json`, `merges.txt`
- (recommended) `chat_template.json`, `generation_config.json`
- (for trust_remote_code) `configuration_dots.py`, `modeling_dots_ocr.py`, `modeling_dots_vision.py`

Copy them into:
```bash
mkdir -p ./models/DotsOCR
cp /path/to/downloaded/* ./models/DotsOCR/
```

> Use a folder name **without periods** (e.g., `DotsOCR`, not `dots.ocr`).

## Verify (offline)
- The container mounts `./models` (read-only) at `/models`.
- The app loads from `/models/DotsOCR` with `trust_remote_code=True` (no internet required at runtime).

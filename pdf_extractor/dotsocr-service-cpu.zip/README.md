# dotsocr-service (CPU-only, in-process FastAPI)

A production-grade but **easy-to-read** FastAPI service that runs **dots.ocr** in-process on **CPU only**.
No external model server; models are loaded from a **local folder** you mount into the container.
Includes bounded concurrency (semaphore) for decent throughput on multi-core CPUs.

## Quickstart
1) Place weights under `./models/DotsOCR` (see `docs/INSTALL_MODELS.md`).
2) Build & run:
```bash
docker compose build
docker compose up -d
```
3) Health & extract:
```bash
curl http://localhost:8080/api/healthz
curl -X POST -F "file=@/path/to/diagram.png" http://localhost:8080/api/extract
```

## Env
- `MODEL_PATH=/models/DotsOCR`
- `MAX_CONCURRENCY=3` (increase gradually)
- Thread caps: `OMP_NUM_THREADS=4`, `MKL_NUM_THREADS=4`, `TOKENIZERS_PARALLELISM=false`

## Notes
- CPU-only is slower than GPU—use bounded concurrency & scale replicas for throughput.
- OpenCV table/arrow detection is intentionally simple; replace with ML detectors if needed.

# Offline Model Installation (DotsOCR)

This service **does not download any models at runtime**. You must place the DotsOCR weights
under `./models/DotsOCR` **before** building/running Docker.

## Get weights on a machine with internet

1. Clone the official repo:
   ```bash
   git clone https://github.com/rednote-hilab/dots.ocr.git
   cd dots.ocr
   ```
2. (Optional) Create a clean Python env and install requirements as per upstream README.
3. Use their download tool to fetch weights locally (choose Hugging Face or ModelScope as desired):
   ```bash
   # Hugging Face
   python3 tools/download_model.py

   # Or ModelScope
   python3 tools/download_model.py --type modelscope
   ```
4. This will create a folder, typically `weights/DotsOCR/`. **Note:** Upstream advises using a folder
   name **without periods** (e.g., `DotsOCR` not `dots.ocr`). Move/copy that folder into this project:
   ```bash
   mkdir -p /path/to/dotsocr-service/models
   cp -r weights/DotsOCR /path/to/dotsocr-service/models/DotsOCR
   ```

## Verify (offline)

- Ensure: `dotsocr-service/models/DotsOCR` contains the model files (no further internet required).
- The provided `docker-compose.yml` mounts `./models` read-only into the vLLM container.
- The API service talks to the local vLLM at `http://vllm:8000/v1`.

## References

- Official repository and instructions are here. Consult them if their paths/CLI change. 
  We mirror the key steps above and load via vLLM using a local path. citeturn1view0

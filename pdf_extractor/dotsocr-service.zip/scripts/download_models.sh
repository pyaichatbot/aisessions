#!/usr/bin/env bash
set -euo pipefail
echo "This script documents the **offline** steps to fetch DotsOCR."
echo "Run these on a machine with internet, then copy the weights into ./models/DotsOCR"
cat <<'DOC'
Steps:
  1) git clone https://github.com/rednote-hilab/dots.ocr.git
  2) cd dots.ocr
  3) python3 tools/download_model.py         # or: python3 tools/download_model.py --type modelscope
  4) cp -r weights/DotsOCR /path/to/your/offline-machine/dotsocr-service/models/DotsOCR
DOC

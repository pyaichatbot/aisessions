from fastapi import APIRouter
from app.core.config import settings

router = APIRouter()

@router.get("/healthz")
async def healthz():
    return {"status":"ok","model": settings.vllm_model}

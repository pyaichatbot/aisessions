from fastapi import APIRouter, UploadFile, File, HTTPException, BackgroundTasks
from app.core.config import settings
from app.schemas.responses import ExtractResponse
from app.services.pdf_loader import load_pdf_as_images
from app.services.extractor import process_pages
from PIL import Image
import io

router = APIRouter()

@router.post("/extract", response_model=ExtractResponse)
async def extract(file: UploadFile = File(...)):
    content = await file.read()
    ct = file.content_type or ""
    try:
        if ct in ("application/pdf",) or file.filename.lower().endswith(".pdf"):
            pages = load_pdf_as_images(path:= ("/tmp/_upload.pdf"), max_pages=settings.max_pdf_pages)
        else:
            img = Image.open(io.BytesIO(content))
            pages = [(0, img)]
    except Exception:
        # If we're here, maybe it's a PDF (needs disk)
        if file.filename.lower().endswith(".pdf") or ct == "application/pdf":
            with open("/tmp/_upload.pdf","wb") as f:
                f.write(content)
            pages = load_pdf_as_images("/tmp/_upload.pdf", max_pages=settings.max_pdf_pages)
        else:
            try:
                img = Image.open(io.BytesIO(content))
                pages = [(0, img)]
            except Exception as e:
                raise HTTPException(status_code=400, detail=f"Unsupported file or corrupt content: {e}")

    resp = await process_pages(
        file_name=file.filename,
        content_type=ct or ("application/pdf" if file.filename.lower().endswith(".pdf") else "image"),
        pages=pages,
        detect_tables=settings.detect_tables,
        detect_arrows_flag=settings.detect_arrows,
        model_name=settings.vllm_model
    )
    return resp

from typing import List, Tuple, Optional
import numpy as np
import cv2

def detect_arrows(bgr: np.ndarray) -> List[Tuple[Tuple[int,int], Tuple[int,int], float]]:
    """Very simple arrow-ish detector using binarization + Hough lines + arrowhead heuristics.
    Returns list of ((x1,y1),(x2,y2), confidence).
    This is intentionally lightweight; for production robustness, replace with a learned detector.
    """
    gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
    gray = cv2.GaussianBlur(gray, (3,3), 0)
    edges = cv2.Canny(gray, 50, 150, apertureSize=3)
    lines = cv2.HoughLinesP(edges, 1, np.pi/180, threshold=70, minLineLength=40, maxLineGap=10)
    results = []
    if lines is None:
        return results
    for l in lines[:,0,:]:
        x1,y1,x2,y2 = map(int, l)
        length = np.hypot(x2-x1, y2-y1)
        if length < 50:
            continue
        # crude arrowhead heuristic via local cornerness at endpoint
        roi = edges[max(0,y2-6):y2+6, max(0,x2-6):x2+6]
        corner_score = cv2.goodFeaturesToTrack(roi, maxCorners=3, qualityLevel=0.01, minDistance=2)
        conf = 0.6 if corner_score is not None and len(corner_score) >= 2 else 0.4
        results.append(((x1,y1),(x2,y2), conf))
    return results

def detect_table_grid(bgr: np.ndarray) -> Optional[Tuple[List[int], List[int]]]:
    """Detect a simple ruled table by line detection.
    Returns (row_y_coords, col_x_coords). Very naive; works for clear, ruled tables.
    """
    gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
    bw = cv2.adaptiveThreshold(~gray,255,cv2.ADAPTIVE_THRESH_MEAN_C,cv2.THRESH_BINARY,15,-2)
    # horizontal lines
    horizontalsize = max(10, bgr.shape[1]//30)
    horizontalStructure = cv2.getStructuringElement(cv2.MORPH_RECT, (horizontalsize,1))
    hor = cv2.erode(bw, horizontalStructure)
    hor = cv2.dilate(hor, horizontalStructure)
    # vertical lines
    verticalsize = max(10, bgr.shape[0]//30)
    verticalStructure = cv2.getStructuringElement(cv2.MORPH_RECT, (1,verticalsize))
    ver = cv2.erode(bw, verticalStructure)
    ver = cv2.dilate(ver, verticalStructure)
    mask = cv2.add(hor, ver)
    # find contours of intersection grid
    ys, xs = [], []
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return None
    # extract lines as projections
    sum_rows = mask.sum(axis=1).flatten()
    sum_cols = mask.sum(axis=0).flatten()
    ys = [int(i) for i in np.where(sum_rows> (sum_rows.max()*0.5))[0]]
    xs = [int(i) for i in np.where(sum_cols> (sum_cols.max()*0.5))[0]]
    if len(xs) < 2 or len(ys) < 2:
        return None
    # thin by picking peaks at intervals
    def pick_peaks(arr, min_gap=12):
        sel = []
        last = -9999
        for idx in arr:
            if idx - last >= min_gap:
                sel.append(int(idx))
                last = idx
        return sel
    xs = pick_peaks(xs, 20)
    ys = pick_peaks(ys, 20)
    if len(xs) < 2 or len(ys) < 2:
        return None
    return ys, xs

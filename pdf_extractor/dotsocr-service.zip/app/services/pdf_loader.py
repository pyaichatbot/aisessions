import fitz  # PyMuPDF
from typing import List, Tuple
from loguru import logger

def load_pdf_as_images(path: str, max_pages: int = 50, dpi: int = 200) -> List[Tuple[int, "PIL.Image.Image"]]:
    from PIL import Image
    doc = fitz.open(path)
    images = []
    n_pages = min(len(doc), max_pages)
    logger.info(f"Loading PDF {path} with {len(doc)} pages; processing first {n_pages} pages @ {dpi} dpi")
    for i in range(n_pages):
        page = doc[i]
        mat = fitz.Matrix(dpi/72.0, dpi/72.0)
        pix = page.get_pixmap(matrix=mat, alpha=False)
        img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
        images.append((i, img))
    doc.close()
    return images

import json
from typing import List, Dict, Any, Tuple
from PIL import Image
import numpy as np
from loguru import logger
from app.schemas.responses import ExtractResponse, PageResult, OCRBlock, BBox, TableResult, TableCell, ArrowEdge
from app.services.ocr_engine import ocr_page
from app.services.vision_utils import detect_arrows, detect_table_grid

def _img_to_bgr(img: Image.Image):
    import cv2, numpy as np
    rgb = np.array(img.convert("RGB"))
    return cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)

async def process_pages(file_name: str, content_type: str, pages: List[Tuple[int, Image.Image]], 
                        detect_tables: bool, detect_arrows_flag: bool, model_name: str) -> ExtractResponse:
    results: List[PageResult] = []
    for page_index, pil_img in pages:
        w, h = pil_img.size
        logger.info(f"Running dots.ocr on page {page_index} ({w}x{h})")
        ocr_json_text = await ocr_page(pil_img)
        try:
            ocr_json = json.loads(ocr_json_text)
        except Exception as e:
            logger.error(f"Failed to parse OCR JSON on page {page_index}: {e}")
            ocr_json = {"blocks": []}

        blocks: List[OCRBlock] = []
        for blk in ocr_json.get("blocks", []):
            bbox = blk.get("bbox") or {}
            b = OCRBlock(
                type=str(blk.get("type","text")),
                text=blk.get("text"),
                bbox=BBox(x=int(bbox.get("x",0)), y=int(bbox.get("y",0)), w=int(bbox.get("w",0)), h=int(bbox.get("h",0))) if bbox else None,
                words=None,
                extra=blk.get("extra")
            )
            blocks.append(b)

        tables = None
        arrows = None
        bgr = _img_to_bgr(pil_img)
        if detect_tables:
            grid = detect_table_grid(bgr)
            if grid:
                ys, xs = grid
                cells = []
                for ri in range(len(ys)-1):
                    for ci in range(len(xs)-1):
                        cells.append(TableCell(row=ri, col=ci, text=None, bbox=None))
                tables = [TableResult(bbox=None, n_rows=len(ys)-1, n_cols=len(xs)-1, cells=cells)]
        if detect_arrows_flag:
            arrs = detect_arrows(bgr)
            arrows = [ArrowEdge(
                start=BBox(x=a[0][0], y=a[0][1], w=1, h=1),
                end=BBox(x=a[1][0], y=a[1][1], w=1, h=1),
                confidence=float(a[2])
            ) for a in arrs]

        results.append(PageResult(
            page_index=page_index, width=w, height=h,
            blocks=blocks, tables=tables, arrows=arrows
        ))

    return ExtractResponse(
        file_name=file_name, content_type=content_type, pages=results, model=model_name,
        metadata={"notes":"Tables and arrows are best-effort heuristics; replace with ML detectors for production needs."}
    )

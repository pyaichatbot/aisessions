import base64, io
from typing import Dict, Any, List, Tuple
from PIL import Image
import httpx
from loguru import logger
from app.core.config import settings

OCR_SYSTEM_PROMPT = (
    "You are dots.ocr, a unified multilingual document parser. "
    "Given an image of a document page, extract a structured JSON with: "
    "blocks (type one of ['title','text','table','figure','formula']), reading order, "
    "plain text for each block, and bounding boxes in pixel coordinates. "
    "For tables, include a markdown or CSV rendition under extra.markdown if available. "
    "Respond ONLY with JSON."
)

def _b64(img: Image.Image) -> str:
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return base64.b64encode(buf.getvalue()).decode("utf-8")

async def ocr_page(img: Image.Image) -> Dict[str, Any]:
    """Send one page to local vLLM (running dots.ocr) using OpenAI-compatible /chat/completions."""
    payload = {
        "model": settings.vllm_model,
        "temperature": 0.0,
        "messages": [
            {"role": "system", "content": OCR_SYSTEM_PROMPT},
            {"role": "user", "content": [
                {"type":"input_text", "text":"Parse this page and return JSON."},
                {"type":"input_image", "image_url": f"data:image/png;base64,{_b64(img)}"}
            ]}
        ],
        "max_tokens": 2048
    }
    headers = {"Authorization": f"Bearer {settings.vllm_api_key}"}
    url = f"{settings.vllm_base_url}/chat/completions"
    logger.debug(f"POST {url}")
    async with httpx.AsyncClient(timeout=120) as client:
        r = await client.post(url, headers=headers, json=payload)
        r.raise_for_status()
        data = r.json()
    # Extract assistant message content
    content = data["choices"][0]["message"]["content"]
    # Some servers may return JSON as a fenced code block; try to strip if present.
    if content.strip().startswith("```"):
        content = content.strip().strip("`")
        if content.lower().startswith("json"):
            content = content[4:].strip()
    return content

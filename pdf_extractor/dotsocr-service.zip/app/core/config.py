import os
from pydantic import BaseModel, Field, field_validator
from typing import Optional

class Settings(BaseModel):
    app_name: str = "dotsocr-service"
    api_prefix: str = "/api"
    environment: str = os.getenv("ENVIRONMENT", "production")
    # OpenAI-compatible vLLM endpoint that serves the DotsOCR model locally
    vllm_base_url: str = os.getenv("VLLM_BASE_URL", "http://vllm:8000/v1")
    vllm_api_key: str = os.getenv("VLLM_API_KEY", "local")  # any non-empty string for local vLLM
    vllm_model: str = os.getenv("VLLM_MODEL", "DotsOCR")    # the model name registered in vLLM

    # Max file size & pages
    max_upload_mb: int = int(os.getenv("MAX_UPLOAD_MB", "50"))
    max_pdf_pages: int = int(os.getenv("MAX_PDF_PAGES", "50"))

    # Processing settings
    detect_tables: bool = os.getenv("DETECT_TABLES", "true").lower() == "true"
    detect_arrows: bool = os.getenv("DETECT_ARROWS", "true").lower() == "true"

    # Security
    allow_origins: str = os.getenv("CORS_ALLOW_ORIGINS", "*")

    @field_validator("vllm_base_url")
    @classmethod
    def _normalize_url(cls, v: str) -> str:
        return v.rstrip("/")

settings = Settings()

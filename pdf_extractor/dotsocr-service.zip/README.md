# dotsocr-service (FastAPI + vLLM, offline models)

A production-grade, **easy-to-read** FastAPI microservice that extracts structure from PDFs/images
using **dots.ocr** served locally via **vLLM**. Handles:

- PDFs (rasterized page-by-page via PyMuPDF)
- Images (JPG/PNG/WEBP)
- Best‑effort detection of tables (ruled grids) and directional arrows (simple OpenCV heuristics)
- Clean JSON schema (pages → blocks/tables/arrows) for downstream pipelines

**No runtime downloads.** Models are loaded locally by vLLM from `./models/DotsOCR`.

---

## Why this design?

- **Separation of concerns:** OCR inference is delegated to a dedicated vLLM process; the API remains lightweight.
- **Local-first:** Works fully offline after you place weights under `./models/DotsOCR`. citeturn1view0
- **Sane defaults:** Minimal, maintainable modules; replace heuristics with ML detectors when needed.
- **Container-native:** Dockerfile and docker-compose included.

---

## Quickstart (Offline)

1) **Place weights**  
   Follow [docs/INSTALL_MODELS.md](docs/INSTALL_MODELS.md) to obtain DotsOCR weights **offline** and copy into:
   ```
   ./models/DotsOCR
   ```

2) **Build & run**
   ```bash
   docker compose build
   docker compose up -d
   ```

3) **Health check**
   ```bash
   curl http://localhost:8080/api/healthz
   ```

4) **Extract**
   ```bash
   # PDF
   curl -X POST -F "file=@/path/to/doc.pdf" http://localhost:8080/api/extract

   # Image
   curl -X POST -F "file=@/path/to/page.png" http://localhost:8080/api/extract
   ```

---

## API

- `GET /api/healthz` → `{ status, model }`
- `POST /api/extract` (multipart form with `file`): returns structured JSON:

```json
{
  "file_name": "doc.pdf",
  "content_type": "application/pdf",
  "model": "DotsOCR",
  "pages": [
    {
      "page_index": 0,
      "width": 1654,
      "height": 2339,
      "blocks": [
        {"type":"title","text":"...","bbox":{"x":...,"y":...,"w":...,"h":...}},
        {"type":"text","text":"...","bbox":{...}},
        {"type":"table","text":null,"bbox":{...},"extra":{"markdown":"|...|"}}
      ],
      "tables": [
        {"n_rows": 8, "n_cols": 4, "cells":[{"row":0,"col":0,"text":null}, ...]}
      ],
      "arrows": [
        {"start":{"x":120,"y":210,"w":1,"h":1},"end":{"x":540,"y":210,"w":1,"h":1},"confidence":0.6}
      ]
    }
  ]
}
```

> Note: DotsOCR already outputs rich structure (text, tables, formulas, reading order). Our service
> prompts the model to return JSON; we also add **heuristic** table/arrow signals from OpenCV as
> supplementary hints. You can disable these via env flags.

---

## Configuration

Environment variables (see `docker-compose.yml`):

- `VLLM_BASE_URL` (default: `http://vllm:8000/v1`)
- `VLLM_API_KEY` (default: `local` — vLLM accepts any non-empty key)
- `VLLM_MODEL` (default: `DotsOCR` — name registered by vLLM)
- `MAX_PDF_PAGES` (default: `50`)
- `DETECT_TABLES` (`true`/`false`)
- `DETECT_ARROWS` (`true`/`false`)
- `CORS_ALLOW_ORIGINS` (CSV of allowed origins; default `*`)

---

## Production Notes

- **GPU:** For throughput, run vLLM on a GPU host with the DotsOCR weights on local SSDs. Upstream shows how to register model with vLLM from a local path. citeturn1view0
- **Scaling:** Run multiple `api` replicas behind a load balancer; scale `vllm` separately. Pin CPU/mem limits per container.
- **Observability:** Add structured logging sinks (ELK/OTEL) and request ids. (Left minimal here for clarity.)
- **Security:** Terminate TLS upstream; restrict CORS; scan uploads; limit max pages.
- **Tables & arrows:** The OpenCV routines are intentionally simple to keep the code base clean. Swap with
  specialized detectors if your documents are complex (e.g., merged cells, curved arrows).

---

## License & Attribution

- This wrapper is MIT. dots.ocr is MIT-licensed (see upstream) but may include assets under their terms.
  Please review their license before production use. citeturn1view0

---

## Troubleshooting

- **The model doesn’t load**: Ensure `./models/DotsOCR` exists and contains the weights. The compose file mounts it read-only.
- **HTTP 500 from vLLM**: Check GPU/CPU availability and logs; ensure your vLLM version supports image inputs.
- **Strange JSON**: Some VLM servers wrap JSON in markdown code fences. We strip basic fences; tighten parsing if needed.
- **Performance**: Rasterization DPI impacts speed/quality. Tune in `pdf_loader.load_pdf_as_images`.

---

## References

- Official dots.ocr repo (install & vLLM notes). citeturn1view0
- DotsOCR strengths: unified model for text/tables/reading order (recent overviews). citeturn0search4turn0search7

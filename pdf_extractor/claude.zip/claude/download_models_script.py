#!/usr/bin/env python3
"""
Model download script for dots.ocr
Downloads the required model weights locally for offline use
"""

import os
import sys
import logging
import shutil
from pathlib import Path
from typing import Optional

import requests
from huggingface_hub import snapshot_download, login
from transformers import AutoModelForCausalLM, AutoProcessor

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Configuration
MODEL_REPO = "rednote-hilab/dots.ocr"
DEFAULT_MODEL_PATH = "./weights/DotsOCR"
REQUIRED_FILES = [
    "config.json",
    "tokenizer_config.json",
    "tokenizer.json",
    "preprocessor_config.json",
    "modeling_dots_ocr_vllm.py",
    "configuration_dots_ocr.py"
]


def check_disk_space(path: Path, required_gb: float = 10.0) -> bool:
    """Check if there's enough disk space"""
    try:
        stat = shutil.disk_usage(path)
        free_gb = stat.free / (1024**3)
        if free_gb < required_gb:
            logger.error(f"Insufficient disk space. Required: {required_gb}GB, Available: {free_gb:.1f}GB")
            return False
        return True
    except Exception as e:
        logger.warning(f"Could not check disk space: {e}")
        return True


def download_model_huggingface(
    model_path: str, 
    hf_token: Optional[str] = None,
    force_download: bool = False
) -> bool:
    """Download model using Hugging Face Hub"""
    try:
        if hf_token:
            login(token=hf_token)
            logger.info("Logged into Hugging Face Hub")
        
        model_dir = Path(model_path)
        
        # Check if model already exists
        if model_dir.exists() and not force_download:
            logger.info(f"Model directory {model_dir} already exists")
            if all((model_dir / file).exists() for file in REQUIRED_FILES):
                logger.info("Model appears to be complete. Use --force to redownload")
                return True
            else:
                logger.warning("Model directory exists but appears incomplete")
        
        # Check disk space
        if not check_disk_space(model_dir.parent):
            return False
        
        logger.info(f"Downloading model from {MODEL_REPO} to {model_path}")
        
        # Download the model
        snapshot_download(
            repo_id=MODEL_REPO,
            local_dir=model_path,
            local_dir_use_symlinks=False,
            resume_download=True
        )
        
        logger.info("Model downloaded successfully")
        return True
        
    except Exception as e:
        logger.error(f"Failed to download model: {str(e)}")
        return False


def verify_model(model_path: str) -> bool:
    """Verify that the downloaded model is complete and loadable"""
    try:
        model_dir = Path(model_path)
        
        # Check required files
        missing_files = []
        for file in REQUIRED_FILES:
            if not (model_dir / file).exists():
                missing_files.append(file)
        
        if missing_files:
            logger.error(f"Missing required files: {missing_files}")
            return False
        
        logger.info("All required files present")
        
        # Try to load the model configuration
        try:
            from transformers import AutoConfig
            config = AutoConfig.from_pretrained(model_path, trust_remote_code=True)
            logger.info(f"Model config loaded successfully: {config.model_type}")
        except Exception as e:
            logger.warning(f"Could not load model config: {e}")
            # Don't fail verification for this, as it might be environment-specific
        
        return True
        
    except Exception as e:
        logger.error(f"Model verification failed: {str(e)}")
        return False


def create_model_info(model_path: str):
    """Create a model info file with metadata"""
    try:
        model_dir = Path(model_path)
        info_file = model_dir / "model_info.json"
        
        import json
        from datetime import datetime
        
        info = {
            "model_repo": MODEL_REPO,
            "download_date": datetime.now().isoformat(),
            "model_path": str(model_dir.absolute()),
            "verified": True,
            "notes": "Downloaded using dots-ocr download script"
        }
        
        with open(info_file, 'w') as f:
            json.dump(info, f, indent=2)
        
        logger.info(f"Created model info file: {info_file}")
        
    except Exception as e:
        logger.warning(f"Could not create model info file: {e}")


def main():
    """Main function"""
    import argparse
    
    parser = argparse.ArgumentParser(description="Download dots.ocr model weights")
    parser.add_argument(
        "--model-path", 
        default=DEFAULT_MODEL_PATH,
        help=f"Path to save model weights (default: {DEFAULT_MODEL_PATH})"
    )
    parser.add_argument(
        "--hf-token",
        help="Hugging Face token for private repositories"
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Force redownload even if model exists"
    )
    parser.add_argument(
        "--verify-only",
        action="store_true",
        help="Only verify existing model, don't download"
    )
    
    args = parser.parse_args()
    
    # Create model directory
    model_path = Path(args.model_path)
    model_path.mkdir(parents=True, exist_ok=True)
    
    logger.info(f"Model path: {model_path.absolute()}")
    
    if args.verify_only:
        logger.info("Verifying existing model...")
        if verify_model(args.model_path):
            logger.info("✅ Model verification passed")
            return 0
        else:
            logger.error("❌ Model verification failed")
            return 1
    
    # Download model
    success = download_model_huggingface(
        args.model_path,
        args.hf_token,
        args.force
    )
    
    if not success:
        logger.error("❌ Model download failed")
        return 1
    
    # Verify downloaded model
    if verify_model(args.model_path):
        logger.info("✅ Model verification passed")
        create_model_info(args.model_path)
        
        # Print usage instructions
        print("\n" + "="*50)
        print("🎉 Model download completed successfully!")
        print("="*50)
        print(f"Model location: {Path(args.model_path).absolute()}")
        print("\nTo use the model:")
        print("1. Set environment variable:")
        print(f"   export MODEL_PATH={args.model_path}")
        print("\n2. Start the service:")
        print("   docker-compose up")
        print("\n3. Or run directly:")
        print("   python main.py")
        print("="*50)
        
        return 0
    else:
        logger.error("❌ Model verification failed")
        return 1


if __name__ == "__main__":
    sys.exit(main())

"""
Test suite for the document extraction service
"""

import json
import tempfile
from pathlib import Path
from unittest.mock import Mock, patch

import pytest
from fastapi.testclient import TestClient
from PIL import Image

# Import the main app
from main import app, Config


@pytest.fixture
def client():
    """Test client fixture"""
    return TestClient(app)


@pytest.fixture
def mock_model_and_processor():
    """Mock model and processor for testing"""
    with patch('main.model') as mock_model, \
         patch('main.processor') as mock_processor:
        
        # Setup mock processor
        mock_processor.apply_chat_template.return_value = "test prompt"
        mock_processor.return_value = Mock()
        mock_processor.batch_decode.return_value = ['{"elements": [{"bbox": [0, 0, 100, 100], "category": "text", "text": "Test content"}]}']
        
        # Setup mock model
        mock_model.generate.return_value = [[1, 2, 3, 4]]
        
        yield mock_model, mock_processor


@pytest.fixture
def sample_image():
    """Create a sample image file for testing"""
    with tempfile.NamedTemporaryFile(suffix='.png', delete=False) as tmp:
        img = Image.new('RGB', (100, 100), color='white')
        img.save(tmp.name)
        yield tmp.name
    Path(tmp.name).unlink()


class TestHealthEndpoint:
    """Tests for health check endpoint"""
    
    def test_health_check_no_model(self, client):
        """Test health check when model is not loaded"""
        response = client.get("/health")
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "healthy"
        assert data["model_loaded"] is False
        assert "device" in data
        assert "timestamp" in data


class TestExtractEndpoint:
    """Tests for document extraction endpoint"""
    
    def test_extract_no_model_loaded(self, client, sample_image):
        """Test extraction fails when model not loaded"""
        with open(sample_image, 'rb') as f:
            response = client.post(
                "/extract",
                files={"file": ("test.png", f, "image/png")},
                data={"prompt_mode": "prompt_layout_all_en"}
            )
        assert response.status_code == 503
        assert "Model not loaded" in response.json()["detail"]
    
    def test_extract_invalid_file_type(self, client, mock_model_and_processor):
        """Test extraction with unsupported file type"""
        with tempfile.NamedTemporaryFile(suffix='.txt', delete=False) as tmp:
            tmp.write(b"test content")
            tmp.flush()
            
            with open(tmp.name, 'rb') as f:
                response = client.post(
                    "/extract",
                    files={"file": ("test.txt", f, "text/plain")},
                    data={"prompt_mode": "prompt_layout_all_en"}
                )
        
        assert response.status_code == 400
        assert "Unsupported file type" in response.json()["detail"]
        Path(tmp.name).unlink()
    
    def test_extract_no_filename(self, client, mock_model_and_processor):
        """Test extraction with no filename"""
        response = client.post(
            "/extract",
            files={"file": ("", b"test content", "image/png")},
            data={"prompt_mode": "prompt_layout_all_en"}
        )
        assert response.status_code == 400
        assert "No filename provided" in response.json()["detail"]
    
    def test_extract_invalid_bbox(self, client, sample_image, mock_model_and_processor):
        """Test extraction with invalid bbox format"""
        with open(sample_image, 'rb') as f:
            response = client.post(
                "/extract",
                files={"file": ("test.png", f, "image/png")},
                data={
                    "prompt_mode": "prompt_grounding_ocr",
                    "bbox": "invalid,bbox,format"
                }
            )
        assert response.status_code == 400
        assert "Invalid bbox format" in response.json()["detail"]
    
    @patch('main.process_vision_info')
    def test_extract_success(self, mock_process_vision, client, sample_image, mock_model_and_processor):
        """Test successful extraction"""
        mock_model, mock_processor = mock_model_and_processor
        mock_process_vision.return_value = ([], [])
        
        # Mock the inputs object
        mock_inputs = Mock()
        mock_inputs.input_ids = [[1, 2, 3]]
        mock_inputs.to.return_value = mock_inputs
        mock_processor.return_value = mock_inputs
        
        with open(sample_image, 'rb') as f:
            response = client.post(
                "/extract",
                files={"file": ("test.png", f, "image/png")},
                data={"prompt_mode": "prompt_layout_all_en"}
            )
        
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "completed"
        assert data["filename"] == "test.png"
        assert data["file_type"] == ".png"
        assert "task_id" in data
        assert "processing_time" in data
        assert len(data["layout_elements"]) > 0


class TestDocumentExtractor:
    """Tests for DocumentExtractor class"""
    
    def test_parse_output_json_format(self):
        """Test parsing JSON output"""
        from main import DocumentExtractor
        
        extractor = DocumentExtractor(None, None)
        json_output = '{"elements": [{"bbox": [0, 0, 100, 100], "category": "text", "text": "Test"}]}'
        
        result = extractor._parse_output(json_output, "prompt_layout_all_en")
        assert result["format"] == "structured"
        assert len(result["layout_elements"]) == 1
        assert result["layout_elements"][0]["text"] == "Test"
    
    def test_parse_output_plain_text(self):
        """Test parsing plain text output"""
        from main import DocumentExtractor
        
        extractor = DocumentExtractor(None, None)
        text_output = "This is plain text output"
        
        result = extractor._parse_output(text_output, "prompt_ocr")
        assert result["format"] == "plain_text"
        assert len(result["layout_elements"]) == 1
        assert result["layout_elements"][0]["text"] == "This is plain text output"
    
    def test_generate_markdown(self):
        """Test markdown generation"""
        from main import DocumentExtractor
        
        extractor = DocumentExtractor(None, None)
        elements = [
            {"category": "title", "text": "Main Title"},
            {"category": "text", "text": "Some paragraph text"},
            {"category": "table", "text": "<table><tr><td>Cell</td></tr></table>"},
            {"category": "formula", "text": "E=mc^2"},
            {"category": "picture", "text": ""},  # Should be skipped
        ]
        
        markdown = extractor.generate_markdown(elements)
        assert "# Main Title" in markdown
        assert "Some paragraph text" in markdown
        assert "<table>" in markdown
        assert "$$E=mc^2$$" in markdown
        assert "picture" not in markdown.lower()


class TestPromptsEndpoint:
    """Tests for prompts endpoint"""
    
    def test_get_prompts(self, client):
        """Test getting available prompts"""
        response = client.get("/prompts")
        assert response.status_code == 200
        data = response.json()
        assert "prompts" in data
        assert "descriptions" in data
        assert "prompt_layout_all_en" in data["prompts"]


class TestTaskEndpoint:
    """Tests for task result endpoint"""
    
    def test_get_nonexistent_task(self, client):
        """Test getting non-existent task"""
        response = client.get("/task/nonexistent-task-id")
        assert response.status_code == 404
        assert "Task not found" in response.json()["detail"]


class TestConfiguration:
    """Tests for configuration"""
    
    def test_config_defaults(self):
        """Test default configuration values"""
        assert Config.MAX_FILE_SIZE == 50 * 1024 * 1024  # 50MB
        assert Config.MAX_NEW_TOKENS == 24000
        assert Config.ALLOWED_EXTENSIONS == {".pdf", ".png", ".jpg", ".jpeg", ".bmp", ".tiff"}
        assert Config.DEVICE in ["cuda", "cpu"]


class TestFileValidation:
    """Tests for file validation"""
    
    def test_validate_file_no_filename(self):
        """Test validation with no filename"""
        from main import validate_file
        from fastapi import HTTPException
        
        mock_file = Mock()
        mock_file.filename = None
        
        with pytest.raises(HTTPException) as exc_info:
            validate_file(mock_file)
        assert exc_info.value.status_code == 400
        assert "No filename provided" in str(exc_info.value.detail)
    
    def test_validate_file_unsupported_extension(self):
        """Test validation with unsupported file extension"""
        from main import validate_file
        from fastapi import HTTPException
        
        mock_file = Mock()
        mock_file.filename = "test.xyz"
        
        with pytest.raises(HTTPException) as exc_info:
            validate_file(mock_file)
        assert exc_info.value.status_code == 400
        assert "Unsupported file type" in str(exc_info.value.detail)
    
    def test_validate_file_success(self):
        """Test successful file validation"""
        from main import validate_file
        
        mock_file = Mock()
        mock_file.filename = "test.pdf"
        
        # Should not raise an exception
        validate_file(mock_file)


@pytest.mark.asyncio
class TestAsyncFunctions:
    """Tests for async functions"""
    
    async def test_save_upload_file(self):
        """Test saving upload file"""
        from main import save_upload_file
        from fastapi import UploadFile
        
        # Create mock upload file
        content = b"test file content"
        mock_file = Mock(spec=UploadFile)
        mock_file.filename = "test.pdf"
        mock_file.read = Mock(return_value=content)
        
        # Create temporary directory for uploads
        with tempfile.TemporaryDirectory() as temp_dir:
            Config.UPLOAD_DIR = temp_dir
            
            file_path = await save_upload_file(mock_file)
            
            assert file_path.exists()
            assert file_path.suffix == ".pdf"
            assert file_path.read_bytes() == content
    
    async def test_save_upload_file_too_large(self):
        """Test saving file that's too large"""
        from main import save_upload_file
        from fastapi import UploadFile, HTTPException
        
        # Create mock file that's too large
        large_content = b"x" * (Config.MAX_FILE_SIZE + 1)
        mock_file = Mock(spec=UploadFile)
        mock_file.filename = "large.pdf"
        mock_file.read = Mock(return_value=large_content)
        
        with tempfile.TemporaryDirectory() as temp_dir:
            Config.UPLOAD_DIR = temp_dir
            
            with pytest.raises(HTTPException) as exc_info:
                await save_upload_file(mock_file)
            assert exc_info.value.status_code == 413
            assert "File too large" in str(exc_info.value.detail)


if __name__ == "__main__":
    pytest.main([__file__])

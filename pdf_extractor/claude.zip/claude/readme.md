# Document Extraction Service

A production-grade PDF and image extraction service powered by [dots.ocr](https://github.com/rednote-hilab/dots.ocr), capable of processing complex documents with tables, images, architectural diagrams, and directional arrows between components.

## 🚀 Features

- **Multi-format Support**: PDF, PNG, JPG, JPEG, BMP, TIFF
- **Complex Document Processing**: Tables, formulas, architectural diagrams, component relationships
- **High Accuracy**: State-of-the-art performance with dots.ocr 1.7B parameter model
- **Production Ready**: Docker containerization, load balancing, monitoring
- **Scalable Architecture**: Async processing, configurable workers
- **Enterprise Standards**: Comprehensive logging, error handling, health checks

## 📋 Table of Contents

- [Prerequisites](#prerequisites)
- [Quick Start](#quick-start)
- [Model Setup](#model-setup)
- [Configuration](#configuration)
- [API Documentation](#api-documentation)
- [Deployment](#deployment)
- [Monitoring](#monitoring)
- [Development](#development)
- [Troubleshooting](#troubleshooting)

## 🔧 Prerequisites

### System Requirements

- **GPU**: NVIDIA GPU with 8GB+ VRAM (recommended)
- **RAM**: 16GB+ system memory
- **Storage**: 20GB+ free disk space
- **OS**: Linux (Ubuntu 20.04+ recommended)

### Software Requirements

- Docker 20.10+
- Docker Compose 2.0+
- NVIDIA Container Toolkit (for GPU support)
- Python 3.11+ (for local development)

### NVIDIA Container Toolkit Setup

```bash
# Ubuntu/Debian
curl -fsSL https://nvidia.github.io/libnvidia-container/gpgkey | sudo gpg --dearmor -o /usr/share/keyrings/nvidia-container-toolkit-keyring.gpg
curl -s -L https://nvidia.github.io/libnvidia-container/stable/deb/nvidia-container-toolkit.list | \
  sed 's#deb https://#deb [signed-by=/usr/share/keyrings/nvidia-container-toolkit-keyring.gpg] https://#g' | \
  sudo tee /etc/apt/sources.list.d/nvidia-container-toolkit.list

sudo apt-get update
sudo apt-get install -y nvidia-container-toolkit
sudo nvidia-ctk runtime configure --runtime=docker
sudo systemctl restart docker
```

## 🚀 Quick Start

### 1. Clone Repository

```bash
git clone <repository-url>
cd document-extraction-service
```

### 2. Download Model Weights

```bash
# Install requirements for download script
pip install huggingface-hub transformers

# Download model (requires ~8GB storage)
python download_models.py --model-path ./weights/DotsOCR

# Or with Hugging Face token for private access
python download_models.py --model-path ./weights/DotsOCR --hf-token YOUR_HF_TOKEN
```

### 3. Start Services

```bash
# Production deployment
docker-compose up -d

# Development with hot reload
docker-compose -f docker-compose.yml -f docker-compose.dev.yml up

# Check service health
curl http://localhost:8000/health
```

### 4. Test the Service

```bash
# Upload a document for extraction
curl -X POST "http://localhost:8000/extract" \
  -H "Content-Type: multipart/form-data" \
  -F "file=@sample.pdf" \
  -F "prompt_mode=prompt_layout_all_en"
```

## 📦 Model Setup

### Automatic Download

The easiest way to download the required model:

```bash
python download_models.py
```

### Manual Download

If you prefer manual setup:

```bash
# Using Hugging Face CLI
pip install huggingface_hub
huggingface-cli download rednote-hilab/dots.ocr --local-dir ./weights/DotsOCR

# Using Python
from huggingface_hub import snapshot_download
snapshot_download(
    repo_id="rednote-hilab/dots.ocr",
    local_dir="./weights/DotsOCR",
    local_dir_use_symlinks=False
)
```

### Model Verification

```bash
# Verify model integrity
python download_models.py --verify-only --model-path ./weights/DotsOCR
```

### Directory Structure

```
weights/
└── DotsOCR/
    ├── config.json
    ├── tokenizer_config.json
    ├── tokenizer.json
    ├── preprocessor_config.json
    ├── modeling_dots_ocr_vllm.py
    ├── configuration_dots_ocr.py
    └── pytorch_model.bin (or .safetensors files)
```

## ⚙️ Configuration

### Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `MODEL_PATH` | `./weights/DotsOCR` | Path to model weights |
| `MAX_FILE_SIZE` | `52428800` | Max upload size (50MB) |
| `MAX_NEW_TOKENS` | `24000` | Max tokens for generation |
| `GPU_MEMORY_UTILIZATION` | `0.8` | GPU memory usage ratio |
| `CUDA_VISIBLE_DEVICES` | `0` | GPU device selection |

### Docker Configuration

Create a `.env` file:

```env
MODEL_PATH=./weights/DotsOCR
MAX_FILE_SIZE=52428800
MAX_NEW_TOKENS=24000
GPU_MEMORY_UTILIZATION=0.8
CUDA_VISIBLE_DEVICES=0
```

### Production Tuning

For production environments, adjust these settings in `docker-compose.yml`:

```yaml
environment:
  - GPU_MEMORY_UTILIZATION=0.9  # Higher GPU usage
  - MAX_FILE_SIZE=104857600      # 100MB limit
deploy:
  resources:
    reservations:
      devices:
        - driver: nvidia
          count: 2              # Multiple GPUs
          capabilities: [gpu]
```

## 🌐 API Documentation

### Endpoints

#### Health Check
```http
GET /health
```
Returns service status and model loading state.

#### Document Extraction
```http
POST /extract
```
Extract content from uploaded documents.

**Parameters:**
- `file`: Document file (multipart/form-data)
- `prompt_mode`: Extraction mode (form parameter)
- `bbox`: Bounding box for region extraction (optional)
- `dpi`: PDF resolution (default: 200)

**Prompt Modes:**
- `prompt_layout_all_en`: Full layout detection and content recognition
- `prompt_layout_only_en`: Layout detection only
- `prompt_ocr`: Text extraction (excludes headers/footers)
- `prompt_grounding_ocr`: Extract from specific region (requires bbox)

#### Task Result
```http
GET /task/{task_id}
```
Retrieve extraction results by task ID.

#### Available Prompts
```http
GET /prompts
```
List available prompt modes and descriptions.

### Example Requests

#### Basic Document Extraction
```bash
curl -X POST "http://localhost:8000/extract" \
  -H "Content-Type: multipart/form-data" \
  -F "file=@document.pdf" \
  -F "prompt_mode=prompt_layout_all_en"
```

#### Region-specific Extraction
```bash
curl -X POST "http://localhost:8000/extract" \
  -H "Content-Type: multipart/form-data" \
  -F "file=@diagram.png" \
  -F "prompt_mode=prompt_grounding_ocr" \
  -F "bbox=100,200,500,400"
```

#### High-resolution PDF
```bash
curl -X POST "http://localhost:8000/extract" \
  -H "Content-Type: multipart/form-data" \
  -F "file=@technical_drawing.pdf" \
  -F "prompt_mode=prompt_layout_all_en" \
  -F "dpi=300"
```

### Response Format

```json
{
  "task_id": "uuid-string",
  "status": "completed",
  "filename": "document.pdf",
  "file_type": ".pdf",
  "processing_time": 15.23,
  "layout_elements": [
    {
      "bbox": [100, 200, 400, 300],
      "category": "Text",
      "text": "Extracted content...",
      "confidence": 0.95
    }
  ],
  "markdown_content": "# Processed Content\n\nText content...",
  "metadata": {
    "prompt_mode": "prompt_layout_all_en",
    "device": "cuda",
    "format": "structured"
  }
}
```

## 🚀 Deployment

### Production Deployment

#### 1. Prepare Environment
```bash
# Create data directories
mkdir -p data/uploads data/results logs/nginx

# Set permissions
chmod 755 data/uploads data/results logs
```

#### 2. Configure SSL (Optional)
```bash
mkdir -p nginx/ssl
# Place your SSL certificates in nginx/ssl/
# cert.pem and key.pem
```

#### 3. Deploy Services
```bash
docker-compose up -d
```

#### 4. Verify Deployment
```bash
# Check all services
docker-compose ps

# Test health endpoint
curl http://localhost/health

# View logs
docker-compose logs -f dots-ocr-service
```

### Scaling

#### Horizontal Scaling
```yaml
# docker-compose.yml
services:
  dots-ocr-service:
    deploy:
      replicas: 3
    # ... rest of configuration
```

#### Load Balancing
```nginx
# nginx.conf
upstream fastapi_backend {
    server dots-ocr-service-1:8000;
    server dots-ocr-service-2:8000;
    server dots-ocr-service-3:8000;
}
```

### Cloud Deployment

#### AWS ECS
```json
{
  "family": "dots-ocr-service",
  "taskRoleArn": "arn:aws:iam::account:role/ecsTaskRole",
  "requiresCompatibilities": ["EC2"],
  "placementConstraints": [
    {
      "type": "memberOf",
      "expression": "attribute:ecs.instance-type =~ g4dn.*"
    }
  ]
}
```

#### Kubernetes
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: dots-ocr-service
spec:
  replicas: 2
  selector:
    matchLabels:
      app: dots-ocr-service
  template:
    metadata:
      labels:
        app: dots-ocr-service
    spec:
      containers:
      - name: dots-ocr-service
        image: dots-ocr-service:latest
        resources:
          requests:
            nvidia.com/gpu: 1
          limits:
            nvidia.com/gpu: 1
```

## 📊 Monitoring

### Built-in Monitoring

The service includes Prometheus metrics and Grafana dashboards:

```bash
# Access monitoring
open http://localhost:3000  # Grafana (admin/admin123)
open http://localhost:9090  # Prometheus
```

### Custom Metrics

Monitor key performance indicators:

- Request latency and throughput
- GPU memory usage
- Processing queue depth
- Error rates by endpoint
- Model inference time

### Log Analysis

```bash
# Service logs
docker-compose logs -f dots-ocr-service

# Nginx access logs
docker-compose logs -f nginx

# System resources
docker stats
```

### Health Monitoring

```bash
# Automated health checks
curl -f http://localhost:8000/health || echo "Service unhealthy"

# Detailed status
curl http://localhost:8000/health | jq '.'
```

## 👨‍💻 Development

### Local Development Setup

```bash
# Create virtual environment
python3.11 -m venv venv
source venv/activate  # or `venv\Scripts\activate` on Windows

# Install dependencies
pip install -r requirements.txt -r requirements-dev.txt

# Download model
python download_models.py

# Run development server
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

### Development with Docker

```bash
# Development environment with hot reload
docker-compose -f docker-compose.yml -f docker-compose.dev.yml up

# Run tests
docker-compose exec dots-ocr-service pytest

# Format code
docker-compose exec dots-ocr-service black .
docker-compose exec dots-ocr-service isort .
```

### Testing

```bash
# Run all tests
pytest

# Run with coverage
pytest --cov=. --cov-report=html

# Test specific endpoint
pytest tests/test_extract.py -v
```

### Code Quality

```bash
# Pre-commit hooks
pre-commit install
pre-commit run --all-files

# Type checking
mypy main.py

# Linting
flake8 .
```

## 🛠️ Troubleshooting

### Common Issues

#### 1. Model Loading Fails
```bash
# Check model files
ls -la weights/DotsOCR/
python download_models.py --verify-only

# Check GPU availability
nvidia-smi
docker run --rm --gpus all nvidia/cuda:12.1-base-ubuntu22.04 nvidia-smi

# Check model path
export MODEL_PATH=./weights/DotsOCR
echo $MODEL_PATH
```

**Solutions:**
- Ensure model files are downloaded correctly
- Verify MODEL_PATH environment variable
- Check GPU driver compatibility
- Restart Docker daemon after NVIDIA toolkit installation

#### 2. Out of Memory Errors
```bash
# Monitor GPU memory
watch -n 1 nvidia-smi

# Check container memory limits
docker stats
```

**Solutions:**
- Reduce `GPU_MEMORY_UTILIZATION` (default: 0.8)
- Lower `MAX_NEW_TOKENS` for shorter outputs
- Process smaller batches or single files
- Use CPU-only mode for testing (slower)

#### 3. File Upload Issues
```bash
# Check file size limits
curl -X POST "http://localhost:8000/extract" \
  -F "file=@large_file.pdf" -v

# Test with smaller file
curl -X POST "http://localhost:8000/extract" \
  -F "file=@small_test.jpg"
```

**Solutions:**
- Increase `MAX_FILE_SIZE` in environment
- Check Nginx `client_max_body_size`
- Verify file format is supported
- Use lower DPI for large PDFs

#### 4. Docker Build Issues
```bash
# Clean Docker cache
docker system prune -a

# Build with no cache
docker-compose build --no-cache

# Check CUDA compatibility
docker run --rm --gpus all nvidia/cuda:12.1-base-ubuntu22.04 nvcc --version
```

#### 5. Permission Errors
```bash
# Fix file permissions
sudo chown -R $USER:$USER weights/ data/ logs/

# Check container user
docker-compose exec dots-ocr-service id
```

### Performance Optimization

#### GPU Optimization
```bash
# Monitor GPU utilization
nvidia-smi -l 1

# Optimize memory usage
export GPU_MEMORY_UTILIZATION=0.9
export PYTORCH_CUDA_ALLOC_CONF=max_split_size_mb:128
```

#### Processing Optimization
```yaml
# docker-compose.yml optimizations
environment:
  - OMP_NUM_THREADS=4
  - CUDA_LAUNCH_BLOCKING=0
  - TORCH_CUDNN_V8_API_ENABLED=1
```

#### Network Optimization
```nginx
# nginx.conf optimizations
proxy_buffering on;
proxy_cache_path /tmp/nginx_cache levels=1:2 keys_zone=cache:10m;
proxy_cache cache;
```

### Debugging

#### Enable Debug Logging
```bash
# In docker-compose.yml
environment:
  - LOG_LEVEL=DEBUG
  - CUDA_LAUNCH_BLOCKING=1  # For CUDA debugging
```

#### Container Debugging
```bash
# Access container shell
docker-compose exec dots-ocr-service bash

# Check Python environment
python -c "import torch; print(torch.cuda.is_available())"
python -c "import transformers; print(transformers.__version__)"

# Test model loading
python -c "
from transformers import AutoConfig
config = AutoConfig.from_pretrained('/app/weights/DotsOCR', trust_remote_code=True)
print('Model loaded successfully')
"
```

#### Log Analysis
```bash
# Follow service logs
docker-compose logs -f dots-ocr-service | grep ERROR

# Check specific error patterns
docker-compose logs dots-ocr-service | grep -E "(CUDA|Memory|Error)"

# Export logs for analysis
docker-compose logs dots-ocr-service > service_logs.txt
```

## 🔧 Advanced Configuration

### Custom Prompts

You can extend the service with custom prompts by modifying the `dict_promptmode_to_prompt` mapping:

```python
# Custom prompt for architectural diagrams
CUSTOM_ARCHITECTURE_PROMPT = """
Analyze this architectural diagram and extract:
1. Component names and their bounding boxes
2. Connection arrows and their directions
3. Labels and annotations
4. Hierarchical relationships

Format the output as structured JSON with components, connections, and metadata.
"""
```

### Multi-GPU Setup

```yaml
# docker-compose.yml for multi-GPU
services:
  dots-ocr-service:
    environment:
      - CUDA_VISIBLE_DEVICES=0,1,2,3
    deploy:
      resources:
        reservations:
          devices:
            - driver: nvidia
              count: 4
              capabilities: [gpu]
```

### Custom Model Integration

```python
# Extend the service for custom models
class CustomModelExtractor(DocumentExtractor):
    def __init__(self, model_path: str):
        # Load your custom model
        self.custom_model = load_custom_model(model_path)
        super().__init__(self.custom_model, processor)
```

## 📚 API Reference

### Complete OpenAPI Schema

The service automatically generates OpenAPI documentation available at:
- Interactive docs: `http://localhost:8000/docs`
- ReDoc: `http://localhost:8000/redoc`
- OpenAPI JSON: `http://localhost:8000/openapi.json`

### Rate Limiting

Default rate limits (configured in Nginx):
- API endpoints: 10 requests/second
- Upload endpoint: 2 requests/second
- Burst allowance: 20 requests (API), 5 requests (upload)

### Authentication (Optional)

To add authentication, extend the service with:

```python
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer

security = HTTPBearer()

async def verify_token(token: str = Depends(security)):
    # Implement your token verification logic
    if not verify_jwt_token(token.credentials):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authentication token"
        )
    return token
```

## 🤝 Contributing

### Development Workflow

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/your-feature`
3. Make changes and add tests
4. Run quality checks: `pre-commit run --all-files`
5. Submit a pull request

### Code Standards

- Follow PEP 8 style guidelines
- Add type hints for all functions
- Write docstrings for public APIs
- Maintain test coverage above 80%
- Update documentation for new features

### Testing Guidelines

```bash
# Run full test suite
pytest tests/ -v

# Test specific functionality
pytest tests/test_extraction.py::test_pdf_processing -v

# Performance testing
pytest tests/test_performance.py --benchmark-only
```

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- [dots.ocr](https://github.com/rednote-hilab/dots.ocr) - The core OCR model
- [Qwen2.5-VL](https://github.com/QwenLM/Qwen2.5-VL) - Base vision-language model
- [FastAPI](https://fastapi.tiangolo.com/) - Modern web framework
- [Transformers](https://huggingface.co/transformers) - Machine learning library

## 📞 Support

### Documentation
- [API Documentation](http://localhost:8000/docs) (when service is running)
- [Model Documentation](https://github.com/rednote-hilab/dots.ocr)

### Community
- [Issues](https://github.com/your-repo/issues) - Bug reports and feature requests
- [Discussions](https://github.com/your-repo/discussions) - Questions and community chat

### Enterprise Support
For enterprise support, custom deployments, or consulting services, please contact [your-email@company.com].

---

**⚡ Quick Commands Reference:**

```bash
# Setup
python download_models.py
docker-compose up -d

# Development  
docker-compose -f docker-compose.yml -f docker-compose.dev.yml up
pytest

# Production
docker-compose up -d --scale dots-ocr-service=3
curl http://localhost/health

# Monitoring
docker-compose logs -f
open http://localhost:3000  # Grafana
```
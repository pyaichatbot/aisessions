"""
Production-grade PDF and Image extraction service using dots.ocr
Supports complex documents with tables, images, and architectural diagrams
"""

import asyncio
import json
import logging
import os
import tempfile
import uuid
from contextlib import asynccontextmanager
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

import aiofiles
import torch
import uvicorn
from fastapi import FastAPI, File, Form, HTTPException, UploadFile, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from transformers import AutoModelForCausalLM, AutoProcessor

from dots_ocr.utils import dict_promptmode_to_prompt
from qwen_vl_utils import process_vision_info


# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

# Configuration
class Config:
    MODEL_PATH = os.getenv("MODEL_PATH", "./weights/DotsOCR")
    MAX_FILE_SIZE = int(os.getenv("MAX_FILE_SIZE", 50 * 1024 * 1024))  # 50MB
    MAX_NEW_TOKENS = int(os.getenv("MAX_NEW_TOKENS", 24000))
    UPLOAD_DIR = "./uploads"
    RESULTS_DIR = "./results"
    ALLOWED_EXTENSIONS = {".pdf", ".png", ".jpg", ".jpeg", ".bmp", ".tiff"}
    
    # GPU Configuration
    DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
    GPU_MEMORY_UTILIZATION = float(os.getenv("GPU_MEMORY_UTILIZATION", 0.8))


# Pydantic Models
class ExtractionRequest(BaseModel):
    """Request model for document extraction"""
    prompt_mode: str = Field(
        default="prompt_layout_all_en",
        description="Prompt mode for extraction",
        examples=["prompt_layout_all_en", "prompt_layout_only_en", "prompt_ocr"]
    )
    bbox: Optional[List[int]] = Field(
        default=None,
        description="Bounding box for grounding OCR [x1, y1, x2, y2]",
        min_items=4,
        max_items=4
    )
    dpi: int = Field(
        default=200,
        description="DPI for PDF parsing",
        ge=72,
        le=600
    )


class LayoutElement(BaseModel):
    """Layout element from extraction"""
    bbox: List[int] = Field(description="Bounding box [x1, y1, x2, y2]")
    category: str = Field(description="Layout category")
    text: Optional[str] = Field(default=None, description="Extracted text content")
    confidence: Optional[float] = Field(default=None, description="Confidence score")


class ExtractionResponse(BaseModel):
    """Response model for successful extraction"""
    task_id: str = Field(description="Unique task identifier")
    status: str = Field(description="Processing status")
    filename: str = Field(description="Original filename")
    file_type: str = Field(description="File type")
    processing_time: float = Field(description="Processing time in seconds")
    layout_elements: List[LayoutElement] = Field(description="Extracted layout elements")
    markdown_content: Optional[str] = Field(default=None, description="Markdown representation")
    metadata: Dict[str, Any] = Field(description="Additional metadata")


class ErrorResponse(BaseModel):
    """Error response model"""
    error: str = Field(description="Error message")
    details: Optional[str] = Field(default=None, description="Error details")
    task_id: Optional[str] = Field(default=None, description="Task ID if applicable")


class HealthResponse(BaseModel):
    """Health check response"""
    status: str = Field(description="Service status")
    model_loaded: bool = Field(description="Whether model is loaded")
    device: str = Field(description="Device being used")
    timestamp: datetime = Field(description="Current timestamp")


# Global model instance
model = None
processor = None


class DocumentExtractor:
    """Main document extraction class"""
    
    def __init__(self, model_instance, processor_instance):
        self.model = model_instance
        self.processor = processor_instance
        
    async def extract_from_file(
        self,
        file_path: Path,
        prompt_mode: str = "prompt_layout_all_en",
        bbox: Optional[List[int]] = None,
        dpi: int = 200
    ) -> Dict[str, Any]:
        """Extract content from file"""
        try:
            # Determine the prompt based on mode and bbox
            if bbox and prompt_mode == "prompt_grounding_ocr":
                prompt = self._get_grounding_prompt(bbox)
            else:
                prompt = dict_promptmode_to_prompt.get(
                    prompt_mode,
                    dict_promptmode_to_prompt["prompt_layout_all_en"]
                )
            
            # Create messages for the model
            messages = [
                {
                    "role": "user",
                    "content": [
                        {"type": "image", "image": str(file_path)},
                        {"type": "text", "text": prompt}
                    ]
                }
            ]
            
            # Process with the model
            text = self.processor.apply_chat_template(
                messages, tokenize=False, add_generation_prompt=True
            )
            
            image_inputs, video_inputs = process_vision_info(messages)
            inputs = self.processor(
                text=[text],
                images=image_inputs,
                videos=video_inputs,
                padding=True,
                return_tensors="pt",
            )
            
            inputs = inputs.to(Config.DEVICE)
            
            # Generate output
            with torch.no_grad():
                generated_ids = self.model.generate(
                    **inputs, 
                    max_new_tokens=Config.MAX_NEW_TOKENS,
                    do_sample=False,
                    temperature=0.0
                )
            
            generated_ids_trimmed = [
                out_ids[len(in_ids):] 
                for in_ids, out_ids in zip(inputs.input_ids, generated_ids)
            ]
            
            output_text = self.processor.batch_decode(
                generated_ids_trimmed, 
                skip_special_tokens=True, 
                clean_up_tokenization_spaces=False
            )[0]
            
            # Parse the output
            return self._parse_output(output_text, prompt_mode)
            
        except Exception as e:
            logger.error(f"Error extracting from file {file_path}: {str(e)}")
            raise
    
    def _get_grounding_prompt(self, bbox: List[int]) -> str:
        """Get grounding OCR prompt with bbox"""
        return f"""Please extract the text content from the specified region in the image.
        
Region coordinates (bbox): [{bbox[0]}, {bbox[1]}, {bbox[2]}, {bbox[3]}]
Format: [x1, y1, x2, y2]

Please provide only the text content from this region."""
    
    def _parse_output(self, output_text: str, prompt_mode: str) -> Dict[str, Any]:
        """Parse the model output into structured format"""
        try:
            # Try to parse as JSON first
            if output_text.strip().startswith('{'):
                json_data = json.loads(output_text.strip())
                layout_elements = []
                
                # Convert to standardized format
                if isinstance(json_data, list):
                    for item in json_data:
                        layout_elements.append({
                            "bbox": item.get("bbox", []),
                            "category": item.get("category", "unknown"),
                            "text": item.get("text"),
                            "confidence": item.get("confidence")
                        })
                elif isinstance(json_data, dict):
                    # Handle single element or nested structure
                    elements = json_data.get("elements", [json_data])
                    for item in elements:
                        layout_elements.append({
                            "bbox": item.get("bbox", []),
                            "category": item.get("category", "unknown"),
                            "text": item.get("text"),
                            "confidence": item.get("confidence")
                        })
                
                return {
                    "layout_elements": layout_elements,
                    "raw_output": output_text,
                    "format": "structured"
                }
            else:
                # Handle plain text output
                return {
                    "layout_elements": [{
                        "bbox": [],
                        "category": "text",
                        "text": output_text.strip(),
                        "confidence": None
                    }],
                    "raw_output": output_text,
                    "format": "plain_text"
                }
                
        except json.JSONDecodeError:
            logger.warning("Failed to parse JSON output, treating as plain text")
            return {
                "layout_elements": [{
                    "bbox": [],
                    "category": "text", 
                    "text": output_text.strip(),
                    "confidence": None
                }],
                "raw_output": output_text,
                "format": "plain_text"
            }
    
    def generate_markdown(self, layout_elements: List[Dict]) -> str:
        """Generate markdown from layout elements"""
        markdown_parts = []
        
        for element in layout_elements:
            category = element.get("category", "").lower()
            text = element.get("text", "").strip()
            
            if not text or category in ["picture", "page-header", "page-footer"]:
                continue
                
            if category == "title":
                markdown_parts.append(f"# {text}\n")
            elif category == "section-header":
                markdown_parts.append(f"## {text}\n")
            elif category == "table":
                # Text should already be in HTML format for tables
                markdown_parts.append(f"{text}\n")
            elif category == "formula":
                # Text should already be in LaTeX format
                markdown_parts.append(f"$${text}$$\n")
            elif category == "list-item":
                markdown_parts.append(f"- {text}\n")
            else:
                # Default to paragraph
                markdown_parts.append(f"{text}\n")
        
        return "\n".join(markdown_parts)


# Initialize directories
def init_directories():
    """Initialize required directories"""
    for dir_path in [Config.UPLOAD_DIR, Config.RESULTS_DIR]:
        Path(dir_path).mkdir(parents=True, exist_ok=True)


async def load_model():
    """Load the dots.ocr model"""
    global model, processor
    
    try:
        logger.info(f"Loading model from {Config.MODEL_PATH}")
        
        model = AutoModelForCausalLM.from_pretrained(
            Config.MODEL_PATH,
            attn_implementation="flash_attention_2",
            torch_dtype=torch.bfloat16,
            device_map="auto",
            trust_remote_code=True
        )
        
        processor = AutoProcessor.from_pretrained(
            Config.MODEL_PATH, 
            trust_remote_code=True
        )
        
        logger.info(f"Model loaded successfully on {Config.DEVICE}")
        
    except Exception as e:
        logger.error(f"Failed to load model: {str(e)}")
        raise


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan events"""
    # Startup
    init_directories()
    await load_model()
    logger.info("Service started successfully")
    yield
    # Shutdown
    logger.info("Service shutting down")


# Initialize FastAPI app
app = FastAPI(
    title="Document Extraction Service",
    description="Production-grade PDF and Image extraction using dots.ocr",
    version="1.0.0",
    lifespan=lifespan
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


def validate_file(file: UploadFile) -> None:
    """Validate uploaded file"""
    if not file.filename:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No filename provided"
        )
    
    file_extension = Path(file.filename).suffix.lower()
    if file_extension not in Config.ALLOWED_EXTENSIONS:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Unsupported file type. Allowed: {Config.ALLOWED_EXTENSIONS}"
        )


async def save_upload_file(file: UploadFile) -> Path:
    """Save uploaded file temporarily"""
    file_extension = Path(file.filename).suffix
    temp_filename = f"{uuid.uuid4()}{file_extension}"
    file_path = Path(Config.UPLOAD_DIR) / temp_filename
    
    async with aiofiles.open(file_path, 'wb') as f:
        content = await file.read()
        if len(content) > Config.MAX_FILE_SIZE:
            raise HTTPException(
                status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                detail=f"File too large. Max size: {Config.MAX_FILE_SIZE} bytes"
            )
        await f.write(content)
    
    return file_path


@app.get("/health", response_model=HealthResponse)
async def health_check():
    """Health check endpoint"""
    return HealthResponse(
        status="healthy",
        model_loaded=model is not None and processor is not None,
        device=Config.DEVICE,
        timestamp=datetime.utcnow()
    )


@app.post("/extract", response_model=ExtractionResponse)
async def extract_document(
    file: UploadFile = File(..., description="Document file to extract"),
    prompt_mode: str = Form(
        default="prompt_layout_all_en",
        description="Extraction prompt mode"
    ),
    bbox: Optional[str] = Form(
        default=None,
        description="Bounding box as comma-separated values: x1,y1,x2,y2"
    ),
    dpi: int = Form(
        default=200,
        description="DPI for PDF parsing"
    )
):
    """Extract content from uploaded document"""
    if model is None or processor is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Model not loaded"
        )
    
    task_id = str(uuid.uuid4())
    start_time = datetime.utcnow()
    
    try:
        # Validate file
        validate_file(file)
        
        # Parse bbox if provided
        bbox_list = None
        if bbox:
            try:
                bbox_list = [int(x.strip()) for x in bbox.split(',')]
                if len(bbox_list) != 4:
                    raise ValueError("Bbox must have 4 values")
            except (ValueError, AttributeError) as e:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Invalid bbox format: {str(e)}"
                )
        
        # Save uploaded file
        file_path = await save_upload_file(file)
        
        try:
            # Extract content
            extractor = DocumentExtractor(model, processor)
            result = await extractor.extract_from_file(
                file_path=file_path,
                prompt_mode=prompt_mode,
                bbox=bbox_list,
                dpi=dpi
            )
            
            # Generate markdown
            markdown_content = extractor.generate_markdown(
                result["layout_elements"]
            )
            
            # Calculate processing time
            processing_time = (datetime.utcnow() - start_time).total_seconds()
            
            # Save results
            result_path = Path(Config.RESULTS_DIR) / f"{task_id}.json"
            async with aiofiles.open(result_path, 'w') as f:
                await f.write(json.dumps({
                    "task_id": task_id,
                    "filename": file.filename,
                    "result": result,
                    "markdown_content": markdown_content,
                    "processing_time": processing_time
                }, indent=2))
            
            return ExtractionResponse(
                task_id=task_id,
                status="completed",
                filename=file.filename,
                file_type=Path(file.filename).suffix,
                processing_time=processing_time,
                layout_elements=[
                    LayoutElement(**element) for element in result["layout_elements"]
                ],
                markdown_content=markdown_content,
                metadata={
                    "prompt_mode": prompt_mode,
                    "bbox": bbox_list,
                    "dpi": dpi,
                    "device": Config.DEVICE,
                    "format": result.get("format", "unknown")
                }
            )
            
        finally:
            # Clean up temporary file
            if file_path.exists():
                file_path.unlink()
                
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error processing task {task_id}: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Processing failed: {str(e)}"
        )


@app.get("/task/{task_id}")
async def get_task_result(task_id: str):
    """Get task result by ID"""
    result_path = Path(Config.RESULTS_DIR) / f"{task_id}.json"
    
    if not result_path.exists():
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Task not found"
        )
    
    async with aiofiles.open(result_path, 'r') as f:
        content = await f.read()
        return json.loads(content)


@app.get("/prompts")
async def get_available_prompts():
    """Get available prompt modes"""
    return {
        "prompts": list(dict_promptmode_to_prompt.keys()),
        "descriptions": {
            "prompt_layout_all_en": "Full layout detection and content recognition",
            "prompt_layout_only_en": "Layout detection only",
            "prompt_ocr": "Text extraction only (excludes headers/footers)",
            "prompt_grounding_ocr": "Text extraction from specific region (requires bbox)"
        }
    }


if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=False,
        workers=1  # Single worker due to model loading
    )

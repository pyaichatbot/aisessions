# Session 6 Demo — Agents Deep Dive

This is a **beginner-friendly** yet **enterprise-clean** demo showing an Agent that can **plan → select a tool → act → respond**.

It exposes both a **CLI** and a **FastAPI service** so you can present easily on Windows with Docker.

## 🧠 What it shows
- Router (very simple) that decides whether to call the **calculator** or **weather** tool.
- Tools are cleanly separated under `agents/tools/`.
- API returns a structured trace of the **agent steps** so you can explain the loop.

## 🚀 Quick start (Docker)
```bash
docker compose up --build
```
Open the API docs at: http://localhost:8080/docs

Example curl:
```bash
curl -s -X POST "http://localhost:8080/chat" -H "Content-Type: application/json"   -d '{ "message": "What is 12 * 7 + 5?" }' | jq
```

Another example:
```bash
curl -s -X POST "http://localhost:8080/chat" -H "Content-Type: application/json"   -d '{ "message": "weather in berlin today" }' | jq
```

## 🖥️ CLI (optional)
```bash
python -m src.run_cli
```

## 🗂️ Structure
```
src/
  agents/
    core/agent.py       # agent loop (plan → act → respond)
    tools/calculator.py # safe eval (+,-,*,/)
    tools/weather.py    # mocked weather tool (no internet)
api/
  main.py               # FastAPI app
Dockerfile
docker-compose.yml
requirements.txt
```

## 🔐 Notes
- No external API keys needed. Weather is **mocked** to keep the demo stable offline.
- For enterprise sessions, replace `weather.py` with a real HTTP call and show the diff.

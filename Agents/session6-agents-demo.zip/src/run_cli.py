from agents.core.agent import run_agent

def main():
    print("Agents Demo (calculator + weather) — type 'exit' to quit\n")
    while True:
        msg = input("> ").strip()
        if msg.lower() in {"exit", "quit"}:
            break
        result = run_agent(msg)
        print("Answer:", result["answer"])
        print("Trace:")
        for ev in result["trace"]:
            print(" -", ev["type"], ev["data"])  # simple pretty print
        print()

if __name__ == "__main__":
    main()

from __future__ import annotations
from dataclasses import dataclass
from typing import Dict

# Mocked dataset (kept simple and deterministic for demo)
MOCK_WEATHER: Dict[str, Dict[str, str]] = {
    "berlin": {"today": "18°C, cloudy", "tomorrow": "20°C, light rain"},
    "frankfurt": {"today": "21°C, sunny", "tomorrow": "22°C, sunny"},
    "munich": {"today": "19°C, showers", "tomorrow": "17°C, cloudy"},
    "hyderabad": {"today": "31°C, humid", "tomorrow": "32°C, hot"},
}

def get_weather(city: str, day: str = "today") -> str:
    city_key = city.strip().lower()
    day_key = day.strip().lower()
    data = MOCK_WEATHER.get(city_key)
    if not data:
        return f"No weather data for {city}"
    return data.get(day_key, f"No {day} forecast for {city}")

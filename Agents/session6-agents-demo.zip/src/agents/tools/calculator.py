from __future__ import annotations
from typing import List

ALLOWED = set("0123456789+-*/(). ")

class CalcError(Exception):
    pass

def sanitize(expr: str) -> str:
    if not expr or any(ch not in ALLOWED for ch in expr):
        raise CalcError("Invalid characters in expression")
    return expr

def calculate(expression: str) -> float:
    expr = sanitize(expression)
    # Very small safe eval: only numbers and operators
    try:
        # Evaluate using Python's eval with restricted globals/locals
        result = eval(expr, {"__builtins__": None}, {})
    except ZeroDivisionError:
        raise CalcError("Division by zero")
    except Exception as e:
        raise CalcError(f"Invalid expression: {e}")
    if not isinstance(result, (int, float)):
        raise CalcError("Expression did not return a number")
    return float(result)

from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Dict, List, Optional
from agents.tools.calculator import calculate, CalcError
from agents.tools.weather import get_weather

@dataclass
class AgentEvent:
    type: str
    data: Dict[str, Any]

def plan(message: str) -> Dict[str, Any]:
    msg = message.lower().strip()
    # Extremely simple planner for the demo
    if any(k in msg for k in [" + ", " - ", " * ", " / "]) or any(ch in msg for ch in "+-*/"):
        return {"tool": "calculator", "args": {"expression": extract_expression(msg)}}
    if "weather" in msg or "forecast" in msg:
        city = extract_city(msg) or "berlin"
        day = "tomorrow" if "tomorrow" in msg else "today"
        return {"tool": "weather", "args": {"city": city, "day": day}}
    return {"tool": None, "args": {}}

def extract_expression(msg: str) -> str:
    # naive extraction: keep digits, operators and parentheses
    allowed = set("0123456789+-*/(). ")
    return "".join(ch for ch in msg if ch in allowed).strip()

def extract_city(msg: str) -> Optional[str]:
    for city in ["berlin", "frankfurt", "munich", "hyderabad"]:
        if city in msg:
            return city
    return None

def run_agent(message: str) -> Dict[str, Any]:
    events: List[AgentEvent] = []
    events.append(AgentEvent(type="plan", data={"message": message}))
    decision = plan(message)
    events.append(AgentEvent(type="decision", data=decision))

    tool = decision.get("tool")
    args = decision.get("args", {})

    if tool == "calculator":
        try:
            result = calculate(args.get("expression", ""))
            events.append(AgentEvent(type="tool_result", data={"tool": tool, "result": result}))
            answer = f"Result: {result:g}"
        except CalcError as e:
            answer = f"Calculator error: {e}"
    elif tool == "weather":
        city = args.get("city", "berlin")
        day = args.get("day", "today")
        info = get_weather(city, day)
        events.append(AgentEvent(type="tool_result", data={"tool": tool, "result": info}))
        answer = f"Weather in {city.title()} {day}: {info}"
    else:
        answer = "This looks like a general knowledge question. In this demo, only calculator and weather tools are wired."

    events.append(AgentEvent(type="final", data={"answer": answer}))
    # Serialize
    return {
        "trace": [{"type": e.type, "data": e.data} for e in events],
        "answer": answer,
    }

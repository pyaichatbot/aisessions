from fastapi import FastAPI
from pydantic import BaseModel
from agents.core.agent import run_agent

app = FastAPI(title="Session 6 – Agents Demo", version="1.0.0")

class ChatIn(BaseModel):
    message: str

@app.post("/chat")
def chat(payload: ChatIn):
    return run_agent(payload.message)

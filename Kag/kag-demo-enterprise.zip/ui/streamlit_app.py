import os, httpx, streamlit as st

API_URL = os.getenv('API_URL', 'http://localhost:8000')

st.set_page_config(page_title='Enterprise KAG (Chroma + Neo4j)', layout='wide')
st.title('Knowledge-Augmented Generation — Enterprise Demo')

with st.sidebar:
    st.header('Upload document')
    up = st.file_uploader('PDF / MD / TXT', type=['pdf','md','txt'])
    user = st.text_input('User / Session', 'default')
    if st.button('Upload & Ingest', disabled=not up):
        files = {'file': (up.name, up.getvalue(), up.type or 'application/octet-stream')}
        data = {'user': user}
        with st.spinner('Uploading & indexing...'):
            r = httpx.post(f'{API_URL}/upload', files=files, data=data, timeout=180.0)
            st.success(r.json())

    if st.button('Reset indexes & graph'):
        with st.spinner('Resetting...'):
            r = httpx.post(f'{API_URL}/ingest/reset', timeout=60.0)
            st.success(r.json())

st.subheader('Ask a question')
q = st.text_input('Question', 'What documents are required for merchant onboarding?')
go = st.button('Run')
if go:
    with st.spinner('Querying...'):
        r = httpx.post(f'{API_URL}/query', json={'question': q, 'user': user}, timeout=180.0)
        data = r.json()

    st.markdown('### Orchestration')
    cols = st.columns(3)
    cols[0].metric('ARAG Route', data.get('route','-'))
    cr = data.get('crag',{})
    cols[1].metric('CRAG (vector kept)', f"{cr.get('vector_after',0)} / {cr.get('vector_before',0)}")
    cols[2].metric('CRAG (graph kept)', f"{cr.get('graph_after',0)} / {cr.get('graph_before',0)}")

    st.markdown('### KAG Answer')
    st.code(data.get('answer',''), language='markdown')

    c1, c2 = st.columns(2)
    with c1:
        st.markdown('#### Citations (Vector)')
        st.json(data.get('citations', []))
    with c2:
        st.markdown('#### Graph Triples')
        st.table(data.get('graph_paths', []))

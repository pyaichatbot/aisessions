# Operations Handbook

## Document Checklist
- Government ID
- Business registration
- Bank statement (last 3 months)

## Approval Workflow
Analyst review -> Compliance sign-off -> Account provisioning

# Merchant Onboarding Policy

## KYC Requirements
Merchants must submit government-issued ID, business registration, and bank statements.

## Risk Limits
Default monthly processing limit is 100,000 USD. Higher limits require enhanced due diligence (EDD).

## Compliance
All onboarding must adhere to AML and sanctions screening policies.

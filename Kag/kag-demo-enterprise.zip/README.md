# KAG Demo — Enterprise Edition (Chroma + Neo4j + ARAG + CRAG + KAG)

This reference demo implements an enterprise-style **Knowledge-Augmented Generation** stack:
- **Upload** PDF/MD/TXT → preprocessing (extract, chunk, dedup)
- **Vector** indexing in **Chroma**
- **Knowledge Graph** in **Neo4j** (entities + co-mention relations)
- **ARAG** router: Vector / Graph / Hybrid
- **CRAG** corrective filter: cosine threshold on chunks, lexical filter on triples
- **KAG** synthesis: pluggable `LLMWrapper` (use your local LLM)

## Run with Docker Compose
```bash
docker compose up --build
# UI:    http://localhost:8501
# API:   http://localhost:8000/docs
# Neo4j: http://localhost:7474  (neo4j / password)
```
Then open the UI and:
1) Upload docs in the left panel
2) Ask questions in the main panel

## Local run (no containers)
```bash
python -m venv .venv && . .venv/Scripts/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
streamlit run ui/streamlit_app.py
```

## Mermaid (ingestion + query)
```mermaid
flowchart LR
  subgraph Ingestion
    U[Upload] --> P[Preprocess: extract, chunk, dedup]
    P --> V[(Chroma Vector DB)]
    P --> G[(Neo4j Graph)]
  end

  Q[User Query] --> R[ARAG Router]
  R -->|vector| VR[Vector Retrieve]
  R -->|graph| GR[Graph Retrieve]
  R -->|hybrid| VR & GR
  VR & GR --> C[CRAG Filter]
  C --> S[KAG Synthesis (LLMWrapper)]
  S --> A[Answer + Citations + Graph Triples]
```

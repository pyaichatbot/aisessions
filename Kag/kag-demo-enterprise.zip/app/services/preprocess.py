import os, io
from typing import List, Tuple
from dataclasses import dataclass
from PyPDF2 import PdfReader

@dataclass
class Chunk:
    text: str
    file: str
    section: str
    offset: int

def extract(file_bytes: bytes, filename: str) -> Tuple[str, dict]:
    name = filename or 'Document'
    ext = os.path.splitext(name)[1].lower()
    meta = {'file': name}
    if ext in ['.md', '.txt']:
        txt = file_bytes.decode('utf-8', errors='ignore')
    elif ext == '.pdf':
        pdf = PdfReader(io.BytesIO(file_bytes))
        pages = [p.extract_text() or '' for p in pdf.pages]
        txt = '\n\n'.join(pages)
    else:
        txt = file_bytes.decode('utf-8', errors='ignore')
    return txt, meta

def _split_into_chunks(text: str, file: str, max_tokens: int = 350, overlap: int = 40) -> List[Chunk]:
    words = text.split()
    chunks, i, offset = [], 0, 0
    while i < len(words):
        j = min(len(words), i + max_tokens)
        chunk_text = ' '.join(words[i:j])
        chunks.append(Chunk(text=chunk_text, file=file, section='', offset=offset))
        offset += len(chunk_text)
        i = j - overlap
        if i <= 0:
            i = j
    return chunks

def chunk(content: str, filename: str, max_tokens: int, overlap: int) -> List[Chunk]:
    content = (content or '').strip()
    if not content:
        return []
    return _split_into_chunks(content, filename, max_tokens, overlap)

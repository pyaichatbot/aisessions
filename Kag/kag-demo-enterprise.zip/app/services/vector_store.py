from typing import List, Dict, Any
from chromadb import PersistentClient
from llama_index.vector_stores.chroma import ChromaVectorStore
from llama_index.core import VectorStoreIndex, Document, Settings
from llama_index.embeddings.huggingface import HuggingFaceEmbedding
from .preprocess import Chunk
from ..utils.config import CHROMA_PATH

class VectorStore:
    def __init__(self, path: str = CHROMA_PATH):
        self.client = PersistentClient(path=path)
        self.collection = self.client.get_or_create_collection('kag_collection')
        self.store = ChromaVectorStore(chroma_collection=self.collection)
        self.embed = HuggingFaceEmbedding('sentence-transformers/all-MiniLM-L6-v2')
        Settings.embed_model = self.embed
        self.index = None

    def reset(self):
        self.client.delete_collection('kag_collection')
        self.collection = self.client.get_or_create_collection('kag_collection')
        self.store = ChromaVectorStore(chroma_collection=self.collection)
        self.index = None

    def index_chunks(self, chunks: List[Chunk], user: str = 'default'):
        docs = []
        for c in chunks:
            meta = {'file': c.file, 'section': c.section, 'user': user, 'offset': c.offset}
            docs.append(Document(text=c.text, metadata=meta))
        if not docs:
            return 0
        if self.index is None:
            self.index = VectorStoreIndex.from_documents(docs, vector_store=self.store, embed_model=self.embed)
        else:
            self.index.insert_documents(docs)
        return len(docs)

    def query(self, question: str, top_k: int = 6, user: str = 'default') -> List[Dict[str, Any]]:
        if self.index is None:
            self.index = VectorStoreIndex.from_vector_store(self.store, embed_model=self.embed)
        qe = self.index.as_query_engine(similarity_top_k=top_k)
        res = qe.query(question)
        hits = []
        try:
            for sn in getattr(res, 'source_nodes', []) or []:
                m = sn.metadata or {}
                if m.get('user') != user:
                    continue
                hits.append({'file': m.get('file','Document'), 'section': m.get('section',''), 'text': sn.text or '', 'score': float(m.get('score', 0.0))})
        except Exception:
            hits.append({'file':'Document','text':str(res),'score':0.0})
        return hits[:top_k]

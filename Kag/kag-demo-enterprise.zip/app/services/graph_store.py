from typing import List, Dict, Any
from neo4j import GraphDatabase
from ..utils.config import NEO4J_URI, NEO4J_USER, NEO4J_PASS

class GraphStore:
    def __init__(self):
        self.driver = GraphDatabase.driver(NEO4J_URI, auth=(NEO4J_USER, NEO4J_PASS))

    def reset(self):
        with self.driver.session() as s:
            s.run('MATCH (n) DETACH DELETE n')

    def add_doc_entities(self, file: str, entities: List[str], user: str = 'default'):
        with self.driver.session() as s:
            s.run('MERGE (u:User {id:$u})', u=user)
            s.run('MERGE (d:Document {name:$f, user:$u})', f=file, u=user)
            for e in entities:
                s.run('MERGE (e:Entity {name:$e, user:$u})', e=e, u=user)
                s.run('MATCH (d:Document {name:$f, user:$u}), (e:Entity {name:$e, user:$u}) CREATE (d)-[:MENTIONS]->(e)', f=file, e=e, u=user)
            s.run('MATCH (d:Document {name:$f, user:$u})-[:MENTIONS]->(e1:Entity {user:$u}), (d)-[:MENTIONS]->(e2:Entity {user:$u}) WHERE e1 <> e2 MERGE (e1)-[:RELATED]->(e2)', f=file, u=user)

    def query_paths(self, term: str, user: str = 'default', limit_paths: int = 8) -> List[Dict[str, Any]]:
        cypher = (
            'MATCH (e:Entity {user:$u}) '
            'WHERE toLower(e.name) CONTAINS toLower($t) '
            'WITH e MATCH p=(e)-[r:RELATED|MENTIONS*1..2]->(n {user:$u}) '
            'WITH p LIMIT $lim '
            'RETURN [x IN nodes(p) | coalesce(x.name, labels(x)[0])] AS nodes, '
            '[type(rel) IN relationships(p) | type(rel)] AS rels'
        )
        triples = []
        with self.driver.session() as s:
            rows = s.run(cypher, u=user, t=term, lim=limit_paths).data()
            for row in rows:
                nodes = row.get('nodes') or []
                rels  = row.get('rels') or []
                for i, rel in enumerate(rels):
                    src, dst = nodes[i], nodes[i+1]
                    triples.append({'src': src, 'rel': rel, 'dst': dst})
        uniq, seen = [], set()
        for t in triples:
            k = (t['src'], t['rel'], t['dst'])
            if k not in seen:
                seen.add(k); uniq.append(t)
        return uniq[:limit_paths]

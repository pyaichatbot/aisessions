from typing import List, Dict, Any
from ..llm_wrapper import LLMWrapper

def synthesize(question: str, vec_hits: List[Dict[str,Any]], graph_hits: List[Dict[str,Any]]):
    llm = LLMWrapper()  # Replace with your local model
    context = [h['text'] for h in (vec_hits or [])][:6]
    prompt = (
        'You are an onboarding analyst. Use the provided context and graph relations to answer. '
        'Keep it concise. Add short citations (filenames). If unsure, say so.'
    )
    answer = llm.generate(prompt, context)
    citations = [{'file': h.get('file','Document'), 'relevance': round(h.get('relevance',0.0),3)} for h in (vec_hits or [])]
    return {'answer': answer, 'citations': citations, 'graph_paths': graph_hits}

def route_query(q: str) -> str:
    low = (q or '').lower()
    graph_triggers = ['who relates', 'relationship', 'depends', 'connected', 'link', 'entity', 'graph']
    vec_triggers   = ['document', 'section', 'policy', 'explain', 'summarize', 'require', 'list']
    if any(t in low for t in graph_triggers):
        return 'graph'
    if any(t in low for t in vec_triggers):
        return 'vector'
    return 'hybrid'

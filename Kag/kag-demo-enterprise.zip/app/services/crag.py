from typing import List, Dict, Any, Tuple
import numpy as np
from llama_index.embeddings.huggingface import HuggingFaceEmbedding

_embed = None
def _emb():
    global _embed
    if _embed is None:
        _embed = HuggingFaceEmbedding('sentence-transformers/all-MiniLM-L6-v2')
    return _embed

def _embed_texts(texts: List[str]) -> np.ndarray:
    e = _emb()
    vecs = e.get_text_embedding_batch(texts or [''])
    return np.array(vecs, dtype='float32')

def _cos(a: np.ndarray, b: np.ndarray) -> float:
    denom = (np.linalg.norm(a) * np.linalg.norm(b)) or 1e-6
    return float(np.dot(a, b) / denom)

def filter_results(question: str, vector_hits: List[Dict[str,Any]], graph_hits: List[Dict[str,Any]], thresh: float = 0.28) -> Tuple[List[Dict], List[Dict], Dict[str,Any]]:
    logs = {'threshold': thresh, 'vector_before': len(vector_hits), 'graph_before': len(graph_hits)}
    qv = _embed_texts([question])[0]

    kept_vec = []
    if vector_hits:
        texts = [h['text'] for h in vector_hits]
        mat = _embed_texts(texts)
        for h, hv in zip(vector_hits, mat):
            sim = _cos(qv, hv)
            h['relevance'] = sim
            if sim >= thresh:
                kept_vec.append(h)

    kept_graph = []
    q_words = set([w for w in question.lower().split() if len(w) > 2])
    for t in graph_hits or []:
        score = 0.0
        for part in [t.get('src',''), t.get('dst',''), t.get('rel','')]:
            for w in q_words:
                if w in part.lower():
                    score += 0.2
        t['relevance'] = min(score, 1.0)
        if t['relevance'] >= 0.2:
            kept_graph.append(t)

    logs['vector_after'] = len(kept_vec)
    logs['graph_after'] = len(kept_graph)
    return kept_vec, kept_graph, logs

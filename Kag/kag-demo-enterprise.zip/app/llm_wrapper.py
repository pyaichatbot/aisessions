from typing import List

class LLMWrapper:
    """Swap this with your local LLM call (Ollama, vLLM, etc.)."""
    def generate(self, prompt: str, context: List[str]) -> str:
        # default heuristic: concatenate context (so demo runs without a model)
        body = "\n".join([c[:500] for c in (context or [])])
        return f"""Draft answer (heuristic)
---
{body}
"""

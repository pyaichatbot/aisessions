from fastapi import APIRouter
from pydantic import BaseModel
from typing import Dict, Any
from ..services.vector_store import VectorStore
from ..services.graph_store import GraphStore
from ..services.arag import route_query
from ..services.crag import filter_results
from ..services.kag import synthesize
from ..utils.config import CHROMA_PATH

router = APIRouter(prefix='/query', tags=['query'])

_vs = VectorStore(CHROMA_PATH)
_gs = GraphStore()

class QIn(BaseModel):
    question: str
    user: str = 'default'

@router.post('')
def run_query(q: QIn) -> Dict[str, Any]:
    route = route_query(q.question)
    vec_hits = _vs.query(q.question, top_k=8, user=q.user) if route in ('vector','hybrid') else []
    graph_hits = _gs.query_paths(q.question, user=q.user, limit_paths=10) if route in ('graph','hybrid') else []
    kept_vec, kept_graph, crag_log = filter_results(q.question, vec_hits, graph_hits)
    out = synthesize(q.question, kept_vec, kept_graph)
    return {'route': route, 'crag': crag_log, **out}

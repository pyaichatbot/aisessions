from fastapi import APIRouter
from ..services.vector_store import VectorStore
from ..services.graph_store import GraphStore
from ..utils.config import CHROMA_PATH

router = APIRouter(prefix='/ingest', tags=['ingest'])

_vs = VectorStore(CHROMA_PATH)
_gs = GraphStore()

@router.post('/reset')
def reset():
    _vs.reset(); _gs.reset();
    return {'status':'ok', 'message':'Vector store and Neo4j graph cleared.'}

from fastapi import APIRouter, UploadFile, File, Form
from ..services import preprocess, vector_store, graph_store
from ..utils.config import MAX_CHUNK_TOKENS, CHUNK_OVERLAP, CHROMA_PATH

router = APIRouter(prefix='/upload', tags=['upload'])

_vs = vector_store.VectorStore(CHROMA_PATH)
_gs = graph_store.GraphStore()

@router.post('')
async def upload(file: UploadFile = File(...), user: str = Form('default')):
    content_bytes = await file.read()
    text, meta = preprocess.extract(content_bytes, file.filename)
    chunks = preprocess.chunk(text, file.filename, MAX_CHUNK_TOKENS, CHUNK_OVERLAP)
    count = _vs.index_chunks(chunks, user=user)
    # naive entities (replace with spaCy/LLM in prod)
    ents = list({w for w in text.split() if w.istitle() and len(w) > 2})[:50]
    _gs.add_doc_entities(file.filename, ents, user=user)
    return {'file': file.filename, 'chunks_indexed': count, 'entities': len(ents)}

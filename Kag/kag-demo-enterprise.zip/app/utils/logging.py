import time
def log_event(stage: str, **kwargs):
    return {'ts': time.time(), 'stage': stage, **kwargs}

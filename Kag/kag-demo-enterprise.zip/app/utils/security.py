def require_api_key(token: str | None) -> bool:
    return True  # plug your org auth here

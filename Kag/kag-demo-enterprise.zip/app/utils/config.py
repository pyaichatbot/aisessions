import os
NEO4J_URI  = os.getenv('NEO4J_URI', 'bolt://localhost:7687')
NEO4J_USER = os.getenv('NEO4J_USER', 'neo4j')
NEO4J_PASS = os.getenv('NEO4J_PASS', 'password')
CHROMA_PATH = os.getenv('CHROMA_PATH', './chroma')
MAX_CHUNK_TOKENS = int(os.getenv('KAG_MAX_CHUNK_TOKENS', '350'))
CHUNK_OVERLAP    = int(os.getenv('KAG_CHUNK_OVERLAP', '40'))
